({
	doInit : function(component, event, helper) {
        console.log(component.get("v.pageReference").state.id);
    }
})
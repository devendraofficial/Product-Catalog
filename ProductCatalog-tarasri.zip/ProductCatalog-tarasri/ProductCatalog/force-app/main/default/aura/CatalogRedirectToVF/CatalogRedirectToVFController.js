({
	myAction : function(component, event, helper) {
		window.open("/c/ProductCatalogContainerApp.app","_blank");
        //window.open("/c/ProductCatalogContainerApp.app?LeadId=112233","_blank");
        
	}
})
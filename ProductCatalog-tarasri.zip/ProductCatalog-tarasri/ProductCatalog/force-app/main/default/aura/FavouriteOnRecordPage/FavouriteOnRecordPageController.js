({
	doInit : function(component, event, helper) {
        helper.helperInit(component, event, helper);
    }
})
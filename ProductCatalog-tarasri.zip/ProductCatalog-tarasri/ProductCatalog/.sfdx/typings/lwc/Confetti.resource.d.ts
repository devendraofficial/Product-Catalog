declare module "@salesforce/resourceUrl/Confetti" {
    var Confetti: string;
    export default Confetti;
}
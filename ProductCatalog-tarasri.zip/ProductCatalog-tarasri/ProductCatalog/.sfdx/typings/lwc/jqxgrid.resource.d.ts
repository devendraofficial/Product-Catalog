declare module "@salesforce/resourceUrl/jqxgrid" {
    var jqxgrid: string;
    export default jqxgrid;
}
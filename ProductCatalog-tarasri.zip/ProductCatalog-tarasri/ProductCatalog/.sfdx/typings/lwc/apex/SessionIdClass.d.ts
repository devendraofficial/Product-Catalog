declare module "@salesforce/apex/SessionIdClass.fetchFilteredProducts" {
  export default function fetchFilteredProducts(): Promise<any>;
}

declare module "@salesforce/apex/ProductCatalogController.queryFav" {
  export default function queryFav(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/ProductCatalogController.queryProducts" {
  export default function queryProducts(): Promise<any>;
}

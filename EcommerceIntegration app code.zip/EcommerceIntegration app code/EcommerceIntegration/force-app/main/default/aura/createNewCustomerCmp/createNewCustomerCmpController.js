({
    
    submitDetails : function(component, event, helper) {
        var custList = component.get("v.customerMap");
        component.set("v.isModalOpen", false);
        var action = component.get("c.createNewCustomer");
        action.setParams({ 
            "customerMap": custList
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var title = 'Success!';
                var type = 'success';
                var message = 'Customer record created successfully.'
                var compEvent = component.getEvent("customerComponentEvent"); 
                compEvent.fire();
                helper.handleToast(component,event,helper,title,type,message);
                
            }else {
                component.set("v.isModalOpen", false);
                var title = 'Failed!';
                var type = 'error';
                var message = action.getError()[0].message;
                helper.handleToast(component,event,helper,title,type,message);
                
            }
        });
        $A.enqueueAction(action);
    },
    
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        component.set("v.customer",[]);
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
})
({
    setDefaultAppToggle : function(component, event, helper) {
        var action = component.get("c.getSelectedApp");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(resultData != null){
                    if(resultData == 'Shopify'){
                        component.find("toggleid")[0].set("v.checked", true);
                        component.set("v.shopifyDiv", true);
                        component.set("v.defaultApp", 'Shopify');
                    }else if(resultData == 'Magento'){
                        component.find("toggleid")[1].set("v.checked", true);
                        component.set("v.magentoDiv", true);
                        component.set("v.defaultApp", 'Magento');
                    }else if(resultData == 'Woocommerce'){
                        component.find("toggleid")[2].set("v.checked", true);
                        component.set("v.woocommerceDiv", true);
                        component.set("v.defaultApp", 'Woocommerce');
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    setDefaultShopifyShop : function(component, event, helper,shopID) {
        var action = component.get("c.setDefaultShopifyStore");
        action.setParams({
            "shopid": shopID
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                console.log(state);
            }else {
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    setDefaultMagentoShop : function(component, event, helper,shopID) {
        var action = component.get("c.setDefaultMagentoStore");
        action.setParams({
            "shopid": shopID
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                console.log(state);
            }else {
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    setDefaultWoocommerceShop : function(component, event, helper,shopID) {
        var action = component.get("c.setDefaultWoocommerceStore");
        action.setParams({
            "shopid": shopID
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                console.log(state);
            }else {
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    getShopifyShopDetails : function(component, event, helper) {
        var action = component.get("c.fetchShopifyShopList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(resultData != null){
                    component.set("v.shopifyStoreList",resultData);
                }else{
                    component.set("v.shopifyStoreList",[]);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getMagentoShopDetails : function(component, event, helper) {
        var action = component.get("c.fetchMagentoShopList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(resultData != null){
                    component.set("v.magentoStoreList",resultData);
                    }else{
                    component.set("v.magentoStoreList",[]);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    getWoocommerceShopDetails : function(component, event, helper) {
        var action = component.get("c.fetchWoocommerceShopList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(resultData != null){
                    component.set("v.woocommerceStoreList",resultData);
                   }else{
                    component.set("v.magentoStoreList",[]);
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    setSelectedAppDetails : function(component, event, helper,appname) {
        var action = component.get("c.setSelectedApp");
        action.setParams({
            "name": appname
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                console.log(state);
            }else {
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    saveShopifyDetailsHelper : function(component, event, helper, storeurl, accesstoken, password) {
        var action = component.get("c.addNewShopifyStore");
        action.setParams({
            "StoreURL" : storeurl,
            "accessToken" : accesstoken,
            "password" : password
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: 'New Shop added successfully.'
                });
                toastEvent.fire();
                component.set("v.shopifyStoreList",resultData);
                helper.resetvalues(component, helper, event);
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    saveMagentoDetailsHelper : function(component, event, helper, storeurl, accesstoken, password) {
        var action = component.get("c.addNewMagentoStore");
        action.setParams({
            "StoreURL" : storeurl,
            "accessToken" : accesstoken,
            "password" : password
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: 'New Shop added successfully.'
                });
                toastEvent.fire();
                component.set("v.magentoStoreList",resultData);
                helper.resetvalues(component, helper, event);
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    saveWoocommerceDetailsHelper : function(component, event, helper, storeurl, accesstoken, password) {
        var action = component.get("c.addNewWoocommerceStore");
        action.setParams({
            "StoreURL" : storeurl,
            "accessToken" : accesstoken,
            "password" : password
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: 'New Shop added successfully.'
                });
                toastEvent.fire();
                component.set("v.woocommerceStoreList",resultData);
                helper.resetvalues(component, helper, event);
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    editStoreHelper : function(component, event, helper,storename,shopid){
        
        if(storename == 'Shopify'){
            var action = component.get("c.getShopifyStoreList");
        }else if(storename == 'Magento'){
            var action = component.get("c.getMagentoStoreList");
        }else if(storename == 'Woocomerce'){
            var action = component.get("c.getWoocommerceStoreList");
        }
        
        action.setParams({
            "shopId" : shopid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                component.set("v.storeURL",resultData[0].Name);
                if(storename == 'Shopify'){
                    component.set("v.accessToken",resultData[0].Access_Token__c);
                    component.set("v.password",resultData[0].Password__c);
                    component.set("v.openEditModal", true);
                }else if(storename == 'Woocomerce'){
                    component.set("v.accessToken",resultData[0].Consumer_Key__c);
                    component.set("v.password",resultData[0].Consumer_Secret__c);
                    component.set("v.openEditModal", true);
                }else{
                    component.set("v.accessToken",resultData[0].Username__c);
                    component.set("v.password",resultData[0].Password__c);
                    component.set("v.openEditModal", true);
                }
                
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    saveEditedStoreHelper : function(component, event, helper,storename,shopid,storeurl,accesstoken,password){
        if(storename == 'Shopify'){
            var action = component.get("c.saveShopifyEditedDetails");
        }else if(storename == 'Magento'){
            var action = component.get("c.saveMagentoEditedDetails");
        }else if(storename == 'Woocomerce'){
            var action = component.get("c.saveWoocommerceEditedDetails");
        }
        
        action.setParams({
            "shopid" : shopid,
            "storeurl" : storeurl,
            "accesstoken" : accesstoken,
            "password" : password
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(storename == 'Shopify'){
                    component.set("v.shopifyStoreList",resultData);
                }else if(storename == 'Magento'){
                    component.set("v.magentoStoreList",resultData);
                }else if(storename == 'Woocomerce'){
                    component.set("v.woocommerceStoreList",resultData);
                }
                 var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: 'Store details updated successfully.'
                });
                toastEvent.fire();
                helper.resetvalues(component, helper, event);
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    deleteStoreHelper : function(component, event, helper,storename,storeid){
        if(storename == 'Shopify'){
            var action = component.get("c.deleteShpfyStore");
        }else if(storename == 'Magento'){
            var action = component.get("c.deleteMgntoStore");
        }else if(storename == 'Woocommerce'){
            var action = component.get("c.deleteWoocomStore");
        }
        action.setParams({
            "storeid" : storeid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var resultData = response.getReturnValue();
                if(storename == 'Shopify'){
                    component.set("v.shopifyStoreList",resultData);
                }else if(storename == 'Magento'){
                    component.set("v.magentoStoreList",resultData);
                }else if(storename == 'Woocommerce'){
                    component.set("v.woocommerceStoreList",resultData);
                }
                 var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: 'Store deleted successfully.'
                });
                toastEvent.fire();
                helper.resetvalues(component, helper, event);
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    resetvalues : function(component, event, helper){
        component.set("v.storeURL", '');
        component.set("v.accessToken", '');
        component.set("v.password", '');
        component.set("v.storeId",'');
    }
})
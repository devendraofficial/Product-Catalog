({
    doInit : function(component, event, helper) {
        helper.setDefaultAppToggle(component, event, helper);
        helper.getShopifyShopDetails(component, event, helper);
        helper.getMagentoShopDetails(component, event, helper);
        helper.getWoocommerceShopDetails(component, event, helper);
    },
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    
    toggleDefaultShopifyShop: function(component, event, helper) {
        var shopID = event.target.getAttribute('data-value');
        var totalelements = component.find("toggleidA");
        var ids = event.target.getAttribute('data-Id');
        var shpifylist = component.get("v.shopifyStoreList");
        
        if(shpifylist.length == 1){
            var isChecked = component.find("toggleidA").get("v.checked");
            if(isChecked == false){
                component.find("toggleidA").set("v.checked",false);
            }else{
                helper.setDefaultShopifyShop(component, event, helper, shopID);
            }
        }else {
            for(var i in totalelements) {
                if(i == ids){
                    component.find("toggleidA")[i].set("v.checked", true);
                }
                else{
                    component.find("toggleidA")[i].set("v.checked", false);
                }
            }
            //call helper and apex function to set default shopify shop...
            helper.setDefaultShopifyShop(component, event, helper, shopID);
        }
        var appEvent = $A.get("e.c:refreshMappingModalBoxEvent"); 
        appEvent.fire();
    },
    
    toggleDefaultMagentoShop: function(component, event, helper) {
        var shopID = event.target.getAttribute('data-value');
        var totalelements = component.find("toggleid3");
        var ids = event.target.getAttribute('data-Id');
        var mgntolist = component.get("v.magentoStoreList");
        
        if(mgntolist.length == 1){
            var isChecked = component.find("toggleid3").get("v.checked");
            if(isChecked == false){
                component.find("toggleid3").set("v.checked",false);
            }else{
                helper.setDefaultMagentoShop(component, event, helper, shopID);
            }
        }else {
            for(var i in totalelements) {
                if(i == ids){
                    component.find("toggleid3")[i].set("v.checked", true);
                }
                else{
                    component.find("toggleid3")[i].set("v.checked", false);
                }
            }
            
            //call helper and apex function to set default shopify shop...
            helper.setDefaultMagentoShop(component, event, helper, shopID);
        }
        var appEvent = $A.get("e.c:refreshMappingModalBoxEvent"); 
        appEvent.fire();
        
    },
    
    toggleDefaultWoocommerceShop: function(component, event, helper) {
        var shopID = event.target.getAttribute('data-value');
        var totalelements = component.find("toggleid4");
        var ids = event.target.getAttribute('data-Id');
        var wocom = component.get("v.woocommerceStoreList");
        
        if(wocom.length == 1){
            var isChecked = component.find("toggleid4").get("v.checked");
            if(isChecked == false){
                component.find("toggleid4").set("v.checked",false);
            }else{
                helper.setDefaultWoocommerceShop(component, event, helper, shopID);
            }
        }else {
            for(var i in totalelements) {
                if(i == ids){
                    component.find("toggleid4")[i].set("v.checked", true);
                }
                else{
                    component.find("toggleid4")[i].set("v.checked", false);
                }
            }
            //call helper and apex function to set default shopify shop...
            helper.setDefaultWoocommerceShop(component, event, helper, shopID);
        }
        var appEvent = $A.get("e.c:refreshMappingModalBoxEvent"); 
        appEvent.fire();
    },
    
    getAppName : function(component, event, helper) {
        
        //Control toggle and get selected app name:
        var appname = event.target.getAttribute('data-value');
        component.set("v.defaultApp",appname);
        var totalelements = component.find("toggleid");
        var ids = event.target.getAttribute('data-Id');
        for(var i in totalelements) {
            if(i == ids){
                component.find("toggleid")[i].set("v.checked", true);
            }
            else{
                component.find("toggleid")[i].set("v.checked", false);
            }
        }
        
        //call this helper when saving the configuration:
        helper.setSelectedAppDetails(component, event, helper,appname);
        
        //Control configuration div according to selected app:
        
        if(appname == 'Shopify'){
            component.set("v.shopifyDiv", true);
            component.set("v.magentoDiv", false);
            component.set("v.woocommerceDiv", false);
        }else if(appname == 'Magento'){
            component.set("v.shopifyDiv", false);
            component.set("v.magentoDiv", true);
            component.set("v.woocommerceDiv", false);
        }else if(appname == 'Woocommerce'){
            component.set("v.shopifyDiv", false);
            component.set("v.magentoDiv", false);
            component.set("v.woocommerceDiv", true);
        }
        var appEvent = $A.get("e.c:refreshMappingModalBoxEvent"); 
        appEvent.fire();
    },
    
    openNewShopifyStoreModal: function(component, event, helper) {
        component.set("v.storeName", 'Shopify');
        component.set("v.openModal", true);
    },
    openNewMagentoStoreModal: function(component, event, helper) {
        component.set("v.storeName", 'Magento');
        component.set("v.openModal", true);
    },
    
    openNewWoocommerceStoreModal: function(component, event, helper) {
        component.set("v.storeName", 'Woocomerce');
        component.set("v.openModal", true);
    },
    closeModal: function(component, event, helper) {
        component.set("v.storeName", '');
        component.set("v.storeURL", '');
        component.set("v.accessToken", '');
        component.set("v.password", '');
        component.set("v.openModal", false);
        component.set("v.openEditModal", false);
    },
    
    saveNewStoreDetails : function(component, event, helper) {
        component.set("v.openModal", false);
        var storename = component.get("v.storeName");
        var storeurl = component.get("v.storeURL");
        var accesstoken = component.get("v.accessToken");
        var password = component.get("v.password");
        var process = false;
        
        if(storeurl == undefined || storeurl == ''){
            alert('Please fill Store URL');
        }else if(accesstoken == undefined || accesstoken == ''){
            alert('Please fill Access token/ Username');
        }else if(password == undefined || password == ''){
            alert('Please fill Password');
        }else{
            process = true;
        }
        
        if(process){
            if(storename == 'Shopify'){
                helper.saveShopifyDetailsHelper(component, event, helper, storeurl, accesstoken, password);
            }else if(storename == 'Magento'){
                helper.saveMagentoDetailsHelper(component, event, helper, storeurl, accesstoken, password);
            }else if(storename == 'Woocomerce'){
                helper.saveWoocommerceDetailsHelper(component, event, helper, storeurl, accesstoken, password);
            }
        }
    },
    
    editShopifyModel : function(component, event, helper) {
        var shopid = event.target.getAttribute('data-value');
        component.set("v.storeId",shopid);
        component.set("v.storeName", 'Shopify');
        var storename = component.get("v.storeName");
        if(shopid != '' || shopid != undefined || storename != '' || storename != undefined){
            helper.editStoreHelper(component, event, helper,storename,shopid);
        }else{
            alert('Error while fetching values');
        }
    },
    
    editMagentoModel : function(component, event, helper) {
        var shopid = event.target.getAttribute('data-value');
        component.set("v.storeId",shopid);
        component.set("v.storeName", 'Magento');
        var storename = component.get("v.storeName");
        if(shopid != '' || shopid != undefined || storename != '' || storename != undefined){
            helper.editStoreHelper(component, event, helper,storename,shopid);
        }else{
            alert('Error while fetching values');
        }
    },
    editWoocommerceModel : function(component, event, helper) {
        var shopid = event.target.getAttribute('data-value');
        component.set("v.storeId",shopid);
        component.set("v.storeName", 'Woocomerce');
        var storename = component.get("v.storeName");
        if(shopid != '' || shopid != undefined || storename != '' || storename != undefined){
            helper.editStoreHelper(component, event, helper,storename,shopid);
        }else{
            alert('Error while fetching values');
        }
        
    },
    
    saveEditedDetails : function(component, event, helper) {
        var shopid = component.get("v.storeId");
        var storename = component.get("v.storeName");
        var storeurl = component.get("v.storeURL");
        var accesstoken = component.get("v.accessToken");
        var password = component.get("v.password");
        if(storename != '' || storename != undefined || storeurl != '' || storeurl != undefined || accesstoken != '' || accesstoken != undefined
           || password != '' || password != undefined){
            component.set("v.openEditModal", false);
            helper.saveEditedStoreHelper(component, event, helper,storename,shopid,storeurl,accesstoken,password);
        }else{
            alert('Error while saving edited record');
        }
    },
    
    deleteShopifyStore : function(component, event, helper) {
        var storeid = event.target.getAttribute('data-value');
        var storename = 'Shopify';
        if(storeid != '' || storeid != undefined){
            helper.deleteStoreHelper(component, event, helper,storename,storeid);
        }else{
            alert('Error while fetching store id');
        }
    },
    
    deleteMagentoStore : function(component, event, helper) {
        var storeid = event.target.getAttribute('data-value');
        var storename = 'Magento';
        if(storeid != '' || storeid != undefined){
            helper.deleteStoreHelper(component, event, helper,storename,storeid);
        }else{
            alert('Error while fetching store id');
        }
    },
    
    deleteWoocommerceStore : function(component, event, helper) {
        var storeid = event.target.getAttribute('data-value');
        var storename = 'Woocommerce';
        if(storeid != '' || storeid != undefined){
            helper.deleteStoreHelper(component, event, helper,storename,storeid);
        }else{
            alert('Error while fetching store id');
        }
    },
    
    handleShopifyMapping : function(component, event, helper){
        component.set("v.showShopifyMappingModal", true);
        var appEvent = $A.get("e.c:shopifyMappingEvent");               
        appEvent.setParams({
            "modalValue":true,
            "defaultAppName" : component.get("v.defaultApp")
        });                                               
        appEvent.fire();
    },
})
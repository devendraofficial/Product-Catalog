({
    doInit: function(component, event, helper) {
        helper.doInitHelper(component, event);
    },
    
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    
    openOrderModalBox : function (component, event, helper){
        var modalboxcmp = component.find('orderModalBoxComponent');
        modalboxcmp.openmodalbox();
    },
    showfilterBox : function(component, event, helper){
        var divstate = component.get('v.showFilterDiv');
        if(divstate == 'slds-show'){
            component.set("v.showFilterDiv", "slds-hide");
        }else{
            component.set("v.showFilterDiv", "slds-show");
        }
    },
    
    //function for filter to show hide columns
    onCheckFilters: function(component, event, helper) {
        var value = event.getSource().get("v.text");
        
        if(value == 'CreatedDate'){
            var abc =  component.get("v.CreatedDate");
            if(abc == 'slds-show' ){
                component.set("v.CreatedDate",'slds-hide');
            }else{
                component.set("v.CreatedDate",'slds-show');
            }
        }else if(value == 'LastModifiedDate'){
            var abc =  component.get("v.LastModifiedDate");
            if(abc == 'slds-show' ){
                component.set("v.LastModifiedDate",'slds-hide');
            }else{
                component.set("v.LastModifiedDate",'slds-show');
            }
        }else if(value == 'DueAmount'){
            var abc =  component.get("v.DueAmount");
            if(abc == 'slds-show' ){
                component.set("v.DueAmount",'slds-hide');
            }else{
                component.set("v.DueAmount",'slds-show');
            }
        }else if(value == 'Discount'){
            var abc =  component.get("v.Discount");
            if(abc == 'slds-show' ){
                component.set("v.Discount",'slds-hide');
            }else{
                component.set("v.Discount",'slds-show');
            }
        }else if(value == 'TaxAmount'){
            var abc =  component.get("v.TaxAmount");
            if(abc == 'slds-show' ){
                component.set("v.TaxAmount",'slds-hide');
            }else{
                component.set("v.TaxAmount",'slds-show');
            }
        }else if(value == 'ShippingAddress'){
            var abc =  component.get("v.ShippingAddress");
            if(abc == 'slds-show' ){
                component.set("v.ShippingAddress",'slds-hide');
            }else{
                component.set("v.ShippingAddress",'slds-show');
            }
        }else if(value == 'BillingAddress'){
            var abc =  component.get("v.BillingAddress");
            if(abc == 'slds-show' ){
                component.set("v.BillingAddress",'slds-hide');
            }else{
                component.set("v.BillingAddress",'slds-show');
            }
        }else if(value == 'ShippingAmount'){
            var abc =  component.get("v.ShippingAmount");
            if(abc == 'slds-show' ){
                component.set("v.ShippingAmount",'slds-hide');
            }else{
                component.set("v.ShippingAmount",'slds-show');
            }
        }
    },
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.orderList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var whichBtn = event.getSource().get("v.name");
        
        if (whichBtn == 'next') {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList);
        }
        
        else if (whichBtn == 'previous') {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listoforders = component.get("v.orderList");
        var PaginationList = component.get("v.PaginationList");
        
        for (var i = 0; i < listoforders.length; i++) {
            if (selectedHeaderCheck == true) {
                listoforders[i].isChecked = true;
                component.set("v.selectedCount", listoforders.length);
            } else {
                listoforders[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listoforders[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.orderList", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
    },
    
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
    },
    
    handleShowEntry : function(component, event, helper) {
        var prodctlist = component.get('v.orderList');
        var pageSize = component.get("v.pageSize");
        var totalRecordsList = prodctlist;
        var totalLength = totalRecordsList.length ;
        component.set("v.totalRecordsCount", totalLength);
        component.set("v.startPage",0);
        component.set("v.endPage",pageSize-1);
        component.set("v.currentPage",1);
        var PaginationLst = [];
        for(var i=0; i < pageSize; i++){
            if(component.get("v.orderList").length > i){
                PaginationLst.push(prodctlist[i]);    
            } 
        }
        component.set('v.PaginationList', PaginationLst);
        component.set("v.selectedCount" , 0);
        component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
        
    },
    
    deleteSelectedRecords: function(component, event, helper) {
        var allRecords = component.get("v.orderList");
        var orderid = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                orderid.push(allRecords[i].objorder.Order_Id__c);
            }
        }
        helper.deleteMultipleOrder(component, event, helper,orderid);
    },
    
    previewOrder: function(component, event, helper) {
        var url = event.target.getAttribute('data-value');
        var orderid = event.target.getAttribute('data-Id');
        var storeurl = String(url); 
        if(storeurl.includes("myshopify")){
            window.open(storeurl+"/admin/orders/"+orderid, '_blank'); 
        }else if(storeurl.includes("wpthemes")){
            window.open(storeurl+"/wp-admin/post.php?post="+orderid+"&action=edit", '_blank');
        }else{
            window.open(storeurl+"/admin/sales/order/view/order_id/"+orderid, '_blank');
        }
        
    },
    
    deleteSingleOrder :function(component, event, helper){
        var orderid =  event.getSource().get("v.value");
        helper.deletesingleorderhelper(component, event, helper,orderid);
    },
    
    doSearching: function(component, event, helper) {  
        helper.FilterRecords(component);  
    },
    
    SyncAllOrders : function(component, event, helper) {  
        helper.synchelper(component);  
    },
})
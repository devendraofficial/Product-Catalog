({
    
    doInitHelper : function(component,event){ 
        var action = component.get("c.fetchproductWrapper");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var oRes = response.getReturnValue();
                if(oRes.length > 0 || oRes != null){
                    component.set('v.productList', oRes);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",pageSize-1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.productList").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));  
                }else{
                    // if there is no records then display message
                    component.set("v.bNoRecordsFound" , true);
                } 
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
                component.set("v.bNoRecordsFound" , true);
            }
        });
        $A.enqueueAction(action);  
    },
    
    fetchProductFields : function(component, event, helper) {
        var action = component.get("c.getProductMappings");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                if(response.getReturnValue() != null){
                    var arrayMap = response.getReturnValue();
                    var prodtMap = JSON.parse(arrayMap[0].replace(/&quot;/g,'"'));

                    //set product mapping:
                    component.set("v.field1",prodtMap.ProductName);
                    component.set("v.field2",prodtMap.ProductID);
                    component.set("v.field3",prodtMap.ProductPrice);
                    component.set("v.field4",prodtMap.ProductImageURL);
                    component.set("v.field5",prodtMap.ProductCreatedDate);
                    component.set("v.field6",prodtMap.ProductUpdatedDate);
                    component.set("v.field7",prodtMap.ProductDescription);
                    component.set("v.field8",prodtMap.ProductSKU);
                    
                    console.log('field1:',component.get("v.field1"));
                    
                }
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    
    
    
    next : function(component,event,sObjectList){
        var Paginationlist = [];
        var counter = 0;
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        
        for(var i = parseInt(end)+parseInt(1); i < parseInt(end) + parseInt(pageSize) + parseInt(1); i++){
            if(sObjectList.length > i){ 
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]);  
                }
            }
            counter ++ ;
        }
        start = parseInt(start) + parseInt(counter);
        end = parseInt(end) + parseInt(counter);
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    
    previous : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        
        for(var i= parseInt(start) - parseInt(pageSize); i < parseInt(start) ; i++){
            if(i > -1){
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]); 
                }
                counter ++;
            }else{
                start++;
            }
        }
        start = parseInt(start) - parseInt(counter);
        end = parseInt(end) - parseInt(counter);
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    
    FilterRecords: function(component) {  
        
        var data = component.get("v.PaginationList");  
        var allRecords = component.get("v.productList");  
        
        var searchFilter = component.get("v.searchKeyword").toUpperCase();
        var filtereddata = [];
        var i;
        
        // check if searchKey is blank  
        if(searchFilter==''){  
            component.set("v.bNoRecordsFound" , false);
            var pageSize = component.get("v.pageSize");
            var PaginationLst = [];
            
            for(var i=0; i < pageSize; i++){
                if(component.get("v.productList").length > i){
                    PaginationLst.push(allRecords[i]);    
                } 
            }
            component.set("v.PaginationList",PaginationLst);
            var totalRecordsList = component.get("v.productList");
            var totalLength = totalRecordsList.length ;
            component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPage",0);
            component.set("v.endPage",parseInt(pageSize) - parseInt(1));
            component.set("v.selectedCount" , 0);
            component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize)); 
        }else{
            for(i=0; i < allRecords.length; i++){
                if((allRecords[i].objproduct.Name && allRecords[i].objproduct.Name.toUpperCase().indexOf(searchFilter) != -1) ||
                   (allRecords[i].objproduct.Product_Id__c && allRecords[i].objproduct.Product_Id__c.toUpperCase().indexOf(searchFilter) != -1 ))
                {
                    filtereddata.push(allRecords[i]);
                }
            }
            if(filtereddata.length == 0){
                component.set("v.bNoRecordsFound" , true);
            }else{
                component.set("v.bNoRecordsFound" , false);
                var pageSize = filtereddata.length;
                var PaginationLst = [];
                if(filtereddata.length > component.get("v.pageSize")){
                    pageSize = component.get("v.pageSize");
                }
                
                for(var i=0; i < pageSize; i++){
                    PaginationLst.push(filtereddata[i]);    
                }
                
                component.set("v.PaginationList",PaginationLst);
                component.set("v.totalRecordsCount", filtereddata.length);
                component.set("v.startPage",0);
                component.set("v.endPage",parseInt(pageSize) - parseInt(1));
                component.set("v.selectedCount" , 0);
                component.set("v.totalPagesCount", Math.ceil(filtereddata.length / pageSize));
            }
        } 
    },
    
    deleteSingleProduct : function(component, event, helper,productid){
        var action = component.get("c.deleteProduct");
        var array = [productid];

        action.setParams({ 
            "productId": array
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Product deleted successfully';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: message
                });
                toastEvent.fire();
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);  
    },
    deleteMultipleProduct : function(component, event, helper,productid){
        var action = component.get("c.deleteProduct");
        action.setParams({ 
            "productId": productid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Product deleted successfully';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: message
                });
                toastEvent.fire();
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);  
    },
    synchelper : function(component,event,helper){
        var action = component.get("c.syncProducts");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Syncing started successfully, please wait for a while.';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    duration:'7000',
                    message: message
                });
                toastEvent.fire();
                component.set("v.spinner", false);
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action); 
    },
    
    handleToast : function(component,event,helper,errorMsg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: 'Error',
            type: 'error',
            message: errorMsg
        });
        toastEvent.fire();
    },
})
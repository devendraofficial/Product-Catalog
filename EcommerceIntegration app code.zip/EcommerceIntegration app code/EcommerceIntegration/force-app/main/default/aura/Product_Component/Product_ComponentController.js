({
    doInit: function(component, event, helper) {
        //helper.fetchProductFields(component, event, helper);
        helper.doInitHelper(component, event);
        
    },
    
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    
    openProductModalBox : function (component, event, helper){
        var modalboxcmp = component.find('productModalBoxComponent');
        modalboxcmp.openmodalbox();
    },
    showfilterBox : function(component, event, helper){
        var divstate = component.get('v.showFilterDiv');
        if(divstate == 'slds-show'){
            component.set("v.showFilterDiv", "slds-hide");
        }else{
            component.set("v.showFilterDiv", "slds-show");
        }
    },
    
    //function for filter to show hide columns
    onCheckFilters: function(component, event, helper) {
        var value = event.getSource().get("v.text");
        
        if(value == 'CreatedDate'){
            var abc =  component.get("v.CreatedDateHide");
            if(abc == 'slds-show' ){
                component.set("v.CreatedDateHide",'slds-hide');
            }else{
                component.set("v.CreatedDateHide",'slds-show');
            }
        }else if(value == 'SKU'){
            var abc =  component.get("v.SKU");
            if(abc == 'slds-show' ){
                component.set("v.SKU",'slds-hide');
            }else{
                component.set("v.SKU",'slds-show');
            }
        }else if(value == 'LastModifiedDate'){
            var abc =  component.get("v.LastModifiedDateHide");
            if(abc == 'slds-show' ){
                component.set("v.LastModifiedDateHide",'slds-hide');
            }else{
                component.set("v.LastModifiedDateHide",'slds-show');
            }
        }else if(value == 'ProductCode'){
            var abc =  component.get("v.ProductCodeHide");
            if(abc == 'slds-show' ){
                component.set("v.ProductCodeHide",'slds-hide');
            }else{
                component.set("v.ProductCodeHide",'slds-show');
            }
        }else if(value == 'ProductType'){
            var abc =  component.get("v.ProductTypeHide");
            if(abc == 'slds-show' ){
                component.set("v.ProductTypeHide",'slds-hide');
            }else{
                component.set("v.ProductTypeHide",'slds-show');
            }
        }else if(value == 'ProductDescription'){
            var abc =  component.get("v.ProductDescriptionHide");
            if(abc == 'slds-show' ){
                component.set("v.ProductDescriptionHide",'slds-hide');
            }else{
                component.set("v.ProductDescriptionHide",'slds-show');
            }
        }else if(value == 'StoreURL'){
            var abc =  component.get("v.StoreURLHide");
            if(abc == 'slds-show' ){
                component.set("v.StoreURLHide",'slds-hide');
            }else{
                component.set("v.StoreURLHide",'slds-show');
            }
        }
    },
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.productList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var whichBtn = event.getSource().get("v.name");
        // check if whichBtn value is 'next' then call 'next' helper method
        if (whichBtn == 'next') {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList);
        }
        // check if whichBtn value is 'previous' then call 'previous' helper method
        else if (whichBtn == 'previous') {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listofproducts = component.get("v.productList");
        var PaginationList = component.get("v.PaginationList");
        
        for (var i = 0; i < listofproducts.length; i++) {
            if (selectedHeaderCheck == true) {
                listofproducts[i].isChecked = true;
                component.set("v.selectedCount", listofproducts.length);
            } else {
                listofproducts[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listofproducts[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.productList", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
    },
    
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
    },
    
    handleShowEntry : function(component, event, helper) {
        var prodctlist = component.get('v.productList');
        var pageSize = component.get("v.pageSize");
        var totalRecordsList = prodctlist;
        var totalLength = totalRecordsList.length ;
        component.set("v.totalRecordsCount", totalLength);
        component.set("v.startPage",0);
        component.set("v.endPage",pageSize-1);
        component.set("v.currentPage",1);
        var PaginationLst = [];
        for(var i=0; i < pageSize; i++){
            if(component.get("v.productList").length > i){
                PaginationLst.push(prodctlist[i]);    
            } 
        }
        component.set('v.PaginationList', PaginationLst);
        component.set("v.selectedCount" , 0);
        component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
        
    },
    
    deleteSelectedRecords: function(component, event, helper) {
        var allRecords = component.get("v.productList");
        var productid = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                productid.push(allRecords[i].objproduct.Product_Id__c);
            }
        }
        helper.deleteMultipleProduct(component, event, helper,productid);

    },
    
    previewProduct: function(component, event, helper) {
        var url = event.target.getAttribute('data-value');
        var productid = event.target.getAttribute('data-Id');
        var storeurl = String(url); 
        var prodname =  event.getSource().get("v.value");
        prodname = prodname.replace(/ /g, "-");
        if(storeurl.includes("wpthemes")){
            window.open(storeurl+"/products/"+prodname, '_blank'); 
        }else if(storeurl.includes("myshopify")){
            window.open(storeurl+"/products/"+prodname, '_blank'); 
        }else{
            window.open(storeurl+"/admin/catalog/product/edit/id/"+productid, '_blank'); 
        }
        
    },
    
    deleteSingleProduct :function(component, event, helper){
        var productid =  event.getSource().get("v.value");
        helper.deleteSingleProduct(component, event, helper,productid);
    },
    
    doSearching: function(component, event, helper) {  
        helper.FilterRecords(component);  
    },
    
    SyncAllProducts : function(component, event, helper) {  
        helper.synchelper(component);  
    },
})
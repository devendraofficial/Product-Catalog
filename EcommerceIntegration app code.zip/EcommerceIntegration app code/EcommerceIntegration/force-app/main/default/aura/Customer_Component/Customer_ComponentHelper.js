({
    
    doInitHelper : function(component,event){ 
        var action = component.get("c.fetchcustomerWrapper");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var oRes = response.getReturnValue();
                if(oRes.length > 0 || oRes != null){
                    component.set('v.customerList', oRes);
                    var pageSize = component.get("v.pageSize");
                    var totalRecordsList = oRes;
                    var totalLength = totalRecordsList.length ;
                    component.set("v.totalRecordsCount", totalLength);
                    component.set("v.startPage",0);
                    component.set("v.endPage",parseInt(pageSize) - 1);
                    
                    var PaginationLst = [];
                    for(var i=0; i < pageSize; i++){
                        if(component.get("v.customerList").length > i){
                            PaginationLst.push(oRes[i]);    
                        } 
                    }
                    component.set('v.PaginationList', PaginationLst);
                    component.set("v.selectedCount" , 0);
                    component.set("v.totalPagesCount", Math.ceil(parseInt(totalLength) / parseInt(pageSize)));    
                    if(PaginationLst.length == 0){
                        component.set("v.bNoRecordsFound" , true);
                    }else{
                        component.set("v.bNoRecordsFound" , false);
                    }
                }else{
                    // if there is no records then display message
                    component.set("v.bNoRecordsFound" , true);
                } 
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
                component.set("v.bNoRecordsFound" , true);
            }
        });
        $A.enqueueAction(action);  
    },
    
    next : function(component,event,sObjectList){
        var Paginationlist = [];
        var counter = 0;
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        
        for(var i = parseInt(end)+parseInt(1); i < parseInt(end) + parseInt(pageSize) + parseInt(1); i++){
            if(sObjectList.length > i){ 
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]);  
                }
            }
            counter ++ ;
        }
        start = parseInt(start) + parseInt(counter);
        end = parseInt(end) + parseInt(counter);
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    
    previous : function(component,event,sObjectList,end,start,pageSize){
        var Paginationlist = [];
        var counter = 0;
        
        for(var i= parseInt(start) - parseInt(pageSize); i < parseInt(start) ; i++){
            if(i > -1){
                if(component.find("selectAllId").get("v.value")){
                    Paginationlist.push(sObjectList[i]);
                }else{
                    Paginationlist.push(sObjectList[i]); 
                }
                counter ++;
            }else{
                start++;
            }
        }
        start = parseInt(start) - parseInt(counter);
        end = parseInt(end) - parseInt(counter);
        component.set("v.startPage",start);
        component.set("v.endPage",end);
        component.set('v.PaginationList', Paginationlist);
    },
    
    FilterRecords: function(component) {  
        
        var data = component.get("v.PaginationList");  
        var allRecords = component.get("v.customerList");  
        
        var searchFilter = component.get("v.searchKeyword").toUpperCase();
        var filtereddata = [];
        var i;
        
        // check if searchKey is blank  
        if(searchFilter==''){  
            component.set("v.bNoRecordsFound" , false);
            var pageSize = component.get("v.pageSize");
            var PaginationLst = [];
            
            for(var i=0; i < pageSize; i++){
                if(component.get("v.customerList").length > i){
                    PaginationLst.push(allRecords[i]);    
                } 
            }
            component.set("v.PaginationList",PaginationLst);
            var totalRecordsList = component.get("v.customerList");
            var totalLength = totalRecordsList.length ;
            component.set("v.totalRecordsCount", totalLength);
            component.set("v.startPage",0);
            component.set("v.endPage",parseInt(pageSize) - parseInt(1));
            component.set("v.selectedCount" , 0);
            component.set("v.totalPagesCount", Math.ceil(parseInt(totalLength) / parseInt(pageSize))); 
        }else{
            for(i=0; i < allRecords.length; i++){
                if((allRecords[i].objcustomer.Name && allRecords[i].objcustomer.Name.toUpperCase().indexOf(searchFilter) != -1) ||
                   (allRecords[i].objcustomer.Customer_Id__c && allRecords[i].objcustomer.Customer_Id__c.toUpperCase().indexOf(searchFilter) != -1 ))
                {
                    filtereddata.push(allRecords[i]);
                }
            }
            if(filtereddata.length == 0){
                component.set("v.bNoRecordsFound" , true);
            }else{
                component.set("v.bNoRecordsFound" , false);
                var pageSize = filtereddata.length;
                var PaginationLst = [];
                if(filtereddata.length > component.get("v.pageSize")){
                    pageSize = component.get("v.pageSize");
                }
                
                for(var i=0; i < pageSize; i++){
                    PaginationLst.push(filtereddata[i]);    
                }
                
                component.set("v.PaginationList",PaginationLst);
                component.set("v.totalRecordsCount", filtereddata.length);
                component.set("v.startPage",0);
                component.set("v.endPage",parseInt(pageSize) - parseInt(1));
                component.set("v.selectedCount" , 0);
                component.set("v.totalPagesCount", Math.ceil(parseInt(filtereddata.length) / parseInt(pageSize)));
            }
        } 
    },
    
    deleteSingleCust : function(component, event, helper, customerid){
        var action = component.get("c.deleteAllCustmers");
        var array = [customerid];
        action.setParams({ 
            "customerId": array
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Customer deleted successfully';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: message
                });
                toastEvent.fire();
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);  
    },
    deleteMultipleCustomer : function(component, event, helper,customerid){
        var action = component.get("c.deleteAllCustmers");
        action.setParams({ 
            "customerId": customerid
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Customer deleted successfully';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    message: message
                });
                toastEvent.fire();
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);  
    },
    
    synchelper : function(component,event,helper){
        var action = component.get("c.syncCustomers");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var message = 'Syncing started successfully.Please refresh page after some time';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!',
                    type: 'success',
                    duration:'7000',
                    message: message
                });
                toastEvent.fire();
                component.set("v.spinner", false);
                helper.doInitHelper(component, event);
            }
            else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action); 
    },
})
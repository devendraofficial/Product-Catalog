({
    doInit: function(component, event, helper) {
        helper.doInitHelper(component, event);
    },
    
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    
    openCustomerModalBox : function (component, event, helper){
        var modalboxcmp = component.find('customerModalBoxComponent');
        modalboxcmp.openmodalbox();
    },
    showfilterBox : function(component, event, helper){
        var divstate = component.get('v.showFilterDiv');
        if(divstate == 'slds-show'){
            component.set("v.showFilterDiv", "slds-hide");
        }else{
            component.set("v.showFilterDiv", "slds-show");
        }
    },
    
    //function for filter to show hide columns
    onCheckFilters: function(component, event, helper) {
        var value = event.getSource().get("v.text");
        
        if(value == 'LastName'){
            var abc =  component.get("v.LastName");
            if(abc == 'slds-show' ){
                component.set("v.LastName",'slds-hide');
            }else{
                component.set("v.LastName",'slds-show');
            }
        }else if(value == 'Age'){
            var abc =  component.get("v.Age");
            if(abc == 'slds-show' ){
                component.set("v.Age",'slds-hide');
            }else{
                component.set("v.Age",'slds-show');
            }
        }else if(value == 'Dateofbirth'){
            var abc =  component.get("v.Dateofbirth");
            if(abc == 'slds-show' ){
                component.set("v.Dateofbirth",'slds-hide');
            }else{
                component.set("v.Dateofbirth",'slds-show');
            }
        }else if(value == 'Gender'){
            var abc =  component.get("v.Gender");
            if(abc == 'slds-show' ){
                component.set("v.Gender",'slds-hide');
            }else{
                component.set("v.Gender",'slds-show');
            }
        }else if(value == 'CreatedDate'){
            var abc =  component.get("v.CreatedDate");
            if(abc == 'slds-show' ){
                component.set("v.CreatedDate",'slds-hide');
            }else{
                component.set("v.CreatedDate",'slds-show');
            }
        }else if(value == 'LastModifiedDate'){
            var abc =  component.get("v.LastModifiedDate");
            if(abc == 'slds-show' ){
                component.set("v.LastModifiedDate",'slds-hide');
            }else{
                component.set("v.LastModifiedDate",'slds-show');
            }
        }else if(value == 'Street'){
            var abc =  component.get("v.Street");
            if(abc == 'slds-show' ){
                component.set("v.Street",'slds-hide');
            }else{
                component.set("v.Street",'slds-show');
            }
        }else if(value == 'Country'){
            var abc =  component.get("v.Country");
            if(abc == 'slds-show' ){
                component.set("v.Country",'slds-hide');
            }else{
                component.set("v.Country",'slds-show');
            }
        }else if(value == 'Province'){
            var abc =  component.get("v.Province");
            if(abc == 'slds-show' ){
                component.set("v.Province",'slds-hide');
            }else{
                component.set("v.Province",'slds-show');
            }
        }else if(value == 'PostalCode'){
            var abc =  component.get("v.PostalCode");
            if(abc == 'slds-show' ){
                component.set("v.PostalCode",'slds-hide');
            }else{
                component.set("v.PostalCode",'slds-show');
            }
        }
    },
    
    /* javaScript function for pagination */
    navigation: function(component, event, helper) {
        var sObjectList = component.get("v.customerList");
        var end = component.get("v.endPage");
        var start = component.get("v.startPage");
        var pageSize = component.get("v.pageSize");
        var whichBtn = event.getSource().get("v.name");
        
        if (whichBtn == 'next') {
            component.set("v.currentPage", component.get("v.currentPage") + 1);
            helper.next(component, event, sObjectList);
        }
        
        else if (whichBtn == 'previous') {
            component.set("v.currentPage", component.get("v.currentPage") - 1);
            helper.previous(component, event, sObjectList, end, start, pageSize);
        }
    },
    
    selectAllCheckbox: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var updatedAllRecords = [];
        var updatedPaginationList = [];
        var listofcustomers = component.get("v.customerList");
        var PaginationList = component.get("v.PaginationList");
        
        for (var i = 0; i < listofcustomers.length; i++) {
            if (selectedHeaderCheck == true) {
                listofcustomers[i].isChecked = true;
                component.set("v.selectedCount", listofcustomers.length);
            } else {
                listofcustomers[i].isChecked = false;
                component.set("v.selectedCount", 0);
            }
            updatedAllRecords.push(listofcustomers[i]);
        }
        // update the checkbox for 'PaginationList' based on header checbox 
        for (var i = 0; i < PaginationList.length; i++) {
            if (selectedHeaderCheck == true) {
                PaginationList[i].isChecked = true;
            } else {
                PaginationList[i].isChecked = false;
            }
            updatedPaginationList.push(PaginationList[i]);
        }
        component.set("v.customerList", updatedAllRecords);
        component.set("v.PaginationList", updatedPaginationList);
    },
    
    checkboxSelect: function(component, event, helper) {
        // on each checkbox selection update the selected record count 
        var selectedRec = event.getSource().get("v.value");
        var getSelectedNumber = component.get("v.selectedCount");
        if (selectedRec == true) {
            getSelectedNumber++;
        } else {
            getSelectedNumber--;
            component.find("selectAllId").set("v.value", false);
        }
        component.set("v.selectedCount", getSelectedNumber);
        // if all checkboxes are checked then set header checkbox with true   
        if (getSelectedNumber == component.get("v.totalRecordsCount")) {
            component.find("selectAllId").set("v.value", true);
        }
    },
    
    handleShowEntry : function(component, event, helper) {
        var prodctlist = component.get('v.customerList');
        var pageSize = component.get("v.pageSize");
        var totalRecordsList = prodctlist;
        var totalLength = totalRecordsList.length ;
        component.set("v.totalRecordsCount", totalLength);
        component.set("v.startPage",0);
        component.set("v.endPage",pageSize-1);
        component.set("v.currentPage",1);
        
        var PaginationLst = [];
        for(var i=0; i < pageSize; i++){
            if(component.get("v.customerList").length > i){
                PaginationLst.push(prodctlist[i]);    
            } 
        }
        component.set('v.PaginationList', PaginationLst);
        component.set("v.selectedCount" , 0);
        component.set("v.totalPagesCount", Math.ceil(totalLength / pageSize));    
        
    },
    
    deleteSelectedRecords: function(component, event, helper) {
        var allRecords = component.get("v.customerList");
        var customerid = [];
        for (var i = 0; i < allRecords.length; i++) {
            if (allRecords[i].isChecked) {
                customerid.push(allRecords[i].objcustomer.Customer_Id__c);
            }
        }
        helper.deleteMultipleCustomer(component, event, helper,customerid);
    },
    
    previewcustomer: function(component, event, helper) {
        var url = event.target.getAttribute('data-value');
        var customerid = event.target.getAttribute('data-Id');
        var storeurl = String(url); 
        if(storeurl.includes("wpthemes")){
            window.open(storeurl+"/wp-admin/user-edit.php?user_id="+customerid, '_blank');
        }else if(storeurl.includes("myshopify")){
            window.open(storeurl+"/admin/customers/"+customerid, '_blank');
        }else{
            window.open(storeurl+"/admin/customer/index/edit/id/"+customerid, '_blank');
        }
        
    },
    
    deleteSinglecustomer :function(component, event, helper){
        var customerid =  event.getSource().get("v.value");
        helper.deleteSingleCust(component, event, helper, customerid);
    },
    
    doSearching: function(component, event, helper) {  
        helper.FilterRecords(component);  
    }, 
    
    SyncAllCustomers : function(component, event, helper) {  
        helper.synchelper(component);  
    },
})
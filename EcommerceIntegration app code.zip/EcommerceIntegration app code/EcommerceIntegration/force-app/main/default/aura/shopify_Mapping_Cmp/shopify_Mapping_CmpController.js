({
    doInit : function(component,event,helper){
        
        helper.fetchProductFields(component, event, helper);
        helper.fetchCustomerFields(component, event, helper);
        helper.fetchOrderFields(component, event, helper);
        helper.getAllMappings(component, event, helper);
    },
    
    showSpinner: function(component, event, helper) {
        component.set("v.spinner", true); 
    },
    
    hideSpinner : function(component,event,helper){
        component.set("v.spinner", false);
    },
    
    handleNext : function(component,event,helper){
        var getselectedStep = component.get("v.selectedStep");
        if(getselectedStep == "step1"){
            component.set("v.selectedStep", "step2");
        }
        else if(getselectedStep == "step2"){
            component.set("v.selectedStep", "step3");
        }
    },
    handlePrev : function(component,event,helper){
        var getselectedStep = component.get("v.selectedStep");
        if(getselectedStep == "step2"){
            component.set("v.selectedStep", "step1");
        }
        else if(getselectedStep == "step3"){
            component.set("v.selectedStep", "step2");
        }
    },
    closeModal: function(component, event, helper) {
        component.set("v.openModal", false);
        component.set("v.spinner", false);
    },
    showModal : function(component, event, helper) {
        var evtValue = event.getParam("modalValue");
        var evtValue2 = event.getParam("defaultAppName");
        component.set("v.defaultAppName",evtValue2);
        component.set("v.selectedStep", "step1");
        component.set("v.openModal", evtValue);
        helper.getAllMappings(component, event, helper);
    }, 
    
    saveDetails : function (component, event, helper){
        var process = true;
        
        //get product fields:
        var producttitle = component.get("v.producttitle");
        var productid = component.get("v.productid");
        var productprice = component.get("v.productprice");
        var productimageurl = component.get("v.productimageurl");
        var productcreateddate = component.get("v.productcreateddate");
        var productupdateddate = component.get("v.productupdateddate");
        var productdescription = component.get("v.productdescription");
        var productsku = component.get("v.productsku");
        
        //get customer fields:
        var customerfirstname = component.get("v.customerfirstname");
        var customeremail = component.get("v.customeremail");
        var customerid = component.get("v.customerid");
        var customerlastname = component.get("v.customerlastname");
        var customergender = component.get("v.customergender");
        var customerDOB = component.get("v.customerDOB");
        var customercity = component.get("v.customercity");
        var customerprovince = component.get("v.customerprovince");
        var customerstreet = component.get("v.customerstreet");
        var customerpostalcode = component.get("v.customerpostalcode");
        var customercountry = component.get("v.customercountry");
        var customercountrycode = component.get("v.customercountrycode");
        var customertelephone = component.get("v.customertelephone");
        var customercreateddate = component.get("v.customercreateddate");
        var customerupdateddate = component.get("v.customerupdateddate");
        
        //get order fields:
        var orderid = component.get("v.orderid");
        var ordername = component.get("v.ordername");
        var orderstatus = component.get("v.orderstatus");
        var orderquantity = component.get("v.orderquantity");
        var orderprice = component.get("v.orderprice");
        var ordertaxamount = component.get("v.ordertaxamount");
        var orderbillingaddress = component.get("v.orderbillingaddress");
        var ordershippingaddress = component.get("v.ordershippingaddress");
        var ordercustomername = component.get("v.ordercustomername");
        var ordercreateddate = component.get("v.ordercreateddate");
        var orderupdateddate = component.get("v.orderupdateddate");
        var orderdueamount = component.get("v.orderdueamount");
        var orderdiscount = component.get("v.orderdiscount");
        
        //check condition if field has value or not:
        
        if(producttitle == 'none' || producttitle == '' || producttitle == undefined){
            alert('please map product title');             
            process = false;
        }else if(productid == 'none' || productid == '' || productid == undefined){
            alert('please map product id');             
            process = false;
        }else if(productprice == 'none' || productprice == '' || productprice == undefined){
            alert('please map product price');             
            process = false;
        }else if(productimageurl == 'none' || productimageurl == '' || productimageurl == undefined){
            alert('please map product image URL');             
            process = false;
        }else if(productcreateddate == 'none' || productcreateddate == '' || productcreateddate == undefined){
            alert('please map product created date');             
            process = false;
        }else if(productupdateddate == 'none' || productupdateddate == '' || productupdateddate == undefined){
            alert('please map product updated date');             
            process = false;
        }else if(productdescription == 'none' || productdescription == '' || productdescription == undefined){
            alert('please map product description');             
            process = false;
        }else if(productsku == 'none' || productsku == '' || productsku == undefined){
            alert('please map product SKU');             
            process = false;
        }else if(customerfirstname == 'none' || customerfirstname == '' || customerfirstname == undefined){
            alert('please map customer firstname');            
            process = false;
        }else if(customeremail == 'none' || customeremail == '' || customeremail == undefined){
            alert('please map customer email');             
            process = false;
        }else if(customerid == 'none' || customerid == '' || customerid == undefined){
            alert('please map customer id');             
            process = false;
        }else if(customerlastname == 'none' || customerlastname == '' || customerlastname == undefined){
            alert('please map customer last name');             
            process = false;
        }else if(customergender == 'none' || customergender == '' || customergender == undefined){
            alert('please map customer gender');             
            process = false;
        }else if(customerDOB == 'none' || customerDOB == '' || customerDOB == undefined){
            alert('please map customer DOB');             
            process = false;
        }else if(customercity == 'none' || customercity == '' || customercity == undefined){
            alert('please map customer city');             
            process = false;
        }else if(customerprovince == 'none' || customerprovince == '' || customerprovince == undefined){
            alert('please map customer province');             
            process = false;
        }else if(customerstreet == 'none' || customerstreet == '' || customerstreet == undefined){
            alert('please map customer street');             
            process = false;
        }else if(customerpostalcode == 'none' || customerpostalcode == '' || customerpostalcode == undefined){
            alert('please map customer postal code');             
            process = false;
        }else if(customercountry == 'none' || customercountry == '' || customercountry == undefined){
            alert('please map customer country');             
            process = false;
        }else if(customercountrycode == 'none' || customercountrycode == '' || customercountrycode == undefined){
            alert('please map customer country code');             
            process = false;
        }else if(customertelephone == 'none' || customertelephone == '' || customertelephone == undefined){
            alert('please map customer telephone');             
            process = false;
        }else if(customercreateddate == 'none' || customercreateddate == '' || customercreateddate == undefined){
            alert('please map customer created date');             
            process = false;
        }else if(customerupdateddate == 'none' || customerupdateddate == '' || customerupdateddate == undefined){
            alert('please map customer updated date');             
            process = false;
        }else if(orderid == 'none' || orderid == '' || orderid == undefined){
            alert('please map order id');             
            process = false;
        }else if(ordername == 'none' || ordername == '' || ordername == undefined){
            alert('please map order name');             
            process = false;
        }else if(orderstatus == 'none' || orderstatus == '' || orderstatus == undefined){
            alert('please map order status');             
            process = false;
        }else if(orderquantity == 'none' || orderquantity == '' || orderquantity == undefined){
            alert('please map order quantity');             
            process = false;
        }else if(orderprice == 'none' || orderprice == '' || orderprice == undefined){
            alert('please map order price');             
            process = false;
        }else if(ordertaxamount == 'none' || ordertaxamount == '' || ordertaxamount == undefined){
            alert('please map order tax amount');             
            process = false;
        }else if(orderbillingaddress == 'none' || orderbillingaddress == '' || orderbillingaddress == undefined){
            alert('please map order billing address');            
            process = false;
        }else if(ordershippingaddress == 'none' || ordershippingaddress == '' || ordershippingaddress == undefined){
            alert('please map order shipping address');             
            process = false;
        }else if(ordercustomername == 'none' || ordercustomername == '' || ordercustomername == undefined){
            alert('please map order customer name');             
            process = false;
        }else if(ordercreateddate == 'none' || ordercreateddate == '' || ordercreateddate == undefined){
            alert('please map order created date');             
            process = false;
        }else if(orderupdateddate == 'none' || orderupdateddate == '' || orderupdateddate == undefined){
            alert('please map order updated date');             
            process = false;
        }else if(orderdueamount == 'none' || orderdueamount == '' || orderdueamount == undefined){
            alert('please map order due amount');             
            process = false;
        }else if(orderdiscount == 'none' || orderdiscount == '' || orderdiscount == undefined){
            alert('please map order discount');             
            process = false;
        }
        
        if(process){
            
            //close the modal box:
            component.set("v.openModal", false);
            
            // map product fields:
            var productMappings = {
                ProductName : producttitle,
                ProductID : productid,
                ProductPrice : productprice,
                ProductImageURL : productimageurl,
                ProductCreatedDate : productcreateddate,
                ProductUpdatedDate : productupdateddate,
                ProductDescription : productdescription,
                ProductSKU : productsku
            };
                        
            //map customer fields:
            var customerMappings = {
                CustomerFirstName : customerfirstname,
                CustomerEmail : customeremail,
                CustomerId : customerid,
                CustomerLastName : customerlastname,
                CustomerGender : customergender,
                CustomerDOB : customerDOB,
                CustomerCity : customercity,
                CustomerProvince : customerprovince,
                CustomerStreet : customerstreet,
                CustomerPostalCode : customerpostalcode,
                CustomerCountry : customercountry,
                CustomerCountryCode : customercountrycode,
                CustomerTelephone : customertelephone,
                CustomerCreatedDate : customercreateddate,
                CustomerUpdatedDate : customerupdateddate
            };
            
            
            //map order fields:
            var orderMappings = {
                OrderID : orderid,
                OrderName : ordername,
                OrderStatus : orderstatus,
                OrderQuantity : orderquantity,
                OrderPrice : orderprice,
                OrderTaxAmount : ordertaxamount,
                OrderBillingAddress : orderbillingaddress,
                OrderShippingAddress : ordershippingaddress,
                OrderCustomerName : ordercustomername,
                OrderCreatedDate : ordercreateddate,
                OrderUpdatedDate : orderupdateddate,
                OrderDueAmount : orderdueamount,
                OrderDiscount : orderdiscount
            };
            
            helper.saveMappings(component, event, helper, productMappings, customerMappings, orderMappings);
        }
    },
})
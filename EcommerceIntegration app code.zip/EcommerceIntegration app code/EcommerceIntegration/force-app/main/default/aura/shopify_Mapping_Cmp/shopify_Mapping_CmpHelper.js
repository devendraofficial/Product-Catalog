({
    getAllMappings : function(component, event, helper) {
        var action = component.get("c.getAllFieldMappings");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                    //var arrayMap = response.getReturnValue();
                    //var prodtMap = JSON.parse(arrayMap[0].replace(/&quot;/g,'"'));
                    //var custMap = JSON.parse(arrayMap[1].replace(/&quot;/g,'"'));
                    //var ordrMap = JSON.parse(arrayMap[2].replace(/&quot;/g,'"'));
                    
                    //set product mapping:
                    /*component.set("v.producttitle",prodtMap.ProductName);
                    component.set("v.productid",prodtMap.ProductID);
                    component.set("v.productprice",prodtMap.ProductPrice);
                    component.set("v.productimageurl",prodtMap.ProductImageURL);
                    component.set("v.productcreateddate",prodtMap.ProductCreatedDate);
                    component.set("v.productupdateddate",prodtMap.ProductUpdatedDate);
                    component.set("v.productdescription",prodtMap.ProductDescription);
                    component.set("v.productsku",prodtMap.ProductSKU);
                    
                    //set customer mapping:
                    component.set("v.customerfirstname",custMap.CustomerFirstName);
                    component.set("v.customeremail",custMap.CustomerEmail);
                    component.set("v.customerid",custMap.CustomerId);
                    component.set("v.customerlastname",custMap.CustomerLastName);
                    component.set("v.customergender",custMap.CustomerGender);
                    component.set("v.customerDOB",custMap.CustomerDOB);
                    component.set("v.customercity",custMap.CustomerCity);
                    component.set("v.customerprovince",custMap.CustomerProvince);
                    component.set("v.customerstreet",custMap.CustomerStreet);
                    component.set("v.customerpostalcode",custMap.CustomerPostalCode);
                    component.set("v.customercountry",custMap.CustomerCountry);
                    component.set("v.customercountrycode",custMap.CustomerCountryCode);
                    component.set("v.customertelephone",custMap.CustomerTelephone);
                    component.set("v.customercreateddate",custMap.CustomerCreatedDate);
                    component.set("v.customerupdateddate",custMap.CustomerUpdatedDate);
                    
                    //set order mapping:
                    component.set("v.orderid",ordrMap.OrderID);
                    component.set("v.ordername",ordrMap.OrderName);
                    component.set("v.orderstatus",ordrMap.OrderStatus);
                    component.set("v.orderquantity",ordrMap.OrderQuantity);
                    component.set("v.orderprice",ordrMap.OrderPrice);
                    component.set("v.ordertaxamount",ordrMap.OrderTaxAmount);
                    component.set("v.orderbillingaddress",ordrMap.OrderBillingAddress);
                    component.set("v.ordershippingaddress",ordrMap.OrderShippingAddress);
                    component.set("v.ordercustomername",ordrMap.OrderCustomerName);
                    component.set("v.ordercreateddate",ordrMap.OrderCreatedDate);
                    component.set("v.orderupdateddate",ordrMap.OrderUpdatedDate);
                    component.set("v.orderdueamount",ordrMap.OrderDueAmount);
                    component.set("v.orderdiscount",ordrMap.OrderDiscount);*/
                    
                    
                    //set product mapping:
                    component.set("v.producttitle",'Name');
                    component.set("v.productid",'Product_Id__c');
                    component.set("v.productprice",'Price__c');
                    component.set("v.productimageurl",'Product_ImageURL__c');
                    component.set("v.productcreateddate",'CreatedDate');
                    component.set("v.productupdateddate",'LastModifiedDate');
                    component.set("v.productdescription",'Product_Description__c');
                    component.set("v.productsku",'SKU__c');
                    
                    //set customer mapping:
                    component.set("v.customerfirstname",'Name');
                    component.set("v.customeremail",'Email__c');
                    component.set("v.customerid",'Customer_Id__c');
                    component.set("v.customerlastname",'Lastname__c');
                    component.set("v.customergender",'Gender__c');
                    component.set("v.customerDOB",'Date_Of_Birth__c');
                    component.set("v.customercity",'City__c');
                    component.set("v.customerprovince",'Province__c');
                    component.set("v.customerstreet",'Street__c');
                    component.set("v.customerpostalcode",'Postal_Code__c');
                    component.set("v.customercountry",'Country__c');
                    component.set("v.customercountrycode",'Region_Code__c');
                    component.set("v.customertelephone",'Telephone__c');
                    component.set("v.customercreateddate",'CreatedDate');
                    component.set("v.customerupdateddate",'LastModifiedDate');
                    
                    //set order mapping:
                    component.set("v.orderid",'Order_Id__c');
                    component.set("v.ordername",'Name');
                    component.set("v.orderstatus",'Order_Status__c');
                    component.set("v.orderprice",'Total_Price__c');
                    component.set("v.ordertaxamount",'Tax_Amount__c');
                    component.set("v.orderbillingaddress",'Billing_Address__c');
                    component.set("v.ordershippingaddress",'Shipping_Address__c');
                    component.set("v.ordercustomername",'Customer__c');
                    component.set("v.ordercreateddate",'CreatedDate');
                    component.set("v.orderupdateddate",'LastModifiedDate');
                    component.set("v.orderdueamount",'Due_Amount__c');
                    component.set("v.orderdiscount",'Discount__c');
                
                
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    fetchProductFields : function(component, event, helper) {
        var action = component.get("c.getProductFieldList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var arrayMap = response.getReturnValue();
                var prod = [];
                for(var key in arrayMap){
                    prod.push({value:arrayMap[key], key:key});
                }
                component.set("v.productFields", prod);
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchCustomerFields : function(component, event, helper) {
        var action = component.get("c.getCustomerFieldList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var arrayMap = response.getReturnValue();
                var cust = [];
                for(var key in arrayMap){
                    cust.push({value:arrayMap[key], key:key});
                }
                component.set("v.customerFields", cust);
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchOrderFields : function(component, event, helper) {
        var action = component.get("c.getOrderFieldList");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var arrayMap = response.getReturnValue();
                var ordr = [];
                for(var key in arrayMap){
                    ordr.push({value:arrayMap[key], key:key});
                }
                component.set("v.orderFields", ordr);
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
            }
        });
        $A.enqueueAction(action);
    },
    saveMappings : function (component, event, helper, productMappings, customerMappings, orderMappings){
        var action = component.get("c.saveAllMappings");
        action.setParams({
            "productMap": JSON.stringify(productMappings),
            "customerMap": JSON.stringify(customerMappings),
            "orderMap": JSON.stringify(orderMappings)
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Success!!',
                    type: 'success',
                    message: 'Mapping is saved successfully'
                });
                toastEvent.fire();
            }else {
                var errorMsg = action.getError()[0].message;
                helper.handleToast(component,event,helper,errorMsg);
                
                
            }
        });
        $A.enqueueAction(action);
    },
    
    handleToast : function(component,event,helper,errorMsg){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: 'Error',
            type: 'error',
            message: errorMsg
        });
        toastEvent.fire();
    },
})
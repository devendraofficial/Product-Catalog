({
    
    submitDetails : function(component, event, helper) {
        var prodct = component.get("v.prod");
        var process = false;
        component.set("v.isModalOpen", false);
        if(prodct.Name == '' || prodct.Name == undefined){
            alert('Please fill name');
        }else if(prodct.Price__c == '' || prodct.Price__c == undefined){
            alert('Please fill Price');
        }else if(prodct.Quantity__c == '' || prodct.Quantity__c == undefined){
            alert('Please fill Quantity');
        }else if(prodct.Product_Description__c == '' || prodct.Product_Description__c == undefined){
            alert('Please fill Description');
        }else{
            process = true;
        }
        
        if(process){
            var action = component.get("c.createNewProduct");
            action.setParams({ 
                "productsDetails": prodct
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var title = 'Success!';
                    var type = 'success';
                    var message = 'Product created successfully.'
                    var compEvent = component.getEvent("productComponentEvent"); 
                    compEvent.fire();
                    helper.handleToast(component,event,helper,title,type,message);
                    
                }else {
                    var title = 'Failed!';
                    var type = 'error';
                    var message = action.getError()[0].message;
                    helper.handleToast(component,event,helper,title,type,message);
                }
            });
            $A.enqueueAction(action);
        }
    },
    
    openModel: function(component, event, helper) {
        component.set("v.product",[]);
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        component.set("v.isModalOpen", false);
    },
})
({
    handleToast : function(component,event,helper,title,type,message){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title: title,
            type: type,
            message: message
        });
        toastEvent.fire();
    },
    searchHelper : function(component,event,getInputkeyWord) {
        var action = component.get("c.fetchLookUpValues");
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'ObjectName' : component.get("v.objectAPIName")
        });
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("mySpinner"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", '');
                }
                
                component.set("v.listOfSearchRecords", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    searchHelper2 : function(component,event,getInputkeyWord) {
        var action = component.get("c.fetchLookUpValues2");
        action.setParams({
            'searchKeyWord2': getInputkeyWord,
            'ObjectName2' : 'Customer__c'
        });
        action.setCallback(this, function(response) {
            $A.util.removeClass(component.find("mySpinner2"), "slds-show");
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                if (storeResponse.length == 0) {
                    component.set("v.Message2", 'No Result Found...');
                } else {
                    component.set("v.Message2", '');
                }
                
                component.set("v.listOfSearchRecords2", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
})
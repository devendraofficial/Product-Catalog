({
    
    submitDetails : function(component, event, helper) {
        component.set("v.isModalOpen", false);
        var ordrList = component.get("v.ordrMap");
        var prodrec = component.get("v.productList");
        var productarray = [];

        for (var i in prodrec) {
            productarray.push(JSON.stringify(prodrec[i]));
        }
        console.log(productarray);
        var custrec = component.get("v.selectedRecord2");
        var custID = custrec.Customer_Id__c;
        var total = component.get("v.totalPrice",total);
        var process = true;
        if(custID =='' || custID == undefined){
            alert('Please select the customer');
            process = false;
        }
        
        if(process){
            var action = component.get("c.createNewOrder");
            action.setParams({ 
                "ordersDetails": ordrList,
                "productMap" : prodrec,
                "customerId": custID,
                "totalprice": total
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.isModalOpen", false);
                    var title = 'Success!';
                    var type = 'success';
                    var message = 'Order record created successfully.'
                    component.set("v.productList",[]);
                    var compEvent = component.getEvent("orderComponentEvent"); 
                    compEvent.fire();
                    helper.handleToast(component,event,helper,title,type,message);
                }else {
                    component.set("v.isModalOpen", false);
                    
                    var title = 'Failed!';
                    var type = 'error';
                    var message = action.getError()[0].message;
                    helper.handleToast(component,event,helper,title,type,message);
                    
                }
            });
            $A.enqueueAction(action);
        }
        
    },
    
    openModel: function(component, event, helper) {
        component.set("v.order",[]);
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    addRow: function(component, event, helper) {
        var prodList = component.get("v.productList");
        var prodrec = component.get("v.selectedRecord");
        var qntity = component.get("v.inputQuantity");
        var selectedprod = prodrec.Name;
        var process = true;
        if(selectedprod == '' || selectedprod == undefined){
            alert('Please select Product');
            process = false;
        }else if(qntity =='' || qntity == 0 || qntity == undefined){
            alert('Please enter quantity');
            process = false;
        }
        
        if(process){
            prodList.push({
                'sobjectType': 'Product__c',
                'Name': selectedprod,
                'Quantity__c': qntity,
                'Price__c':prodrec.Price__c,
                'Product_Id__c': prodrec.Product_Id__c,
            });
            component.set("v.productList", prodList);

            var total = component.get("v.totalPrice");
            total = parseInt(total) + parseInt(qntity) * parseInt(prodrec.Price__c);
            component.set("v.totalPrice",total);
            var pillTarget = component.find("lookup-pill");
            var lookUpTarget = component.find("lookupField"); 
            
            $A.util.addClass(pillTarget, 'slds-hide');
            $A.util.removeClass(pillTarget, 'slds-show');
            
            $A.util.addClass(lookUpTarget, 'slds-show');
            $A.util.removeClass(lookUpTarget, 'slds-hide');
            
            component.set("v.SearchKeyWord",null);
            component.set("v.listOfSearchRecords", null );
            component.set("v.selectedRecord", {} ); 
            component.set("v.inputQuantity",'');
        }
        
    },
    removeRow: function(component, event, helper) {
        //Get the product list
        var prodList = component.get("v.productList");
        //Get the target object
        var selectedItem = event.currentTarget;
        //Get the selected item index
        var index = selectedItem.dataset.record;
        prodList.splice(index, 1);
        component.set("v.productList", prodList);
        var prodList = component.get("v.productList");
        var price = 0;
        var qntity = 0;
        for(var i in prodList){
           price = parseInt(price) +  parseInt(prodList[i].Price__c);
            qntity = parseInt(qntity) + parseInt(prodList[i].Quantity__c);
        }

        if(qntity == "" || qntity == undefined){
            qntity = 0;
        }
        var total = parseInt(qntity) * parseInt(price);
        component.set("v.totalPrice",total);
    },
    onfocus : function(component,event,helper){
        $A.util.addClass(component.find("mySpinner"), "slds-show");
        var forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
        var getInputkeyWord = '';
        helper.searchHelper(component,event,getInputkeyWord);
    },
    onblur : function(component,event,helper){       
        component.set("v.listOfSearchRecords", null );
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressController : function(component, event, helper) {
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord");
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },
    
    // function for clear the Record Selection 
    clear :function(component,event,heplper){
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
        component.set("v.selectedRecord", {} );   
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
        // get the selected Account record from the COMPONENT event 	 
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        component.set("v.selectedRecord" , selectedAccountGetFromEvent); 
        
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },
    
    
    onfocus2 : function(component,event,helper){
        $A.util.addClass(component.find("mySpinner2"), "slds-show");
        var forOpen = component.find("searchRes2");
        $A.util.addClass(forOpen, 'slds-is-open');
        $A.util.removeClass(forOpen, 'slds-is-close');
        // Get Default 5 Records order by createdDate DESC  
        var getInputkeyWord = '';
        helper.searchHelper2(component,event,getInputkeyWord);
    },
    onblur2 : function(component,event,helper){       
        component.set("v.listOfSearchRecords2", null );
        var forclose = component.find("searchRes2");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
    },
    keyPressController2 : function(component, event, helper) {
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord2");
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes2");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper2(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords2", null ); 
            var forclose = component.find("searchRes2");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
    },
    
    // function for clear the Record Selection 
    clear2 :function(component,event,heplper){
        var pillTarget = component.find("lookup-pill2");
        var lookUpTarget = component.find("lookupField2"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord2",null);
        component.set("v.listOfSearchRecords2", null );
        component.set("v.selectedRecord2", {} );   
    },
    
    // This function call when the end User Select any record from the result list.   
    handleComponentEvent2 : function(component, event, helper) {
        // get the selected Account record from the COMPONENT event 	 
        var selectedAccountGetFromEvent = event.getParam("recordByEvent2");
        component.set("v.selectedRecord2" , selectedAccountGetFromEvent); 
        
        var forclose = component.find("lookup-pill2");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        var forclose = component.find("searchRes2");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField2");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
        
    },
})
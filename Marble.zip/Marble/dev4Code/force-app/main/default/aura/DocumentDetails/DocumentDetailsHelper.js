({
    fetchData : function(component,event,helper) {		
        var action1 = component.get("c.getProDocumentsTypes");
        var val = component.get("v.recordId");

        action1.setParams({ LoanApplicationId : component.get("v.recordId"),Type :component.get('v.currentUserType')});
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               
  


                component.set('v.recoveredDocumentsBorrowerPrimary',response.getReturnValue().recDocBorrowerListPrimary);
                component.set('v.recoveredDocumentsBorrowerSecondary',response.getReturnValue().recDocBorrowerListSecondary);
                component.set('v.recoveredDocumentsBorrowerOther',response.getReturnValue().recDocBorrowerListOther);
                
                component.set('v.recoveredDocumentsCoBorrowerPrimary',response.getReturnValue().recDocCoBorrowerListPrimary); 
                component.set('v.recoveredDocumentsCoBorrowerSecondary',response.getReturnValue().recDocCoBorrowerListSecondary); 
                component.set('v.recoveredDocumentsCoBorrowerOther',response.getReturnValue().recDocCoBorrowerListOther); 
                
                
                component.set('v.recoveredDocumentsCoSignerPrimary',response.getReturnValue().recDocCoSignerListPrimary); 
                component.set('v.recoveredDocumentsCoSignerSecondary',response.getReturnValue().recDocCoSignerListSecondary); 
                component.set('v.recoveredDocumentsCoSignerOther',response.getReturnValue().recDocCoSignerListOther); 
                
                
                component.set('v.BorrowerReq',response.getReturnValue().recDocBorrowerListReqCount);
                component.set('v.CoBorrowerReq',response.getReturnValue().recDocCoBorrowerListReqCount);
                component.set('v.CoSignerReq',response.getReturnValue().recDocCoSignerListReqCount);
                
                component.set('v.userTypeList',response.getReturnValue().userTypeList); 
                component.set('v.recDocList',response.getReturnValue().recDocList); 
                

               var isFTB = response.getReturnValue().isFTB;
                var isFTCB = response.getReturnValue().isFTCB;  
                var isFTCS =response.getReturnValue().isFTCS;
            
                
                
                
                
                component.set('v.documentCategoryList',response.getReturnValue().documentCategoryList);
               	
                var documents = response.getReturnValue().documentList;
                var bsCount = 0;
                var piCount = 0;
                 var tiCount = 0;
                var oCount = 0;
                var recDocs = component.get('v.recDocList');
                recDocs.forEach(function(r){
                     console.log('1recdoc+'+r.DocumentType__c);           
                                })
                
         
				var cu = component.get('v.currentUserType');

                
                recDocs.forEach(function(rec){
                    var isAvail = false;
                    response.getReturnValue().pdList.forEach(function(rec1){
                        if(rec.DocumentType__c==rec1.DocumentType__c)
                            isAvail = true;
                    }) 
                    if(isAvail==false)
                    {

                        rec.IsNew = true;
                    }
                    else
                        rec.IsNew = false;
                })
                
                 recDocs.sort(function(a, b) {
                    var x = a.DocumentType__c.toLowerCase();
                    var y = b.DocumentType__c.toLowerCase(); 
                    if(x < y) {
                        return -1;
                    }
                    if(x > y) {
                        return 1;
                    }
                    return 0;
                });
                
                
                
                recDocs.sort(function(a, b) {
                    var x = a.IsRequired__c;
                    var y = b.IsRequired__c; 
                    return (x === y)? 0 : x? -1 : 1;
                   
                });
                
                
                recDocs.forEach(function(rec){
                    
                    if(rec.BorrowingStructure__r.Type__c=='COBORROWER')
                        component.set('v.isCoBorrowerExist',true);
                    if(rec.BorrowingStructure__r.Type__c=='COSIGNER')
                        component.set('v.isCoSignerExist',true);
                    
                })
                

                
                

		component.set('v.recDocList',recDocs);
                
                 
                var records = component.get('v.recDocList');
                var Bcount = 0;
                var CBcount = 0;
                var CScount = 0;
                records.forEach(function(Recs){

                    if(Recs.IsDocumentTypeReceived__c ==false && Recs.IsRequired__c == true && Recs.BorrowingStructure__r.Type__c=='BORROWER'  )
                    {
                        if(isFTB=='true')
                        {
                           if(Recs.DocumentType__c!='Three recent bank statements' && Recs.DocumentType__c!='Two pieces of ID')
                            Bcount = Bcount+1;
                        }
                        else
                        {
                        Bcount = Bcount+1;
                        }
                    }
                    else if (Recs.IsDocumentTypeReceived__c ==false && Recs.IsRequired__c == true && Recs.BorrowingStructure__r.Type__c=='COBORROWER'  )

                     if(isFTCB=='true')
                        {
                           if(Recs.DocumentType__c!='Three recent bank statements' && Recs.DocumentType__c!='Two pieces of ID')
                            CBcount = CBcount+1;
                        }
                        else
                        {
                        CBcount = CBcount+1;
                        }
                    else if (Recs.IsDocumentTypeReceived__c ==false && Recs.IsRequired__c == true && Recs.BorrowingStructure__r.Type__c=='COSIGNER' )
                       
                    
                    if(isFTCS=='true')
                        {
                           if(Recs.DocumentType__c!='Three recent bank statements' && Recs.DocumentType__c!='Two pieces of ID')
                             CScount = CScount+1;
                        }
                        else
                        {
                       CScount = CScount+1;
                        }
                })
                component.set('v.BorrowerReq',Bcount);
                component.set('v.CoBorrowerReq',CBcount);
                component.set('v.CoSignerReq',CScount);
                
                
               var selectedList = []; 
                 var val = component.get('v.currentUserType');
               recDocs.forEach(function(rec)
                               {
                                   if((rec.IsNew==true && rec.IsDocumentTypeReceived__c  == false && rec.BorrowingStructure__r.Type__c ==val) || (rec.IsDocumentTypeReceived__c  == false && rec.IsRequired__c == false && rec.DocumentRequested__c ==true && rec.IsNew==false && rec.BorrowingStructure__r.Type__c ==val ))
                                   {

                                       console.log('pushed'+rec.DocumentType__c);
                                        if(!selectedList.includes(rec.DocumentType__c))
                                       selectedList.push(rec.DocumentType__c);
                                   }
                           
                               }) 
               component.set('v.selectedDocuments',selectedList);
                 var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : selectedList });
            appEvent.fire();
                
                
                
       debugger
                
                
                
                
            }
        });
        $A.enqueueAction(action1);
        
    },
    updatepd:function(component,event,helper,val,docType)
    {
        
        var recDocId = component.get("v.recordId");;    
        var val1 = component.get("v.recordId");
        var userType = component.get('v.currentUserType');
        var action = component.get("c.updatePd");
        action.setParams({change:val,recDocId:recDocId,docType:docType,userType:userType});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
            }      
        });
        $A.enqueueAction(action);    
    }
    
    
})
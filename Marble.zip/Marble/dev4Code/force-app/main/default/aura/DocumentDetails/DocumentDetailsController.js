({
    doInit : function(component, event, helper) {
        helper.fetchData(component,event,helper);
    },
    tabChange: function(component, event, helper) {
        

        var selectedName = event.currentTarget.name;
        
        var tab1 = component.find(selectedName);
        
        $A.util.addClass(tab1, 'slds-active');
        
        
        component.set('v.currentUserType',selectedName);
        var appEvent = $A.get("e.c:changeUserTypeEvent");
        appEvent.setParams({
            "message" : selectedName });
        appEvent.fire();
    },
    borrowerTab: function(component, event, helper) {
        var selectedDocuments= [];
        component.set('v.selectedDocuments',selectedDocuments);
        
        var tab1 = component.find('borrowerId');
        var TabOnedata = component.find('borrowerDataId');
        
        var tab2 = component.find('coBorrowerId');
        var TabTwoData = component.find('coBorrowerDataId');
        
        var tab3 = component.find('coSignerId');
        var TabThreeData = component.find('coSignerDataId');
        //show and Active fruits tab
        $A.util.addClass(tab1, 'slds-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
        $A.util.removeClass(tab3, 'slds-active');
        $A.util.removeClass(TabThreeData, 'slds-show');
        $A.util.addClass(TabThreeData, 'slds-hide');
        component.set('v.currentUserType','BORROWER');
        var val = component.get('v.currentUserType');
        
        
        var appEvent = $A.get("e.c:changeUserTypeEvent");
        appEvent.setParams({
            "message" : "borrower" });
        appEvent.fire();
        
        var recDocs = component.get('v.recDocList');
          var selectedList = []; 
               recDocs.forEach(function(rec)
                               {
                                   if((rec.IsNew==true && rec.IsDocumentTypeReceived__c  == false && rec.BorrowingStructure__r.Type__c =='BORROWER') || (rec.IsDocumentTypeReceived__c  == false && rec.IsRequired__c == false && rec.DocumentRequested__c ==true && rec.IsNew==false && rec.BorrowingStructure__r.Type__c =='BORROWER' ))
                                   {

                                       console.log('pushed'+rec.DocumentType__c);
                                        if(!selectedList.includes(rec.DocumentType__c))
                                       selectedList.push(rec.DocumentType__c);
                                   }
                           
                               }) 
               component.set('v.selectedDocuments',selectedList);
                 var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : selectedList });
            appEvent.fire();
        
        
    },
    coBorrowerTab: function(component, event, helper) {
         var selectedDocuments= [];
        component.set('v.selectedDocuments',selectedDocuments);
        
        var tab1 = component.find('borrowerId');
        var TabOnedata = component.find('borrowerDataId');
        
        var tab2 = component.find('coBorrowerId');
        var TabTwoData = component.find('coBorrowerDataId');
        
        var tab3 = component.find('coSignerId');
        var TabThreeData = component.find('coSignerDataId');
        
        //show and Active tabs
        $A.util.addClass(tab2, 'slds-active');
        $A.util.removeClass(TabTwoData, 'slds-hide');
        $A.util.addClass(TabTwoData, 'slds-show');
        // Hide and deactivate others tab
        $A.util.removeClass(tab1, 'slds-active');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
        $A.util.removeClass(tab3, 'slds-active');
        $A.util.removeClass(TabThreeData, 'slds-show');
        $A.util.addClass(TabThreeData, 'slds-hide');
        
        component.set('v.currentUserType','COBORROWER');
        var val = component.get('v.currentUserType');
        
        
        var appEvent = $A.get("e.c:changeUserTypeEvent");
        appEvent.setParams({
            "message" : "coBorrower" });
        appEvent.fire();
        var recDocs = component.get('v.recDocList');
           var selectedList = []; 
               recDocs.forEach(function(rec)
                               {
                                   if((rec.IsNew==true && rec.IsDocumentTypeReceived__c  == false && rec.BorrowingStructure__r.Type__c =='COBORROWER') || (rec.IsDocumentTypeReceived__c  == false && rec.IsRequired__c == false && rec.DocumentRequested__c ==true && rec.IsNew==false && rec.BorrowingStructure__r.Type__c =='COBORROWER' ))
                                   {

                                       console.log('pushed'+rec.DocumentType__c);
                                        if(!selectedList.includes(rec.DocumentType__c))
                                       selectedList.push(rec.DocumentType__c);
                                   }
                           
                               }) 
               component.set('v.selectedDocuments',selectedList);
                 var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : selectedList });
            appEvent.fire();
        
    },
    coSignerTab: function(component, event, helper) {
        
         var selectedDocuments= [];
        component.set('v.selectedDocuments',selectedDocuments);
        
        var tab1 = component.find('borrowerId');
        var TabOnedata = component.find('borrowerDataId');
        
        var tab2 = component.find('coBorrowerId');
        var TabTwoData = component.find('coBorrowerDataId');
        
        var tab3 = component.find('coSignerId');
        var TabThreeData = component.find('coSignerDataId');
        
        //show and Active vegetables Tab
        $A.util.addClass(tab3, 'slds-active');
        $A.util.removeClass(TabThreeData, 'slds-hide');
        $A.util.addClass(TabThreeData, 'slds-show');
        // Hide and deactivate others tab
        // 
        $A.util.removeClass(tab2, 'slds-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
        
        $A.util.removeClass(tab1, 'slds-active');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
        
        component.set('v.currentUserType','COSIGNER');
        var val = component.get('v.currentUserType');
        
        
        var appEvent = $A.get("e.c:changeUserTypeEvent");
        appEvent.setParams({
            "message" : "coSigner" });
        appEvent.fire();
        var recDocs = component.get('v.recDocList');
          var selectedList = []; 
               recDocs.forEach(function(rec)
                               {
                                   if((rec.IsNew==true && rec.IsDocumentTypeReceived__c  == false && rec.BorrowingStructure__r.Type__c =='COSIGNER') || (rec.IsDocumentTypeReceived__c  == false && rec.IsRequired__c == false && rec.DocumentRequested__c ==true && rec.IsNew==false && rec.BorrowingStructure__r.Type__c =='COSIGNER' ))
                                   {

                                       console.log('pushed'+rec.DocumentType__c);
                                        if(!selectedList.includes(rec.DocumentType__c))
                                       selectedList.push(rec.DocumentType__c);
                                   }
                           
                               }) 
               component.set('v.selectedDocuments',selectedList);
                 var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : selectedList });
            appEvent.fire();
    },
    onClick:function(component,event,helper)
    {
       
        var val = event.getSource().get('v.checked');
        
        var docType =event.getSource().get('v.value').DocumentType__c;
        var required = event.getSource().get('v.value').IsRequired__c;
        var userType = event.getSource().get('v.value').BorrowingStructure__r.Type__c;
        
        console.log('docType'+docType+'required'+required+'userType'+userType);
        var selectedDocuments = component.get('v.selectedDocuments');
        
        if(val ==true)
        {
            
                    selectedDocuments.push(docType);
        component.set('v.selectedDocuments',selectedDocuments);
            console.log(selectedDocuments);
            
            var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : selectedDocuments });
            appEvent.fire();
        
        
        
        }
        else if(val == false)
        {
            var temp = [];
            selectedDocuments.forEach(function(rec)
                                      {
                                          if(rec!=docType)
                                          {
                                             temp.push(rec); 
                                          }
                                      })
            component.set('v.selectedDocuments',temp);
            console.log(temp);

 var appEvent = $A.get("e.c:changeDocumentListEvent");
            appEvent.setParams({
                "documentList" : temp });
            appEvent.fire();

        }
        
        
        
        
      /*  if(required==true)
        {
            var type = event.getSource().get('v.value').BorrowingStructure__r.Type__c;
            
            
            if(type=='BORROWER')
            {
                var count = component.get('v.BorrowerReq');
                
                if(val==true)
                    
                    count--;
                else
                    count++;
                
                component.set('v.BorrowerReq',count);
                
                
            }
            else if(type =='COBORROWER')
            {
                var count = component.get('v.CoBorrowerReq');
                if(val==true)
                    
                    count--;
                else
                    count++;
                component.set('v.CoBorrowerReq',count);
                
            }
                else if(type =='COSIGNER')
                {
                    var count = component.get('v.CoSignerReq');
                    if(val==true)
                        
                        count--;
                    else
                        count++;
                    component.set('v.CoSignerReq',count);
                    
                }
            
            
        }
        
        
        helper.updatepd(component,event,helper,val,docType) ;  */
         
    },
    handleBorrowerReq:function(component,event,helper)
    {
        var count = component.get('v.BorrowerReq');
        if(count==0)
        {
            component.set('v.isBorrowerReq',false);
            
        }
        else
            component.set('v.isBorrowerReq',true);
    },
    handleCoBorrowerReq:function(component,event,helper)
    {
        var count = component.get('v.CoBorrowerReq');
        if(count==0)
        {
            component.set('v.isCoBorrowerReq',false);
            
        }
        else
            component.set('v.isCoBorrowerReq',true);
    },
    handleCoSignerReq:function(component,event,helper)
    {
        var count = component.get('v.CoSignerReq');
        if(count==0)
        {
            component.set('v.isCoSignerReq',false);
            
        }
        else
            component.set('v.isCoSignerReq',true);
    },
    handleVerticalMenu:function(component,event,helper)
    {
        var tab = event.getParam("tab");
        if(tab=="documents"){
            component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false')
            
            },
    RefreshComponent:function(component,event,helper)
    {
      helper.fetchData(component,event,helper); 
    }    , 
    RefreshData:function(component,event,handler)
    {
    
      helper.fetchData(component,event,helper);  
}
     
    
})
({
    openModelEmail: function(component, event, helper) {
        console.log('EmailBox');
        component.set("v.isOpenEmail", true);
    },
    
    closeModelEmail: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        //component.set("v.isOpenEmail", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    
    SaveEmail: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        //alert('');
        //component.set("v.isOpenEmail", false);
        component.set("v.loading",true);
        helper.saveEmail(component, event, helper);
    },
    onTabChangeProfile: function(component, event, helper) {
        component.set("v.currentTab", 'Profile');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeCoBorrower: function(component, event, helper) {
        component.set("v.mainTabName", 'coborrower');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeCoSigner: function(component, event, helper) {
        component.set("v.mainTabName", 'cosigner');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeBorrower: function(component, event, helper) {
        component.set("v.mainTabName", 'borrower');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeAdditional: function(component, event, helper) {
        component.set("v.currentTab", 'Additional');
        helper.resetButtonVisiblility(component, event, helper); 
    },
    editboraddtional: function(component, event, helper) {
        alert("Your in Add");
    },
    openModelPhone: function(component, event, helper) {
        console.log('PhoneBox');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpenPhone", true);
    },
    
    closeModelPhone: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpenPhone", false);
    },
    
    SavePhone: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        //alert('');
        component.set("v.loading",true);
        helper.savePhone(component, event, helper);
        //component.set("v.isOpenPhone", false);
    },
    openModelAddress: function(component, event, helper) {
        console.log('PhoneBox');
        // for Display Model,set the "isOpen" attribute to "true"
        helper.fetchPicklistValues(component, event, helper, 'Province','Address__c','Province__c');
        component.set("v.isOpenAddress", true);
    },
    saveBorrowerBpa: function(component, event, helper) {
        console.log('saveBorrowerBpa');
         if(component.get('v.ftasa.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                    "type": "error",
                });
                toastEvent.fire();   
            }else if((component.get('v.ftasa.InConsumerProposal__c') =='NO' || component.get('v.ftasa.InConsumerProposal__c') =='') && component.get('v.ftasa.ConsumerProposalDate__c') != undefined){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                    "type": "error",
                });
                toastEvent.fire();
            }
            else{
                helper.updateBorrowerPreApproval(component, event, helper,'borrower');   
            }
        
    },
       saveCoBorrowerBpa: function(component, event, helper) {
         if(component.get('v.ftasaCoborrower.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                    "type": "error",
                });
                toastEvent.fire();   
            }else if((component.get('v.ftasaCoborrower.InConsumerProposal__c') =='NO' || component.get('v.ftasaCoborrower.InConsumerProposal__c') =='') && component.get('v.ftasaCoborrower.ConsumerProposalDate__c') != undefined){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                    "type": "error",
                });
                toastEvent.fire();
            }
            else{
                helper.updateBorrowerPreApproval(component, event, helper,'coborrower');   
            }
        
    },

    saveBorrowerBor: function(component, event, helper) {
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            helper.updateRecsBor(component, event, helper, 'borrower'); 
        }else if(currentActiveTab == 'coborrower'){
            helper.updateRecsBor(component, event, helper, 'coborrower'); 
        }else if(currentActiveTab == 'cosigner'){
            helper.updateRecsBor(component, event, helper, 'cosigner');
        }
    },
    closeModelAddress: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpenAddress", false);
    },
    
    SaveAddress: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        //alert('');
        component.set("v.loading",true);
        helper.saveAddress(component, event, helper);
    },
    openModelAddCoborrower: function(component, event, helper) {
        console.log('AddCoborrower');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set('v.loading',true);
        helper.fetchEmailTemplatesList(component, event, helper);
        component.set("v.isAddCoBorrower", true);
    },
    
    closeModelAddCoBorrower: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddCoBorrower", false);
    },
    
    SaveCoborrower: function(component, event, helper){
        var selectedAcc = component.get("v.selectedLookUpRecord");
        if(selectedAcc.Id == undefined){
            component.set("v.popupErrorMessage", 'Account is required');
            return;
        }
        var accountRecData = component.get("v.accountRec");
        if(accountRecData.FirstName == null || accountRecData.LastName == null  || accountRecData.PersonEmail == null  || accountRecData.Username__c == null ){
            component.set("v.popupErrorMessage", 'all fields are required');
            return;
        }
        component.set("v.popupErrorMessage", '');
        helper.AddCoBorrowerCoSigner(component,event,helper,'coborrower');      
        
    },
    openModelAddCoSigner: function(component, event, helper) {
        console.log('AddCoborrower');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isAddCoSigner", true);
    },
    
    closeModelAddCoSigner: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddCoSigner", false);
    },
    
    SaveCoSigner: function(component, event, helper) {
        var selectedAcc = component.get("v.selectedLookUpRecord");
        if(selectedAcc.Id == undefined){
            component.set("v.popupErrorMessage", 'Account is required');
            return;
        }
        var accountRecData = component.get("v.accountRec");
        if(accountRecData.FirstName == null || accountRecData.LastName == null  || accountRecData.PersonEmail == null  || accountRecData.Username__c == null ){
            component.set("v.popupErrorMessage", 'all fields are required');
            return;
        }
        //21-March Maanas        
        helper.AddCoBorrowerCoSigner(component,event,helper,'cosigner');
    },
    
    openModelRemoveCoBorrower: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isRemoveCoBorrower", true);
    },
    
    closeModelRemoveCoBorrower: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isRemoveCoBorrower", false);
    },
    
    RemoveCoborrower: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('');
        component.set("v.isRemoveCoBorrower", false);
    },
    openModelRemoveCoSigner: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isRemoveCoSigner", true);
    },
    
    closeModelRemoveCoSigner: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isRemoveCoSigner", false);
    },
    
    RemoveCoSigner: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('');
        component.set("v.isRemoveCoSigner", false);
    },
    
    openModelAddEmp: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isAddEmp", true);
    },
    
    closeModelAddEmp: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddEmp", false);
    },
    
    SaveAddEmp: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('');
        component.set("v.isAddEmp", false);
    },
    
    openModelAddLoanDebt: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isAddLoanDebt", true);
    },
    
    closeModelAddLoanDebt: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddLoanDebt", false);
    },
    
    SaveAddLoanDebt: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('');
        component.set("v.isAddLoanDebt", false);
    },
    
    
    
    
    
    doInit : function(component, event, helper) {
        
        var id = component.get('v.recordId');
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + today.getDate()); 
        helper.fetchWrapperData(component, event);
        var action = component.get("c.getCosigners");
        action.setParams({
            "applicationId": component.get('v.recordId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var cosMap = [];
                for(var key in result){
                    cosMap.push({label: result[key], value: key});
                }
                component.set("v.cosignerMap", cosMap);
            }
        });
        $A.enqueueAction(action);
    },
    
    editbq : function(component, event, helper) {
        
        if( component.get('v.bqappLabel') =='Save'){
            // helper.updateRecs(component, event);
        }else{
            component.set('v.bqviewmode',false);
            component.set('v.bqappLabel','Save');
        }
    },
    
    ftasaedit : function(component, event, helper) {
        if( component.get('v.ftasaLabel') =='Confirm'){
            if(component.get('v.ftasa.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                    "type": "error",
                });
                toastEvent.fire();   
            }else if((component.get('v.ftasa.InConsumerProposal__c') =='NO' || component.get('v.ftasa.InConsumerProposal__c') =='') && component.get('v.ftasa.ConsumerProposalDate__c') != undefined){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                    "type": "error",
                });
                toastEvent.fire();
            }
                else{
                    helper.updateRecs(component, event,'appSpecfic');    
                }
        }else{
            component.set('v.ftasaviewmode',false);
            component.set('v.ftasaLabel','Confirm');
        }
    },
    
    ftasacancel : function(component, event, helper) {
        component.set('v.ftasaviewmode',true);
        component.set('v.ftasaLabel','Edit');
    },
    
    editbpa : function(component, event, helper) {
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            component.set('v.bpaviewmode',false);
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.cobpaviewmode',false);
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosignerbpaviewmode',false);
        }
        component.set('v.showSaveButtonbpa',true);
        component.set('v.showEditBtnbpa',false);
        
    },
    editCobpa: function(component, event, helper) {
        //if(component.get('v.bpaappLabel') =='Confirm'){
        // helper.updateBorrowerPreApproval(component, event);            
        //}else{
        component.set('v.bpaviewmode',false);
        component.set('v.showEditBtnCobpa',false);
        component.set('v.showSaveButtonCobpa',true);
        //component.set('v.bpaappLabel','Confirm');
        //}
    },
    editCobor :  function(component, event, helper) {
        
        //if( component.get('v.cobappLabel') =='Save'){
        //helper.updateRecsBor(component, event,'coborrower');    
        //}else{
        component.set('v.cobviewmode',false);
        component.set('v.cobappLabel','Save');
        component.set('v.showSaveButtonCoBor',true);
        component.set('v.showEditBtnCoBor',false);
        //}
    },
    
    editbor:  function(component, event, helper) {
        //if( component.get('v.borappLabel') =='Save'){    
        //}else{
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            component.set('v.borviewmode',false);
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.cobviewmode',false);
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosviewmode',false);
        }
        component.set('v.showSaveButtonBor',true);
        component.set('v.showEditBtnBor',false);
        //component.set('v.borappLabel','Save');
        //}
        
    },
    
    editcos : function(component, event, helper) {
        
        if( component.get('v.cosappLabel') =='Save'){
            helper.updateRecsBor(component, event,'cosigner');    
        }else{
            component.set('v.cosviewmode',false);
            component.set('v.cosappLabel','Save');
        }        
    },
    
    cancelcos: function(component, event, helper) {
        component.set('v.cosviewmode',true);
        component.set('v.cosappLabel','Edit');
        
    },
    
    cancelbor : function(component, event, helper) {
        component.set('v.borviewmode',true);
        component.set('v.borappLabel','Edit');
    },
    
    cancelcob : function(component, event, helper) {
        component.set('v.cobviewmode',true);
        component.set('v.cobappLabel','Edit');
    },
    
    cancelbpa : function(component, event, helper) {
        component.set('v.bpaviewmode',true);
        component.set('v.bpaappLabel','Edit');
    },
    
    cancelbq : function(component, event, helper) {
        component.set('v.bqviewmode',true);
        component.set('v.bqappLabel','Edit');
    },
    
    handleOnSubmit : function(component, event, helper) {},
    
    handleOnSuccess : function(component, event, helper) {},
    
    handleOnError : function(component, event, helper) {},
    
    addcoborrower : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Borrower');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','coborrower');
    },
    
    addcosigner : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Signer');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','cosigner');
    },
    
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    submitDetails: function(component, event, helper) {
        
        var callApex=true;
        var lookup = (component.get('v.selectedLookUpRecord'));
        if(component.get('v.selectedradio') == 'search' && (component.get('v.selectedLookUpRecord').Id == undefined))
        {
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Email Cannot be left Blank!',
                "type": "error"
            });
            toastEvent.fire();
        }else if (component.get('v.selectedradio') == 'add' && (component.get('v.accountRec.FirstName') =='' || component.get('v.accountRec.LastName') =='' ||  component.get('v.accountRec.PersonEmail') =='')) {
            
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Fill All Required Fields!',
                "type": "error"
            });
            toastEvent.fire();
        }
        
        
        if(callApex){ 
            if(component.get('v.apptype') =='cosigner'){
                var accrecord = component.get('v.accountRec');
                accrecord.IsActive__pc =true;
                component.set('v.accountRec',accrecord);
            }
            console.log(component.get('v.accountRec'));
            var action = component.get("c.createUpdateAccount");
            action.setParams({
                "existingAccount": component.get('v.selectedLookUpRecord'),
                "newRec": component.get('v.accountRec'),
                "applicantType" : component.get('v.apptype'),
                "applicationId" : component.get('v.recordId')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var recId = response.getReturnValue();
                    if(recId == 'fail'){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Add Failed: User Already Present as Borrower/Co-Borrower/Co-Signer!',
                            "type": "error",
                        });
                        toastEvent.fire();
                    }else{
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Added Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                        };
                        navLink.navigate(pageRef, true);
                        //  $A.get('e.force:refreshView').fire();
                        component.set("v.isModalOpen", false);
                    }
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    var finalErrorMessage;
                    if (errors) {
                        var databaseError = errors[0].message;
                        if(databaseError.includes("A9A"))
                            finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                        else
                            finalErrorMessage =  databaseError;
                        
                        
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": finalErrorMessage,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
        }
    },
    
    onGroup: function(component, event) {
        
        if(component.get('v.selectedradio') =='search'){
            var acc = component.get('v.accountRec');
            acc.FirstName='';
            acc.LastName='';
            acc.PersonEmail='';
            component.set('v.accountRec',acc);
            
        }else if(component.get('v.selectedradio') =='add'){
            component.set('v.selectedLookUpRecord',null);
        }
        
    },
    
    handleSaveEdition: function(component, event, helper) {
        var draftValues = event.getParam('draftValues');
        console.log(draftValues);
        var callApex=true;
        var action = component.get("c.updateRecords");
        action.setParams({"sobjList" : draftValues, "toUpateApplication" : false, "appRecord" :undefined});
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (component.isValid() && state === "SUCCESS") {
                helper.fetchWrapperData(component, event);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Updated Successfully!',
                    "type": "success",
                });
                toastEvent.fire();    
            } else if (state === "ERROR") {
                var errors = action.getError();
                var finalmessage='';
                if (errors) {
                    if( errors[0].message.includes('Province: bad value for restricted picklist field' ) )
                        finalmessage= 'Invalid Province. Only AB, BC, MB, NB, NL, NS, NT, NU, ON, PE, QC, SK, YT Allowed';
                    else if(errors[0].message.includes('A person should have only one primary address'))
                        finalmessage = 'A person should have only one primary address';
                    //  else if(errors[0].message.includes('duplicate value found: EmailAddress__c')){
                    //    finalmessage = 'Duplicate Email Entered For User';
                    //  }
                        else if(errors[0].message.includes('Employment Start Month: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Month can only Be January,February,March,April,May,June,July,August,Septemeber,October,November,December';
                        }else if(errors[0].message.includes('Employment Start Year: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Year Can only be of format 2000, 2001, 2002...';
                        }
                            else
                                finalmessage = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalmessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }            
        });
        $A.enqueueAction(action);
    },
    
    viewInactivecos :  function(component, event, helper) {
        component.set('v.isModalOpenCos',true);
    },
    
    closecosModel :  function(component, event, helper) {
        component.set('v.isModalOpenCos',false);
    },
    
    addAddress : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        /*   var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();            	
        }else if(addAdress =='coborroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
        }else if(addAdress =='cosigneraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
            
        }*/
        var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            let borrower = component.get('v.borrower');
            component.set('v.reqAccId',borrower.Id);
        }else if(addAdress =='coborroweraddress'){
            let coborrower = component.get('v.coborrower');
            component.set('v.reqAccId',coborrower.Id);
        }else if(addAdress =='cosigneraddress'){
            let cosigner = component.get('v.activecosigner');
            component.set('v.reqAccId',cosigner.Id);
        }
        
        component.set('v.showAddAddressCMP',true);
        
    },
    
    addEmail : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var email = event.getSource().getLocalId();
        if(email =='borroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();            	
        }else if(email =='coborroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();
            
        }else if(email =='cosigneremail'){
            var createEmail = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();  
        }
    },
    
    addPhone : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var phone = event.getSource().getLocalId();
        if(phone =='borrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();            	
        }else if(phone =='coborrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();
            
        }else if(phone =='cosignerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();  
        }
    },
    
    addEmployment : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var emp = event.getSource().getLocalId();
        if(emp =='borroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();            	
        }else if(emp =='coborroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();
            
        }else if(emp =='cosigneremp'){
            var createEmp = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();  
        }
    },
    
    sendconnecturl : function(component, event, helper) {
        
        var action = component.get("c.getBankUrl");
        action.setParams({
            "applicationId": component.get('v.recordId'),                
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "Bank Connection URL Sent Successfully!",
                    "type": "success"
                });
                toastEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                if (errors) {
                    var databaseError = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": databaseError,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action);   
        
    },
    
    checkValidity : function(component, event, helper) {
        var validity = event.getSource().get("v.validity");
        console.log(validity)
    },
    
    checkReason :  function(component, event, helper) {
        if(component.get('v.applicationRec.ApplicationStatus__c') =='Rejected')
            component.set('v.showReason',true);
        else
            component.set('v.showReason',false);
    },
    
    activatecos : function(component, event, helper) {
        component.set('v.showActivateCosScreen',true);
        component.set('v.isModalOpenCos',false);
    },
    
    closecosaModel :function(component, event, helper) {
        component.set('v.showActivateCosScreen',false);
        component.set('v.cos','');
    },
    
    activateCosigner : function(component, event, helper) {
        var callApex =true;
        if(component.get('v.cos') == undefined || component.get('v.cos') =='' ){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Select Atleast One Co-Signer',
                "type": "error",
            });
            toastEvent.fire();
        }else{
            
            var action = component.get("c.updateActiveCosigner");
            action.setParams({
                "idToActivate": component.get('v.cos'),
                "activecos": component.get('v.activecosigner')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    component.set('v.loading',true);
                    
                    
                    window.setTimeout(
                        $A.getCallback(function() {
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Success!",
                                "message": 'Co-Signer Activated!',
                                "type": "success",
                            });
                            toastEvent.fire();
                            component.set("v.loading",false);
                            location.reload(true);
                        }), 3000
                    );
                    component.set('v.showActivateCosScreen',false);
                    
                    
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    if (errors) {
                        var databaseError = errors[0].message;
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": databaseError,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
            
        }
    },
    handleVerticalMenu:function(component,event,helper)
    {
        var tab = event.getParam("tab");
        
        
        if(tab=="documents")
        {
            
            component.set('v.isVisible','false');
        }
        else
            component.set('v.isVisible','true');
        
    },
    cancelSave : function(component,event,helper){
        helper.resetButtonVisiblility(component,event,helper);
    },
    showTemplateBody:function(component,event,helper){
        component.set('v.loading','true');
        helper.fetchTemplateBody(component,event,helper);
    }
})
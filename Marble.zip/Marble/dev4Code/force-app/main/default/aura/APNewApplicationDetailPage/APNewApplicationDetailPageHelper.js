({
    fetchWrapperData : function(component, event) {
        
        component.set('v.addressColumns', [
            {label: 'STREET ADDRESS', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'CITY', fieldName: 'City__c', type: 'text'},
            {label: 'COUNTRY', fieldName: 'Country__c', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true},
            {label: 'MOVED IN', fieldName: '', type: 'text'},
            {label: 'MOVED OUT', fieldName: '', type: 'text'}
        ]);
        
        component.set('v.emailColumns', [
           // {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'ADDRESS', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.phoneColumns', [
            {label: 'TYPE', fieldName: 'PhoneType__c', type: 'text'},
            {label: 'NUMBER', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.empColumns', [
            {label: 'COMPANY', fieldName: '', type: 'text'},
            {label: 'JOB TITLE', fieldName: '', type: 'text'},
            {label: 'START DATE', fieldName: '', type: 'text'},
            {label: 'END DATE', fieldName: '', type: 'text'},
            {label: 'FIRST JOB', fieldName: '', type: 'text'}
            //{label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
           // {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            //{label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        
        component.set('v.coaddressColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Street Address', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true}
        ]);
        
        component.set('v.coemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.cophoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.coempColumns', [
            {label: 'Company', fieldName: 'Name', type: 'text'},
            {label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
            {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            {label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        
        component.set('v.cosaddressColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Street Address', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true}
        ]);
        
        component.set('v.cosemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.cosphoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.cosLoanDebtColumns', [
            {label: 'LOAN/DEBT TYPE', fieldName: '', type: 'text'},
            {label: 'GRANTOR', fieldName: '', type: 'text', editable: true},
            {label: 'MONTHLY PAYMENT', fieldName: '' , type: 'text', editable: true},
            {label: 'OUTSTANDING BALANCE', fieldName: '' , type: 'text', editable: true}
        ]);
        
        component.set('v.cosempColumns', [
            {label: 'Company', fieldName: 'Name', type: 'text'},
            {label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
            {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            {label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        var recId = component.get('v.recordId');
        var action = component.get("c.getApplicationData");
        action.setParams({
            "appId": recId
        });
        action.setCallback(this, function(response){
            console.log("Action Called");
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.applicationWrapper", response.getReturnValue());
                var applicationwrapper = response.getReturnValue();
                console.log("Value of Consent : "+applicationwrapper.ConsentOfBorrowerTest);
                if(applicationwrapper != null ){
                    var applicationRec = applicationwrapper.ApplicationDetail;
                    component.set('v.currentApplicationStatus', applicationRec.ApplicationStatus__c);
                    //   component.set('v.currentLoanAmount',applicationRec.LoanAmount__c);
                    var borrower = applicationwrapper.Borrower;
                    var coborrower = applicationwrapper.CoBorrower;
                    var cosigners = applicationwrapper.CoSigner;
                    var fastappsapp ;
                    var autofastapp;
                    var fastappsappcob ;
                    var autofastappcob;
                    var fastappsappcos ;
                    var autofastappcos;
                    var ftasaList = applicationwrapper.FastTrackAppSpecficApplicant;
                    console.log('fasttrackonscreen');
                     console.log(JSON.stringify(ftasaList));
                    ftasaList.forEach(function(record){ 
                        if(record.BorrowingStructure__r.Type__c == 'BORROWER'){
                        	if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                            	component.set('v.ftasa', record)
                            	fastappsapp = record;
                        	}else{
                            	component.set('v.ftasaAutomatic', record);
                            	autofastapp = record;
                        	}  
                        }else if(record.BorrowingStructure__r.Type__c == 'COBORROWER'){
                        	if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                            	component.set('v.ftasaCoborrower', record)
                            	fastappsappcob = record;
                        	}else{
                            	component.set('v.ftasaAutomaticCoborrower', record);
                            	autofastappcob = record;
                        	}  
                        }else if(record.BorrowingStructure__r.Type__c == 'COSIGNER'){
                        	if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                            	component.set('v.ftasaCosigner', record)
                            	fastappsappcos = record;
                        	}else{
                            	component.set('v.ftasaAutomaticCosigner', record);
                            	autofastappcos = record;
                        	}  
                        }
                        
                    }); 
                    
                    component.set('v.applicationRec',applicationRec);
                    component.set('v.borrower',borrower[0]);
                    component.set('v.coborrower',coborrower[0]);
                    component.set('v.cosigners', cosigners);
                    
                    //Manual// Auto Entry for borrower
                    if(fastappsapp != null && fastappsapp != '' && fastappsapp !='undefined' ){
                        if(autofastapp != null && autofastapp != '' && autofastapp !='undefined' ){
                            if(!fastappsapp.ManualUpdate__c){
                                fastappsapp.InConsumerProposal__c = autofastapp.InConsumerProposal__c;
                                fastappsapp.ConsumerProposalDate__c = autofastapp.ConsumerProposalDate__c;
                            }   
                            if(!fastappsapp.ManualPreApproval__c){
                                fastappsapp.ConsumerLoanAmount__c = autofastapp.ConsumerLoanAmount__c;
                                fastappsapp.PayPerCheque__c = autofastapp.PayPerCheque__c;
                                fastappsapp.MonthsAtCurrentJob__c = autofastapp.MonthsAtCurrentJob__c;
                                fastappsapp.PayFrequency__c = autofastapp.PayFrequency__c;
                                fastappsapp.HasActivePaydayLoans__c = autofastapp.HasActivePaydayLoans__c;
                                fastappsapp.HasMoreThanThreeNSFs__c = autofastapp.HasMoreThanThreeNSFs__c;
                            }
                        }
                        /*MD01 component.set('v.jointproposal',fastappsapp.JointProposal__c);*/
                        /*MD01	component.set('v.consumerproposal',fastappsapp.InConsumerProposal__c);*/
                        component.set('v.ftasa',fastappsapp );
                        console.log(JSON.stringify(component.get('v.ftasa')));
                    }
                    
                       //Manual// Auto Entry for coborrower
                    if(fastappsappcob != null && fastappsappcob != '' && fastappsappcob !='undefined' ){
                        if(autofastappcob != null && autofastappcob != '' && autofastappcob !='undefined' ){
                            if(!fastappsappcob.ManualUpdate__c){
                                fastappsappcob.InConsumerProposal__c = autofastappcob.InConsumerProposal__c;
                                fastappsappcob.ConsumerProposalDate__c = autofastappcob.ConsumerProposalDate__c;
                            }   
                            if(!fastappsappcob.ManualPreApproval__c){
                                fastappsappcob.ConsumerLoanAmount__c = autofastappcob.ConsumerLoanAmount__c;
                                fastappsappcob.PayPerCheque__c = autofastappcob.PayPerCheque__c;
                                fastappsappcob.MonthsAtCurrentJob__c = autofastappcob.MonthsAtCurrentJob__c;
                                fastappsappcob.PayFrequency__c = autofastappcob.PayFrequency__c;
                                fastappsappcob.HasActivePaydayLoans__c = autofastappcob.HasActivePaydayLoans__c;
                                fastappsappcob.HasMoreThanThreeNSFs__c = autofastappcob.HasMoreThanThreeNSFs__c;
                            }
                        }
                        component.set('v.ftasaCoborrower',fastappsappcob );
                        console.log(JSON.stringify(component.get('v.ftasaCoborrower')));
                    }
                    
                    //Manual// Auto Entry for cosigner
                    if(fastappsappcos != null && fastappsappcos != '' && fastappsappcos !='undefined' ){
                        if(autofastappcos != null && autofastappcos != '' && autofastappcos !='undefined' ){
                            if(!fastappsappcos.ManualUpdate__c){
                                fastappsappcos.InConsumerProposal__c = autofastappcos.InConsumerProposal__c;
                                fastappsappcos.ConsumerProposalDate__c = autofastappcos.ConsumerProposalDate__c;
                            }   
                            if(!fastappsappcos.ManualPreApproval__c){
                                fastappsappcos.ConsumerLoanAmount__c = autofastappcos.ConsumerLoanAmount__c;
                                fastappsappcos.PayPerCheque__c = autofastappcos.PayPerCheque__c;
                                fastappsappcos.MonthsAtCurrentJob__c = autofastappcos.MonthsAtCurrentJob__c;
                                fastappsappcos.PayFrequency__c = autofastappcos.PayFrequency__c;
                                fastappsappcos.HasActivePaydayLoans__c = autofastappcos.HasActivePaydayLoans__c;
                                fastappsappcos.HasMoreThanThreeNSFs__c = autofastappcos.HasMoreThanThreeNSFs__c;
                            }
                        }
                        component.set('v.ftasaCosigner',fastappsappcos );
                        console.log(JSON.stringify(component.get('v.ftasaCosigner')));
                    }
                    
                    if(borrower != null && borrower != '' && borrower !='undefined' ){
                        component.set('v.addressList', borrower[0].Addresses__r);
                        component.set('v.borrowerconsent',applicationwrapper.ConsentOfBorrower);
                        component.set('v.previousborrowerconsent',applicationwrapper.ConsentOfBorrower);
                        component.set('v.emailList', borrower[0].Emails__r);
                        component.set('v.phoneList', borrower[0].Phones__r);
                        component.set('v.empList', borrower[0].Employments__r);
                    }
                    
                    if(coborrower != null && coborrower != '' && coborrower !='undefined'){  
                        component.set('v.coborrowerconsent',applicationwrapper.ConsentOfCoBorrower);
                        component.set('v.previouscobrwconsent',coborrower[0].Consent__pc);                        
                        component.set('v.coaddressList', coborrower[0].Addresses__r);                    
                        component.set('v.coemailList', coborrower[0].Emails__r);                    
                        component.set('v.cophoneList', coborrower[0].Phones__r);                    
                        component.set('v.coempList', coborrower[0].Employments__r);
                    }
                    
                    if(cosigners != null && cosigners != undefined){
                        var inactivecos =[]
                        var activecos;
                        cosigners.forEach(function(record){ 
                                component.set('v.activecosigner',record);
                                activecos = record                                                         
                        }); 
                        if(activecos != null && activecos != undefined){
                            component.set('v.cosignerconsent',applicationwrapper.ConsentOfCoSigner);
                            component.set('v.cosaddressList', activecos.Addresses__r);                    
                            component.set('v.cosemailList', activecos.Emails__r);                    
                            component.set('v.cosphoneList', activecos.Phones__r);                    
                            component.set('v.cosempList', activecos.Employments__r);
                        }
                        
                    }
                    
                }
                
            }
        });
        $A.enqueueAction(action);
        
    },
    
    updateRecs : function(component, event, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            coborrowr.Consent__pc = component.get('v.coborrowerconsent');
            objList.push(coborrowr);
            
        }else if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            console.log(JSON.stringify(borrowr));
            var previousconsent = component.get('v.previousborrowerconsent');
            borrowr.Consent__pc = component.get('v.borrowerconsent');
            if(previousconsent != component.get('v.borrowerconsent') ){
                updateApplication =true;
            }
            
            objList.push(borrowr);    
            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            cosignr.Consent__pc = component.get('v.cosignerconsent');
            objList.push(cosignr);        
        }else if(rectype =='appSpecfic'){
            var appsepcRec = component.get('v.ftasa');
            /* MD01 appsepcRec.JointProposal__c = component.get('v.jointproposal');*/
            /** MD01 appsepcRec.InConsumerProposal__c = component.get('v.consumerproposal');*/
            appsepcRec.MunualUpdate__c =true;
            objList.push(appsepcRec);
        }
        console.log(JSON.stringify(appsepcRec));
        var action = component.get("c.updateRecords");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        //  window.open('/'+ component.get('v.recordId'),'_self');
                        location.reload(true);
                    }), 5000
                );
                
                
                if(accType =='coborrower'){
                    component.set('v.cobviewmode',true);
                    component.set('v.cobappLabel','Edit');
                }
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
                
                if(accType =='cosigner' ){
                    component.set('v.cosviewmode',true);
                    component.set('v.cosappLabel','Edit');
                }
                
                if(accType =='appSpecfic' ){
                    component.set('v.ftasaviewmode',true);
                    component.set('v.ftasaLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    updateBorrowerPreApproval : function(component, event, helper) {
        
        var currentApplication = component.get('v.applicationRec');
        var updateApp = false;
        var objList = [];
        if(component.get('v.currentApplicationStatus') != currentApplication.ApplicationStatus__c){
            updateApp = true;
            
        }
        
        var fastTrackApp = component.get('v.ftasa');
        console.log(JSON.stringify(fastTrackApp));
        
        if(fastTrackApp.EmploymentStartDate__c != null){
            var res = fastTrackApp.EmploymentStartDate__c.split("-");
            console.log(res);
            
            fastTrackApp.EmploymentStartMonth__c = res[1];
            fastTrackApp.EmploymentStartYear__c = res[0];
        }
        
        console.log(JSON.stringify(fastTrackApp));
        fastTrackApp.ManualPreApproval__c =true;
        objList.push(fastTrackApp);
        var borrower = component.get('v.borrower');
        if(borrower.NumberOfDependents__pc != null){
              
            delete borrower["Name"]
            objList.push(borrower);
        }
 		
        var previousborrconsent = component.get('v.previousborrowerconsent');
        var borrowerconsent = component.get('v.borrowerconsent');
        
        if(previousborrconsent != borrowerconsent && borrowerconsent){
            var action1 = component.get("c.insertConsent");
                action1.setParams({
            "acc": borrower,
            "applcation": currentApplication,
            "borrowerConsent" : true,
			"coborrowerConsent": false,
             "cosignerConsent": false                    
        });
              
         action1.setCallback(this, function(response){
            var state1 = response.getState();
            if (component.isValid() && state1 === "SUCCESS") {
                              
            }
            else if (state1 === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action1);     
    	}
        
        var action = component.get("c.updateFastTrack");
        action.setParams({
            "sobjList": objList ,
            "application": currentApplication,
            "updateApplication": updateApp
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                
                window.setTimeout(
                    $A.getCallback(function() {
                        component.set("v.loading",false);
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        location.reload(true);
                    }), 7000
                );
                if(accType =='coborrower'){
                    component.set('v.bpaviewmode',true);
                    component.set('v.bpaappLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    updateRecsBor : function(component, event,helper, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        var consent1 =false;
        if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            delete borrowr["Name"];
            objList.push(borrowr);                
        }else if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            delete coborrowr["Name"];
            objList.push(coborrowr);            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            delete cosignr["Name"];
            objList.push(cosignr);        
        }
        
        var action = component.get("c.updateRecordsBor");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec'),
            "ftapp" : component.get('v.ftasa'),
            "consent": consent1
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        //  window.open('/'+ component.get('v.recordId'),'_self');
                        location.reload(true);
                    }), 5000
                );
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    saveEmail : function(component, event, helper){
        var action = component.get("c.addNewEmail");
        var currentEmailObj = component.get('v.newEmailObj');
        var currentActiveTab = component.get("v.mainTabName");
        var allEmailList = [];
        if(currentActiveTab == 'borrower'){
            allEmailList = component.get('v.emailList');
        }else if(currentActiveTab == 'coborrower'){
            allEmailList = component.get('v.coemailList');
        }else if(currentActiveTab == 'cosigner'){
            allEmailList = component.get('v.cosemailList');
        }
        
        if(allEmailList.length == 0){
            component.set('v.popupErrorMessage','Account Id is required');
            return;
        }else if(currentEmailObj.emailAddress__c == ''){
            component.set('v.popupErrorMessage','Email address is required');
            return;
        }else if(currentEmailObj.IsPrimary__c == ''){
            component.set('v.popupErrorMessage','Active is required');
            return;
        }
        currentEmailObj.Account__c = allEmailList[0].Account__c;
        action.setParams({
            "emailObj" : currentEmailObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Email added successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        allEmailList.push(res.data.result);
                        if(currentActiveTab == 'borrower'){
                            component.set('v.emailList',allEmailList);
                        }else if(currentActiveTab == 'coborrower'){
                            component.set('v.coemailList',allEmailList);
                        }else if(currentActiveTab == 'cosigner'){
                            component.set('v.cosemailList',allEmailList);
                        }
                        helper.resetPopUpErrorMessage(component, event, helper);
                        helper.clearEmailPopUpsValues(component, event, helper);
                    }else if(res.status == 'failed'){
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    savePhone : function(component, event, helper){
        var action = component.get("c.addNewPhone");
        var currentObj = component.get('v.newPhoneObj');
        var currentActiveTab = component.get("v.mainTabName");
        var allPreviousList = [];
        if(currentActiveTab == 'borrower'){
            allPreviousList = component.get('v.phoneList');
        }else if(currentActiveTab == 'coborrower'){
            allPreviousList = component.get('v.cophoneList');
        }else if(currentActiveTab == 'cosigner'){
            allPreviousList = component.get('v.cosphoneList');
        }
        if(allPreviousList.length == 0){
            component.set('v.popupErrorMessage','Account Id is required');
            return;
        }else if(currentObj.PhoneType__c == ''){
            component.set('v.popupErrorMessage','Phone type is required');
            return;
        }else if(currentObj.IsPrimary__c == ''){
            component.set('v.popupErrorMessage','Active is required');
            return;
        }
        else if(currentObj.PhoneNumber__c == ''){
            component.set('v.popupErrorMessage','Phone number is required');
            return;
        }
        currentObj.Account__c = allPreviousList[0].Account__c;
        action.setParams({
            "phoneObj" : currentObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Phone added successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        allPreviousList.push(res.data.result);
                        if(currentActiveTab == 'borrower'){
                            component.set('v.phoneList',allPreviousList);
                        }else if(currentActiveTab == 'coborrower'){
                            component.set('v.cophoneList',allPreviousList);
                        }else if(currentActiveTab == 'cosigner'){
                            component.set('v.cosphoneList',allPreviousList);
                        }
                        helper.resetPopUpErrorMessage(component, event, helper);
                        helper.clearPhonePopUpsValues(component, event, helper);
                    }else if(res.status == 'failed'){
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    saveAddress : function(component, event, helper){
        var action = component.get("c.addNewAddress");
        var currentObj = component.get('v.newAddressObj');
        var currentActiveTab = component.get("v.mainTabName");
        var allPreviousList = [];
        if(currentActiveTab == 'borrower'){
            allPreviousList = component.get('v.addressList');
        }else if(currentActiveTab == 'coborrower'){
            allPreviousList = component.get('v.coaddressList');
        }else if(currentActiveTab == 'cosigner'){
            allPreviousList = component.get('v.cosaddressList');
        }
        if(allPreviousList.length == 0){
            component.set('v.popupErrorMessage','Account Id is required');
            return;
        }else if(currentObj.Unit__c == ''){
            component.set('v.popupErrorMessage','Unit is required');
            return;
        }else if(currentObj.StreetAddress__c == ''){
            component.set('v.popupErrorMessage','Street is required');
            return;
        }else if(currentObj.City__c == ''){
            component.set('v.popupErrorMessage','City number is required');
            return;
        }else if(currentObj.Country__c == ''){
            component.set('v.popupErrorMessage','Country is required');
            return;
        }else if(currentObj.PostalCode__c == ''){
            component.set('v.popupErrorMessage','PostalCode is required');
            return;
        }else if(currentObj.Province__c == ''){
            component.set('v.popupErrorMessage','Province is required');
            return;
        }
        currentObj.Account__c = allPreviousList[0].Account__c;
        action.setParams({
            "addressObj" : currentObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Address added successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        allPreviousList.push(res.data.result);
                        if(currentActiveTab == 'borrower'){
                            component.set('v.addressList',allPreviousList);
                        }else if(currentActiveTab == 'coborrower'){
                            component.set('v.coaddressList',allPreviousList);
                        }else if(currentActiveTab == 'cosigner'){
                            component.set('v.cosaddressList',allPreviousList);
                        }
                        helper.resetPopUpErrorMessage(component, event, helper);
                        helper.clearAddressPopUpsValues(component, event, helper);
                    }else if(res.status == 'failed'){
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    fetchPicklistValues : function(component, event, helper,cmpName,objName1,fieldName1){
        var action = component.get("c.getPicklistValues");
        action.setParams({
            "objName" : objName1,
            "fieldName" : fieldName1
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(cmpName == 'Province'){
                        component.set('v.addressProvinceOptions',res);
                    }else if(res.status == 'failed'){
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    resetPopUpErrorMessage : function(component, event, helper){
        component.set("v.isOpenEmail", false);
        component.set("v.isOpenPhone", false);
        component.set("v.isOpenAddress", false);
        component.set('v.popupErrorMessage','');
    },
    fetchEmailTemplatesList : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                if(res != null && res.data != null && res.data.result != null){
                    component.set('v.emailTemplateList',res.data.result);
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    fetchTemplateBody : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : component.get("v.emailTemplateSelectedVal")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                if(res != null && res.data != null && res.data.result != null){
                    component.set('v.templatePreviewBody',res.data.result[0].HtmlValue);
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    resetButtonVisiblility: function(component, event, helper) {
        component.set('v.cobviewmode',true);
        component.set('v.borviewmode',true);
        component.set('v.cosviewmode',true);
        component.set('v.bpaviewmode',true);
        component.set('v.cobpaviewmode',true);
        component.set('v.cosignerbpaviewmode',true);
        component.set('v.showSaveButtonBor',false);
        component.set('v.showSaveButtonbpa',false);
        component.set('v.showEditBtnBor',true);
        component.set('v.showEditBtnbpa',true);
    },
    
    AddCoBorrowerCoSigner: function(component, event, helper, type) {
        
          //21-March -Maanas//
        var accLookup;
        if(component.get('v.selectedLookUpRecord').Id == undefined){
            accLookup = null;
        }
        else{
            accLookup = component.get('v.selectedLookUpRecord');
        }
        var action = component.get("c.createUpdateAccount");
        action.setParams({
            "existingAccount": accLookup,
            "newRec": component.get('v.accountRec'),
            "applicantType" : type,
            "applicationId" : component.get('v.recordId')
            
        });            
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var recId = response.getReturnValue();
                if(recId == 'fail'){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": 'Add Failed: User Already Present as Borrower/Co-Borrower/Co-Signer on the Application!',
                        "type": "error",
                    });
                    toastEvent.fire();
                }else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": 'Added Successfully!',
                        "type": "success",
                    });
                    toastEvent.fire();
                    var navLink = component.find("navLink");
                    var pageRef = {
                        type: 'standard__recordPage',
                        attributes: {
                            actionName: 'view',
                            objectApiName: 'Application__c',
                            recordId : component.get('v.recordId')
                        },
                    };
                    component.set("v.isAddCoBorrower",false);
                    component.set("v.isAddCoSigner",false);
                    helper.clearNewBorrowerPopUpsValues(component, event, helper);
                    navLink.navigate(pageRef, true);
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    if(databaseError.includes("A9A"))
                        finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                    else
                        finalErrorMessage =  databaseError;
                    
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action);   
        
    },
    clearEmailPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.EmailAddress__c = '';                                               
        newObj.IsPrimary__c = '';
        component.set("v.newEmailObj",newObj);
    },
    clearPhonePopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.PhoneNumber__c = '';                                               
        newObj.PhoneType__c = '';
        newObj.IsPrimary__c = '';
        component.set("v.newPhoneObj",newObj);
    },
    clearAddressPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.StreetAddress__c = '';                                               
        newObj.City__c = '';
        newObj.Province__c = '';
        newObj.Country__c = '';
        newObj.PostalCode__c = '';
        newObj.IsPrimary__c = '';
        component.set("v.newAddressObj",newObj);
    },
    clearNewBorrowerPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.FirstName = '';                                               
        newObj.LastName = '';
        newObj.PersonEmail = '';
        newObj.Username__c = '';
        component.set("v.accountRec",newObj);
        component.set("selectedLookUpRecord",'');
    }
})
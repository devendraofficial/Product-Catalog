({
	fetchMaritalPicklist : function(component){
        var action = component.get("c.getPicklistvalues");
        action.setParams({
            'objectName': 'Account',
            'field_apiname': 'MaritalStatus__pc',
            'nullRequired': true // includes --None--
        });
        action.setCallback(this, function(a) {
            var state = a.getState();
            if (state === "SUCCESS"){
                component.set("v.maritalPicklist", a.getReturnValue());
            } 
            else if (state === "ERROR") { 
               
                var errors = action.getError();
                if (errors) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors.message,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action);
    }
})
({
    doInit : function(component, event, helper) {
        var singleAdd = component.get('v.singleAddress');
        singleAdd.Country__c ='Canada';
        component.set('v.singleAddress', singleAdd );
        helper.fetchMaritalPicklist(component);
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + today.getDate()); 
    },
    
    CallSave: function(component, account) {
        
        var callApex = true;       
        var accRecord = component.get('v.accountRec');
        var borrerror = false;
        var generalValidation = false;
        var addressValidation = false;
        var previousAddressValidation = false;
        
       accRecord.Consent__pc = component.get('v.consent');
        console.log("Value of Consent in Insert time : ",component.get('v.consent'));
        if(accRecord.FirstName == '' || accRecord.FirstName == undefined  
           || accRecord.LastName =='' || accRecord.LastName == undefined 
           || accRecord =='' || accRecord =='undefined' 
           || accRecord.PersonEmail == '' || accRecord.PersonEmail == undefined ||
           accRecord.Phone =='' ||  accRecord.Phone == undefined ||
           accRecord.PersonBirthdate =='' || accRecord.PersonBirthdate == undefined ||
          accRecord.Gender__pc =='' || accRecord.Gender__pc == undefined ||
          accRecord.MaritalStatus__pc =='' || accRecord.MaritalStatus__pc == undefined){
            callApex = false;
            generalValidation = true;
        }
        var singAddress = component.get('v.singleAddress');
        
        if(singAddress.StreetAddress__c == '' || singAddress.StreetAddress__c == undefined ||
           singAddress.City__c == '' || singAddress.City__c ==undefined ||
           singAddress.Province__c =='' || singAddress.Province__c == undefined ||
           singAddress.Country__c == '' || singAddress.Country__c == undefined ||
           singAddress.PostalCode__c == '' || singAddress.PostalCode__c == undefined
           ){
            addressValidation =true;
            callApex = false;
            
            
        }
        
        var result = new Date();
        result.setMonth(result.getMonth() - 12);
        var previousYear = $A.localizationService.formatDate(result,"YYYY-MM-DD");
        
        var selectedDate = component.get("v.singleAddress.AddressSince__c");
        var previousadd = component.get('v.previousAddress');
        
        /*     if (previousYear <= selectedDate ){
             if(previousadd.StreetAddress__c == '' || previousadd.StreetAddress__c == undefined ||
           		previousadd.City__c == '' || previousadd.City__c ==undefined ||
           		previousadd.Province__c =='' || previousadd.Province__c == undefined ||
           		previousadd.Country__c == '' || previousadd.Country__c == undefined ||
           		previousadd.PostalCode__c == '' || previousadd.PostalCode__c == undefined
               ) {
                	previousAddressValidation = true;
                	callApex = false;	                	
                }         
        }*/
        
        
        var applicationRecord = component.get('v.selectedLookUpRecord');
        
        if((applicationRecord == null ||  applicationRecord == '' || applicationRecord == undefined) && component.get('v.applicantType') != 'borrower'){
            callApex = false;
            borrerror = true;
        }
        
        if(callApex){
            component.set('v.loading',true);
            var action = component.get("c.insertAccount");
            action.setParams({
                "acc": component.get('v.accountRec'),
                "ConsentValue": component.get('v.consent'),
                "Addresses": component.get('v.AddresslstCollectionDetails'),
                "Phones" : component.get('v.PhonelstCollectionDetails'),
                "Emails" : component.get('v.EmaillstCollectionDetails'),
                "SAddress" : component.get('v.singleAddress'),
                "PAddress" : null,
                "selectedApplication" : applicationRecord,
                "appType" : component.get('v.applicantType')
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    component.set('v.loading',false);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": 'Record Inserted Successfully!',
                        "type": "success",
                    });
                    toastEvent.fire();
                    var recId = response.getReturnValue();
                    
                    var navLink = component.find("navLink");
                    var pageRef = {
                        type: 'standard__recordPage',
                        attributes: {
                            actionName: 'view',
                            objectApiName: 'Application__c',
                            recordId : recId //
                        },
                    };
                    navLink.navigate(pageRef, true);
                    
                }
                else if (state === "ERROR") {
                    component.set('v.loading',false);
                    var errors = action.getError();
                    var finalErrorMessage;
                    if (errors) {
                        var databaseError = errors[0].message;
                        if(databaseError.includes("A9A"))
                            finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                        else if(databaseError.includes("SIN__Shadow__s duplicates"))
                            finalErrorMessage = 'Duplicate SIN Entered For User';
                            else if(databaseError.includes("duplicate value found: Unique_Email__c"))
                                finalErrorMessage = 'Duplicate Email Entered For User';
                         		else if(databaseError.includes("Script-thrown exception"))
                                finalErrorMessage = 'A record or object with this unique identifier already exists.';
                                else 
                                    finalErrorMessage =  databaseError;  
                        
                        
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": finalErrorMessage,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);    
        }else{
            var erMsg = '';
            if(borrerror){
                erMsg = 'Application Id cannot be Blank When Co-Borrower & Co-Signer is Selected! \n'
            }
            
            if(generalValidation){
                erMsg += 'Please Fill All Required Fields(First Name/LastName/ Email/Phone/Date OF Birth/Gender/Marital Status) \n';
            }
            
            if(addressValidation)
                erMsg += 'Please Fill All Required Address Fields(Street,City,Province,Country,Postal Code, Address Since)\n';
            
            if(previousAddressValidation)
                erMsg += 'Previous Address Not Filled When Current Address Stay Specified is Less Than 12 Months!\n';
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": erMsg,
                "type": "error",
            });
            toastEvent.fire(); 
        }     
    },
    
    cancel : function(component, account) {
        
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Account',
                actionName: 'home'
            },
        };
        navLink.navigate(pageRef, true);
        
    },
    
    showRequiredFields: function(component, event, helper){
        $A.util.removeClass(component.find("Input_contract_type__c"), "none");
    },
    
    
    addPreviousAddress : function(component, event, helper) {
        
        var result = new Date();
        result.setMonth(result.getMonth() - 12);
        var previousYear = $A.localizationService.formatDate(result,"YYYY-MM-DD");
        
        var selectedDate = component.get("v.singleAddress.AddressSince__c");
        console.log(selectedDate <= previousYear);
        if (previousYear <= selectedDate){
            component.set('v.errorMessage',$A.get("$Label.c.Present_Address_Validation")); 
            component.set('v.openAddressSection', true);
        }else{
            component.set('v.errorMessage',''); 
            component.set('v.openAddressSection', false);
        }
        
    },
    checkValidity : function(component, event, helper) {
        var validity = event.getSource().get("v.validity");
        console.log(validity)
    },
    
    duplicateEmailCheck : function(component, event, helper){
        
        var action = component.get("c.isDuplicateEmail");
        action.setParams({
            "userEmail": component.get('v.accountRec.PersonEmail')
            
        });
        var isDup =false;
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                isDup = response.getReturnValue();
                
                if(isDup){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": 'Duplicate Email Address Found',
                        "type": "error",
                    });
                    toastEvent.fire();
                    component.set('v.accountRec.PersonEmail','');
                    
                }
                
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                if (errors) {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors[0],
                        "type": "error",
                    });
                    toastEvent.fire();
                }
            }
        });
        $A.enqueueAction(action);
    }
})
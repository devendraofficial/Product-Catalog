({
    closeModal : function(component, event, helper) {
      

      //  var vx = component.get("v.method");
      //  $A.enqueueAction(vx);
      //  
        
            
                var appEvent = $A.get("e.c:RefreshDocument");
                appEvent.fire();
          
        
        
    },
    doInit:function (component, event,helper) {
      
        helper.fetchData(component,event,helper);
    },
    handleUploadFinished:function(component, event,helper) {
    },
    
    
    
    handleFilesChange: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName", fileName);
    },
    
    handleSave: function(component, event, helper) {
        
        
        var inputCmp = component.find("fileName");
        var value = inputCmp.get("v.value");
		
        
        if(value!=null)
        {
            
      
        
        
      var val1=component.get('v.documentType');
       
            var action = component.get("c.insertRecoveredDocument");
            
            action.setParams({ DocumentType : component.get('v.documentType') ,applicationId : component.get("v.recordId"), userType :component.get('v.currentUserType')});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {        


                 var appEvent = $A.get("e.c:RefreshDocument");
                appEvent.fire();
                    
                }
                else
                {
                    alert('Insert Failed');
                }
            });
            $A.enqueueAction(action);
        }  
    else
    {
         inputCmp.showHelpMessageIfInvalid();
    }
        
        
        
        
    },
    changeVal:function(component,event,helper)
    {
        var selectedOptionValue = event.getParam("value");
        component.set('v.documentType',selectedOptionValue);
        
    }
   
    
    
})
({
    fetchData : function(component,event,helper) {
        var action = component.get("c.getMailDetails");
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                
                component.set('v.personalEmail',response.getReturnValue().mailId);
                component.set('v.Name',response.getReturnValue().mailId);
                component.set('v.RecoveredDocuments',response.getReturnValue().RecoveredDocuments);
                component.set('v.EmailTemplates',response.getReturnValue().EmailTemplates);
                component.set('v.EmailTemplates1',response.getReturnValue().EmailTemplates1);
                
                
                var recordData = component.get('v.EmailTemplates');
                recordData.forEach(function(Rec){
                    Rec.label = Rec.Name;
                    Rec.value = Rec.Id;
                });
                
                var documents = response.getReturnValue().documentList;
               // var docList = component.get('v.docList');
                var docList = [];
                component.set('v.EmailTemplates',recordData);	          
                var fb= component.get('v.fullBody');
                var tb= component.get('v.templateBody');
                var selectedDocuments = component.get('v.selectedDocuments');
                response.getReturnValue().RecoveredDocuments.forEach(function(Rec){
                    
                    if(Rec.IsRequired__c==false  && Rec.IsDocumentTypeReceived__c == false )
                    {
                        //1.selected documents
                        selectedDocuments.forEach(function(sd){
                            if(sd==Rec.DocumentType__c)
                            {
                                    tb = tb+'<br>'+Rec.DocumentType__c;
                                    docList.push(Rec.DocumentType__c); 
                            }
                        })
                        //2.requested documents
                        if(Rec.DocumentRequested__c==true)
                        {
                            tb = tb+'<br>'+Rec.DocumentType__c;
                            docList.push(Rec.DocumentType__c);
                        }
                        
                        
                    }
                    
                    else if(Rec.IsRequired__c==true && Rec.IsDocumentTypeReceived__c == false)
                    {
                        
                                    tb = tb+'<br>'+Rec.DocumentType__c;
                                    docList.push(Rec.DocumentType__c);
                       
                    }
                })
                
                
                var s ='';
                if(response.getReturnValue().URL!='errormsgNo record Found')
                {
                    s = JSON.parse(response.getReturnValue().URL).value;
                    tb = tb+'<br>'+s;
                    
                }
                
                
                var docs ='';
                component.set('v.docList',docList);
                debugger
                var filertedtext = response.getReturnValue().body.split('</head>')[1];
                
                component.set('v.fullBody',filertedtext);
                var fullBody = component.get('v.fullBody');
                docList.forEach(function(doc){
                    
                    docs = docs+'<br>'+doc;
                });
                fullBody= fullBody.replace(/{{required_documents}}/g, docs);
                fullBody= fullBody.replace('mailMarbleLink', s);
                // fullBody=fullBody+'<br>'+s;
                console.log('linkId'+s);
                component.set('v.fullBody',fullBody);
            }
        });
        $A.enqueueAction(action);
        
    },
    fetchTemplateBody : function(component, event, helper,selectedOptionValue){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : selectedOptionValue
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                if(res != null && res.data != null && res.data.result != null){
                    component.set('v.fullBody',res.data.result[0].HtmlValue);
                }
                var docList = component.get('v.docList');
                var fullBody = component.get('v.fullBody');
                docList.forEach(function(doc){
                    
                    fullBody = fullBody+'\n'+doc;
                })
                
                
                component.set('v.fullBody',fullBody);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    }
})
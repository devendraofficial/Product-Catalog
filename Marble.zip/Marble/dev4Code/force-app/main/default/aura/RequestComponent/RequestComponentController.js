({
closeModal : function(component, event, helper) {

        var vx = component.get("v.method");
        $A.enqueueAction(vx);
    
  //   var appEvent = $A.get("e.c:RefreshDocument");
    //            appEvent.fire();
    
	},
    
   doInit:function (component, event,helper) {
             var values = component.get('v.selectedDocuments');
        console.log('init'+values);
       helper.fetchData(component,event,helper);
    },
    
      showTemplateBody:function(component,event,helper){
      var selectedOptionValue = event.getParam("value");

        helper.fetchTemplateBody(component,event,helper,selectedOptionValue);
    },
    
    
    changeTemplate:function(component,event,helper)
    {
        
          
        
    
        var selectedOptionValue = event.getParam("value");
        component.set('v.selectedTemplateId',selectedOptionValue);
        
        
         var action = component.get("c.getMailBody");
        action.setParams({ templateName : selectedOptionValue,to:component.get('v.personalEmail') , Name:component.get('v.Name')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                

               // component.set('v.templateBody',response.getReturnValue().Body);

                component.set('v.templateBody',response.getReturnValue());
                component.set('v.fullBody',response.getReturnValue());
                
                var fullBody = component.get('v.fullBody');
                var docList = component.get('v.docList');
                
                docList.forEach(function(doc){
                    
                    fullBody = fullBody+'<br>'+doc;
                })
            
                
                component.set('v.fullBody',fullBody); 
               
                

            }

        });
        $A.enqueueAction(action);
        
  
    },
    mockMailFun:function(component,event,helper)
    {
     
        
   

        
        var Name = component.get('v.Name');
        
         var action = component.get("c.mockMail");
        var maildocList = component.get('v.docList');
        console.log('maildocList'+ maildocList);
        action.setParams({ templateId : component.get('v.selectedTemplateId'),body:component.get('v.fullBody'),to:component.get('v.personalEmail'),Name:Name,documentList:maildocList,appId: component.get("v.recordId"), type :component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {

             
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                 "title": "Success!",
                "message":"Request document email successfully sent!",
                "type": 'success',
            });
            toastEvent.fire();
                
         
                
                
                var vx = component.get("v.method");
       $A.enqueueAction(vx);
     }
            else
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "message":"Mail Not Send!",
                    "type": 'error',
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
        
        
        
    },
    onCheck :function(component,event,handler)
    {
      
     
        var docList = component.get('v.docList');
        var name=event.getSource().get("v.label");
        var val = event.getSource().get("v.value");

        if(val==false)
        {

            docList.push(name);
            component.set('v.docList',docList);
            var recs= component.get('v.RecoveredDocuments');
            recs.forEach(function(R){
                if(R.DocumentType__c==name)
                    R.IsDocumentTypeReceived__c=false;
            });
            component.set('v.RecoveredDocuments',recs);
        }
        else if(val==true)
        { 
            var newList =[];
            docList.forEach(function(Rec){
                if(Rec!=name)
                {
                    newList.push(Rec);
                }
            })  
            component.set('v.docList',newList);
            
             var recs= component.get('v.RecoveredDocuments');
            recs.forEach(function(R){
                if(R.DocumentType__c==name)
                    R.IsDocumentTypeReceived__c=true;
            });
            component.set('v.RecoveredDocuments',recs);
        }
        
        
        
        
        
        var templateBody = component.get('v.templateBody');
        var docList = component.get('v.docList');
        if(templateBody!=null && docList!=null)
        {
            docList.forEach(function(Rec){
                templateBody = templateBody+"<br/>"+Rec;
            })
            
             component.set('v.fullBody',templateBody);
        }
        
       
        
        
        
    }
        
  
})
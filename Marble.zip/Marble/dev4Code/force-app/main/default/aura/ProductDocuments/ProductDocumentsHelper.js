({
	fetchData : function(component,event,helper) {
		 var action = component.get("c.getProductDocuments");
        action.setParams({ productId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                component.set('v.productDocuments',response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
	}
})
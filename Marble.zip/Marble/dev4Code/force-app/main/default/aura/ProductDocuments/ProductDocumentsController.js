({
	doInit : function(component, event, helper) {
		 helper.fetchData(component,event,helper);
	},
    newDocumentHeader:function(component,event,helper)
    {
        component.set("v.docModal",'true');
    },
     canceldocHeader:function(component,event,handler)
    {
        component.set('v.docModal','false');
        
    },
    insertDocHeader:function(component,event,helper)
    {

       
        var action = component.get("c.insertDoc");
        action.setParams({ productId : component.get('v.recordId'),documentHeader:component.find("DocumentHeadId").get("v.value")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
             
                helper.fetchData(component,event,helper);
                component.set('v.docModal','false');
            }
        });
        $A.enqueueAction(action);
      
    }
})
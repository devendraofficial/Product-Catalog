({
    doinit : function(component,event,helper) {
        // create a one-time use instance of the serverEcho action
        // in the server-side controller
        var action = component.get("c.SaveUser");
        action.setParams({ LastName : component.get("v.LastName"),
                          Username : component.get("v.Username"),
                          Consent : component.get("v.Consent"),
                          Unit : component.get("v.Unit"),
                          StreetAddress : component.get("v.StreetAddress"),
                          Province : component.get("v.Province"),
                          City : component.get("v.City"),
                          phonenumber : component.get("v.phonenumber"),
                          isPrimary : component.get("v.isPrimary"),
                          isTextAllowed : component.get("v.isTextAllowed"),
                          emailAddress : component.get("v.emailAddress"),
                          isPrimaryp : component.get("v.isPrimaryp")
                         });

        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                           }
            //else if (component.isValid() && state === "INCOMPLETE") {
            else if (state === "INCOMPLETE") {
                // do something
            }
            //else if (component.isValid() && state === "ERROR") {
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });

        $A.enqueueAction(action);
    }
})
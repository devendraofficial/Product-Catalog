({
    doInit : function(component, event, helper) {
        helper.setDataTableHeaders(component, event, helper);
        helper.fetchCreditDetails(component, event, helper);
    },
    newSummaryPull: function(component, event, helper) {
        alert('New Summary Pull is initiated');
        helper.initiateNewSummary(component, event, helper);
    },
    GetNewFullReport: function(component, event, helper) {
        alert('Hardpull is initaited please wait for the data');
        helper.getHardPullData(component, event, helper);
        component.set("v.OpenNewFullReportBox", false);
    },
    likenClose: function(component, event, helper) {
        helper.renderTableVisibility(component, event, helper);
    },
    selectAllCheckBox: function(component, event, helper) {
        helper.selectAllCheckBox(component, event, helper);
    },
    tabSelected: function(component,event,helper) {
        helper.fetchCreditDetails(component, event, helper);
    },
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"
        component.set("v.isOpen", false);
    },
    openFullReportModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.OpenNewFullReportBox", true);
    },
    
    closeNewFullReportModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.OpenNewFullReportBox", false);
    },
    
    
    
    callVFPage : function(component, event, helper) {
        var action = component.get("c.getRawCreditReport");
         action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                var creditData = response.getReturnValue();
                var recordId = creditData[0].Id;
                window.open('/apex/creditReportRawData?id='+recordId);
            }
            else {
                alert('No data found');
            }
        });
        $A.enqueueAction(action);
    },
    
    /*handleVerticalMenu:function(component,event,helper)
    {
        var tab = event.getParam("tab");
        if(tab=="documents")
        {
            component.set('v.isVisible','false');
        }
        else
            component.set('v.isVisible','true');
    }, */
     filterDataTables: function(component, event, helper) {
        
        var searchInput = component.get("v.searchValue");
        if(searchInput.length >= 0 && searchInput.length < 3 ){
            component.set('v.showCharMessage','true');
            if(helper.isTableResetRequired){
                helper.isTableResetRequired = false;
                helper.convertToDatatableData(component, event, helper);
            }
        }else{
            helper.isTableResetRequired = true;
            component.set('v.showCharMessage','false');
            helper.filterDataTablesByInput(component, event, helper,searchInput);
        }
    }, 
    handleVerticalMenu:function(component,event,helper)
    {
        var tab = event.getParam("tab");
		console.log('=======handleVerticalMenu-----'+JSON.stringify(tab));        
        
        if(tab=="CreditReport")
        {
            
            component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false');
        
    },
    
})
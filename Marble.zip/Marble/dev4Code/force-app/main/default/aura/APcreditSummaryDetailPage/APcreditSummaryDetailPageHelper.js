({
    
    isTableResetRequired : false ,
    fetchCreditDetails : function(component, event, helper) {
        var action = component.get("c.getCreditDetails");
        var recId = component.get("v.recordId");
        var applicantType = component.get("v.applicantType");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType1: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                var creditData = response.getReturnValue();
                console.log('creditData init',creditData);
                
                component.set("v.CreditData",creditData);
                helper.convertToDatatableData(component, event, helper);
                
                var MoreThan3InquiriesInThePast6Months = creditData.insights.warnings.inquiriesSixMonthsOverMax;
               console.log('MoreThan3InquiriesInThePast6Months',MoreThan3InquiriesInThePast6Months);
                if(MoreThan3InquiriesInThePast6Months == true){
                    component.set("v.MoreThan3InquiriesInThePast6Months", "slds-show");
                }
                
                var JobTenureUnderOneYear = creditData.insights.employment.tenureUnderMin;
                console.log('JobTenureUnderOneYear',JobTenureUnderOneYear);
                if(JobTenureUnderOneYear == true){
                    component.set("v.JobTenureUnderOneYear", "slds-show");
                }
                var IncomeUnder2000PerMonth = creditData.insights.employment.payUnderMin;
                console.log('IncomeUnder2000PerMonth',IncomeUnder2000PerMonth);
                if(IncomeUnder2000PerMonth == true){
                    component.set("v.IncomeUnder2000PerMonth", "slds-show");
                }
                var NotInConsumerProposal = creditData.insights.cp.since;
                console.log('NotInConsumerProposal',NotInConsumerProposal);
                if(NotInConsumerProposal == null){
                    component.set("v.NotInConsumerProposal", "slds-show");
                }
                var ConsumerProposalAgeUnderOneYear = creditData.insights.cp.durationUnderMin;
                console.log('ConsumerProposalAgeUnderOneYear',ConsumerProposalAgeUnderOneYear);
                if(ConsumerProposalAgeUnderOneYear == true){
                    component.set("v.ConsumerProposalAgeUnderOneYear", "slds-show");
                }
                var ConsumerProposalBalanceOver15000 = creditData.insights.cp.estimatedAmountOverLimit ;
                console.log('ConsumerProposalBalanceOver15000',ConsumerProposalBalanceOver15000);
                if(ConsumerProposalBalanceOver15000 == true){
                    component.set("v.ConsumerProposalBalanceOver15000", "slds-show");
                }
                var CreditSoughtDuringConsumerProposal = creditData.insights.cp.inquiriesDuring;
                console.log('CreditSoughtDuringConsumerProposal',CreditSoughtDuringConsumerProposal);
                if(CreditSoughtDuringConsumerProposal == true){
                    component.set("v.CreditSoughtDuringConsumerProposal", "slds-show");
                }
                var CreditObtainedDuringConsumerProposal = creditData.insights.cp.creditDuring;
                console.log('CreditObtainedDuringConsumerProposal',CreditObtainedDuringConsumerProposal);
                if(CreditObtainedDuringConsumerProposal == true){
                    component.set("v.CreditObtainedDuringConsumerProposal", "slds-show");
                }
                var ResidenceTenureUnderOneYear = creditData.insights.residence.durationUnderMin;
                console.log('ResidenceTenureUnderOneYear',ResidenceTenureUnderOneYear);
                if(ResidenceTenureUnderOneYear == true){
                    component.set("v.ResidenceTenureUnderOneYear", "slds-show");
                }
                /*var PoorMortgagePaymentHistory = creditData.residence.mortgage.latePayments;
                if(PoorMortgagePaymentHistory == true){
                    component.set("v.PoorMortgagePaymentHistory", "slds-show");
                }*/
                var PaydayLoans = creditData.insights.warnings.paydayLoans;
                console.log('PaydayLoans',PaydayLoans);
                if(PaydayLoans == true){
                    component.set("v.PaydayLoans", "slds-show");
                }
                var IDMismatchWarnings = creditData.insights.warnings.idMismatch;
                console.log('IDMismatchWarnings',IDMismatchWarnings);
                if(IDMismatchWarnings == true){
                    component.set("v.IDMismatchWarnings", "slds-show");
                }
                var HighRiskFraudAlerts = creditData.insights.warnings.fraud;
                console.log('HighRiskFraudAlerts',HighRiskFraudAlerts);
                if(HighRiskFraudAlerts == true){
                    component.set("v.HighRiskFraudAlerts", "slds-show");
                }
                var NoCreditScore = creditData.insights.warnings.noCreditScore;
                console.log('NoCreditScore',NoCreditScore);
                if(NoCreditScore == true){
                    component.set("v.NoCreditScore", "slds-show");
                }
                var CreditScoreUnder500 = creditData.insights.warnings.creditScoreUnderMin; 
                console.log('CreditScoreUnder500',CreditScoreUnder500);
                if(CreditScoreUnder500 == true){
                    component.set("v.CreditScoreUnder500", "slds-show");
                }
                var DebtInCollections = creditData.insights.warnings.unpaidCollections;
                console.log('DebtInCollections',DebtInCollections);
                if(DebtInCollections == true){
                    component.set("v.DebtInCollections", "slds-show");
                }
                var DebtServiceRatioOver50Percent = creditData.insights.dsr.overMax;
                console.log('DebtServiceRatioOver50Percent',DebtServiceRatioOver50Percent);
                if(DebtServiceRatioOver50Percent == true){
                    component.set("v.DebtServiceRatioOver50Percent", "slds-show");
                }
                
            }
            else if (status === "INCOMPLETE") {
                console.log("No response from server or client is offline.")
            }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
        });
        $A.enqueueAction(action);
    },
    initiateNewSummary : function(component, event, helper) {
        var action = component.get("c.initiateSoftSummaryPull");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                alert('New Sumary Record Created');
            }
            else if (status === "INCOMPLETE") {
                console.log("No response from server or client is offline.")
            }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
        });
        $A.enqueueAction(action);
    },
    initiateNewSummary : function(component, event, helper) {
        var action = component.get("c.initiateSoftSummaryPull");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                
            }
            else if (status === "INCOMPLETE") {
                console.log("No response from server or client is offline.")
            }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
        });
        $A.enqueueAction(action);
    },
    filterDataTablesByInput : function(component, event, helper,searchInput) {
        var creditData = component.get("v.CreditData");
        var objHistory = creditData.creditHistory; 
        var arrayToSearch = component.get("v.searchableArrays");
        var finalSearchDataObj = {};
        for(var i = 0;i<arrayToSearch.length;i++){
            var filteredResult = [];
            if (objHistory.hasOwnProperty(arrayToSearch[i])){
                var currentArray = objHistory[arrayToSearch[i]];
                for(var ind = 0; ind<currentArray.length; ind++){
                    var currentObj = currentArray[ind];
                    if(currentObj.hasOwnProperty('item')){
                        for (var key in currentObj.item) {
                            if(currentObj.item[key]){
                                if(((currentObj.item[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                    filteredResult.push(currentArray[ind]);
                                } 
                            }  
                        }
                    }else{
                        for (var key in currentObj) {
                            if(currentObj[key]){
                                if(((currentObj[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                    filteredResult.push(currentArray[ind]);
                                } 
                            }  
                        }
                    }
                }
            }else if(arrayToSearch[i] = 'CreditHistoryOverview'){
                for (var key in objHistory) {
                    if(objHistory[key]){
                        if(((objHistory[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                            filteredResult.push(objHistory);
                        } 
                    }  
                }
            }
            finalSearchDataObj[arrayToSearch[i]] = filteredResult;
        }
        helper.setFilteredData(component, event, helper,finalSearchDataObj);
    },
    setFilteredData : function(component, event, helper,filteredData) {
        Object.keys(filteredData).forEach(function(key) {
            if(filteredData[key]){
                if(key == 'addresses'){
                    component.set("v.addresses",filteredData[key]);
                }else if(key == 'tradeSummaries'){
                    component.set("v.tradeSummaries",filteredData[key]);
                }else if(key == 'registeredItems'){
                    component.set("v.registeredItems",filteredData[key]);
                }else if(key == 'bankruptcies'){
                    component.set("v.bankruptcies",filteredData[key]);
                }else if(key == 'inquiries'){
                    component.set("v.Inquirydata",filteredData[key]);
                }else if(key == 'creditHistory'){
                    component.set("v.CreditData",filteredData[key]);
                }else if(key == 'employments'){
                    component.set("v.EmploymentData",filteredData[key]);
                }else if(key == 'summaryReport'){
                    component.set("v.FileSummaryData",filteredData[key]);
                }else if(key == 'consumerProposals'){
                    //component.set("v.",filteredData[key]);
                }else if(key == 'CreditHistoryOverview'){
                    component.set("v.CreditHistoryOverview",filteredData[key]);
                }
            }  
        });
    },
    renderTableVisibility : function(component, event, helper) {
        
        
        
        if(!(component.get("v.InquiriesWithin6Months") || component.get("v.LegalItems")
             || component.get("v.TURiskScore") || component.get("v.Collections")
             || component.get("v.IDMismatch") || component.get("v.CollectionInq")
             || component.get("v.HighRiskFraud"))){	
            component.set("v.IDMismatchAcordian",'slds-hide');
        }else{
            component.set("v.IDMismatchAcordian",'slds-show');
        }
        if(!component.get("v.LatePayments")){	
            component.set("v.TradeAcordian",'slds-hide');
        }else{
            component.set("v.TradeAcordian",'slds-show');
        }
        helper.hideAllOtherTabs(component, event, helper, true);
        component.set("v.isOpen", false);
    },
    hideAllOtherTabs : function(component, event, helper, isShow) {
        if(isShow){
            component.set("v.residenceAcordian",'slds-hide');
            component.set("v.EmploymentAcordian",'slds-hide');
            component.set("v.BankingClosedAcordian",'slds-hide');
            component.set("v.RegisteredItemsAcordian",'slds-hide');
            component.set("v.BankruptcyAcordian",'slds-hide');
            component.set("v.InquiriesAcordian",'slds-hide');
            component.set("v.OverviewAcordian",'slds-hide');
        }else{
            component.set("v.IDMismatchAcordian",'slds-show');
            component.set("v.TradeAcordian",'slds-show');
            component.set("v.residenceAcordian",'slds-show');
            component.set("v.EmploymentAcordian",'slds-show');
            component.set("v.BankingClosedAcordian",'slds-show');
            component.set("v.RegisteredItemsAcordian",'slds-show');
            component.set("v.BankruptcyAcordian",'slds-show');
            component.set("v.InquiriesAcordian",'slds-show');
            component.set("v.OverviewAcordian",'slds-show');
        }
    },
    selectAllCheckBox : function(component, event, helper) {
        var isSelected = false;
        if(component.get("v.selectAll")){
            isSelected = true;
        }
        component.set("v.InquiriesWithin6Months",isSelected);
        component.set("v.LegalItems",isSelected);
        component.set("v.TURiskScore",isSelected);
        component.set("v.Collections",isSelected);
        component.set("v.IDMismatch",isSelected);
        component.set("v.Mismatches",isSelected);
        component.set("v.CollectionInq",isSelected);
        component.set("v.HighRiskFraud",isSelected);
        component.set("v.LatePayments",isSelected);
    },
    
    getHardPullData : function(component, event, helper) {
        console.log('----getHardPullData start----');
        var action = component.get("c.initiateHardPull");
        var recId = component.get("v.recordId");
        var applicantType = component.get("v.applicantType");
        action.setParams({
            appId: component.get("v.recordId"),
            appType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state:',state);
            if(state === 'SUCCESS') {
                var creditData = response.getReturnValue();
                console.log('creditData',creditData);
                component.set("v.CreditData",creditData);
                console.log('----getHardPullData start----');
                helper.convertToDatatableData(component, event, helper);
                var MoreThan3InquiriesInThePast6Months = creditData.warnings.inquiriesSixMonthsOverMax;
                if(MoreThan3InquiriesInThePast6Months == true){
                    component.set("v.MoreThan3InquiriesInThePast6Months", "slds-show");
                }
                
                var JobTenureUnderOneYear = creditData.insights.employment.tenureUnderMin;
                if(JobTenureUnderOneYear == true){
                    component.set("v.JobTenureUnderOneYear", "slds-show");
                }
                var IncomeUnder2000PerMonth = creditData.insights.employment.payUnderMin;
                if(IncomeUnder2000PerMonth == true){
                    component.set("v.IncomeUnder2000PerMonth", "slds-show");
                }
                var NotInConsumerProposal = creditData.insights.cp.since;
                if(NotInConsumerProposal == null){
                    component.set("v.NotInConsumerProposal", "slds-show");
                }
                var ConsumerProposalAgeUnderOneYear = creditData.insights.cp.durationUnderMin;
                if(ConsumerProposalAgeUnderOneYear == true){
                    component.set("v.ConsumerProposalAgeUnderOneYear", "slds-show");
                }
                var ConsumerProposalBalanceOver15000 = creditData.insights.cp.estimatedAmountOverLimit ;
                if(ConsumerProposalBalanceOver15000 == true){
                    component.set("v.ConsumerProposalBalanceOver15000", "slds-show");
                }
                var CreditSoughtDuringConsumerProposal = creditData.insights.cp.inquiriesDuring;
                if(CreditSoughtDuringConsumerProposal == true){
                    component.set("v.CreditSoughtDuringConsumerProposal", "slds-show");
                }
                var CreditObtainedDuringConsumerProposal = creditData.insights.cp.creditDuring;
                if(CreditObtainedDuringConsumerProposal == true){
                    component.set("v.CreditObtainedDuringConsumerProposal", "slds-show");
                }
                var ResidenceTenureUnderOneYear = creditData.residence.durationUnderMin;
                if(ResidenceTenureUnderOneYear == true){
                    component.set("v.ResidenceTenureUnderOneYear", "slds-show");
                }
                var PoorMortgagePaymentHistory = creditData.residence.mortgage.latePayments;
                if(PoorMortgagePaymentHistory == true){
                    component.set("v.PoorMortgagePaymentHistory", "slds-show");
                }
                var PaydayLoans = creditData.warnings.paydayLoans;
                if(PaydayLoans == true){
                    component.set("v.PaydayLoans", "slds-show");
                }
                var IDMismatchWarnings = creditData.warnings.idMismatch;
                if(IDMismatchWarnings == true){
                    component.set("v.IDMismatchWarnings", "slds-show");
                }
                var HighRiskFraudAlerts = creditData.warnings.fraud;
                if(HighRiskFraudAlerts == true){
                    component.set("v.HighRiskFraudAlerts", "slds-show");
                }
                var NoCreditScore = creditData.warnings.noCreditScore;
                if(NoCreditScore == true){
                    component.set("v.NoCreditScore", "slds-show");
                }
                var CreditScoreUnder500 = creditData.warnings.creditScoreUnderMin; 
                if(CreditScoreUnder500 == true){
                    component.set("v.CreditScoreUnder500", "slds-show");
                }
                var DebtInCollections = creditData.warnings.unpaidCollections;
                if(DebtInCollections == true){
                    component.set("v.DebtInCollections", "slds-show");
                }
                var DebtServiceRatioOver50Percent = creditData.dsr.overMax;
                if(DebtServiceRatioOver50Percent == true){
                    component.set("v.DebtServiceRatioOver50Percent", "slds-show");
                }
                
            }
            else if (status === "INCOMPLETE") {
                console.log("No response from server or client is offline.")
            }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                }
        });
        $A.enqueueAction(action);
    },
    setDataTableHeaders :  function (component, event, helper){
        component.set('v.EmploymentColumns', [
            { label: 'EMPLOYER', fieldName: 'companyName' },
            { label: 'ADDRESS', fieldName: '' },
            { label: 'OCCUPATION', fieldName: 'position' },
            { label: 'SINCE', fieldName: 'from_Z' },
            { label: 'CNFRM', fieldName: 'current'}
        ]);
        component.set('v.ResidenceColumns', [
            { label: 'STREET', fieldName: 'streetName' },
            { label: 'CITY', fieldName: 'city'},
            { label: 'PROVINCE', fieldName: 'province' },
            { label: 'POSTALCODE', fieldName: 'postalCode' },
            { label: 'SINCE', fieldName: 'from' },
            { label: 'CONFIRM', fieldName: '' }
        ]);
        
        component.set('v.Inquirycolumns', [
            { label: 'DATE', fieldName: 'eqDate' },
            { label: 'INDUSTRY', fieldName: 'industryCode' },
            { label: 'CREDIT GRANTOR', fieldName: 'inquirerName' },
            { label: 'ACCOUNT NUMBER', fieldName: 'subscriberCode' }
        ]);
        
        component.set('v.BankruptcyInsolvencyColumns', [
            { label: 'RVSD', fieldName: '' },
            { label: 'REPTD', fieldName: 'reportedDate' },
            { label: 'TRUSTEE', fieldName: 'trusteeName' },
            { label: 'ASSETS', fieldName: 'assets'},
            { label: 'LIAB', fieldName: 'liabilities'},
            { label: 'PROPOSAL', fieldName: 'referenceNumber'}
        ]);
        
        component.set('v.RegisteredItemsColumns', [
            { label: 'REPT', fieldName: 'dateFiled' },
            { label: 'OPEN', fieldName: '' },
            { label: 'MATUR', fieldName: 'dateMature' },
            { label: 'AMOUNT', fieldName: 'balance',  },
            { label: 'SECURITY', fieldName: 'security' }
        ]);
        
        component.set('v.TradeColumns', [
            { label: 'REPT', fieldName: 'paymentPatternStart' },
            { label: 'OPEN', fieldName: 'openedOn' },
            { label: 'LAST', fieldName: 'lastActivity' },
            { label: 'H.CREDIT', fieldName: 'openingBalance' },
            { label: 'Balance', fieldName: 'paymentAmount' },
            { label: 'PAST DUE', fieldName: 'amountPastDue' },
            { label: 'TERMS', fieldName: 'paymentSchedule' },
            { label: '30/60/90/#M', fieldName: 'monthsReviewed' },
            { label: 'MOP', fieldName: 'mop' }
        ]);
        
        component.set('v.BankingClosedForCauseColumns', [
            { label: 'REPORTED', fieldName: '' },
            { label: 'OPEN', fieldName: 'dateOpened' },
            { label: 'WRITE OFF', fieldName: '' },
            { label: 'AMOUNT', fieldName: 'balance' },
            { label: 'BB', fieldName: 'subscriberName' },
            { label: 'REASON', fieldName: '' }
        ]);
        
        component.set('v.FileSummaryColumns', [
            { label: 'TYPE', fieldName: 'type' },
            { label: 'COUNT', fieldName: 'count' },
            { label: 'HIGH CRED', fieldName: 'highCredit' },
            { label: 'CRED LIMIT', fieldName: 'creditLimit' },
            { label: 'BALANCE', fieldName: 'balance' },
            { label: 'PAST DUE', fieldName: 'pastDue' },
            { label: 'PAYMENT', fieldName: 'payment' },
            { label: 'AVAILABLE', fieldName: 'available' }
        ]);
    },
    convertToDatatableData : function (component, event, helper){
        
        var creditData = component.get("v.CreditData");
        var creditHistory = creditData.creditHistory;
        var objectToIterate = creditHistory.employments;
        var dataTableArray = [];
        component.set("v.CreditHistoryOverview",creditHistory);
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.current = objectToIterate[i].current;
            objData.companyName = objectToIterate[i].item.companyName;
            objData.position = objectToIterate[i].item.position;
            dataTableArray.push(objData);
        }
        component.set("v.EmploymentData",dataTableArray);
        objectToIterate = creditHistory.addresses;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.streetName = objectToIterate[i].item.civic+' '+objectToIterate[i].item.streetType+' '+objectToIterate[i].item.streetName;
            objData.city = objectToIterate[i].item.city;
            objData.province = objectToIterate[i].item.province;
            objData.postalCode = objectToIterate[i].item.postalCode;
            objData.from = objectToIterate[i].from;
            dataTableArray.push(objData);
        }
        component.set("v.ResidenceData",dataTableArray);
        objectToIterate = creditHistory.inquiries;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.eqDate = objectToIterate[i].eqDate;
            objData.industryCode = objectToIterate[i].industryCode;
            objData.inquirerName = objectToIterate[i].inquirerName;
            objData.subscriberCode = objectToIterate[i].subscriberCode;
            dataTableArray.push(objData);
        }
        component.set("v.Inquirydata",dataTableArray);
        console.log('----convertToDatatableData start-fn---'+creditHistory.bankruptcies);
        console.log(creditHistory.bankruptcies);
        console.log(creditHistory.bankruptcies[0].referenceNumber);
        objectToIterate = creditHistory.bankruptcies;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.referenceNumber = objectToIterate[i].referenceNumber;
            objData.reportedDate = objectToIterate[i].reportedDate;
            objData.trusteeName = objectToIterate[i].trusteeName;
            objData.assets = (objectToIterate[i].assets).toString();
            objData.liabilities = (objectToIterate[i].liabilities).toString();
            dataTableArray.push(objData);
        }
        component.set("v.BankruptcyInsolvencyData",dataTableArray);
        objectToIterate = creditHistory.registeredItems;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.dateMature = objectToIterate[i].dateMature;
            objData.balance = (objectToIterate[i].balance).toString();
            objData.security = objectToIterate[i].security;
            objData.dateFiled = objectToIterate[i].dateFiled;
            dataTableArray.push(objData);
        }
        component.set("v.RegisteredItemsData",dataTableArray);
        objectToIterate = creditHistory.loans;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.openedOn = objectToIterate[i].openedOn;
            objData.mop = objectToIterate[i].mop;
            objData.lastActivity = objectToIterate[i].lastActivity;
            objData.openingBalance = (objectToIterate[i].openingBalance).toString();
            objData.paymentAmount = objectToIterate[i].paymentAmount;
            objData.paymentPatternStart = objectToIterate[i].paymentPatternStart;
            objData.paymentSchedule = objectToIterate[i].paymentSchedule;
            var a= objectToIterate[i].payments30DaysLate;
            var b= objectToIterate[i].payments60DaysLate;
            var c= objectToIterate[i].payments90DaysLate;
            objData.amountPastDue = objectToIterate[i].amountPastDue;
            objData.monthsReviewed = a+'/" '+b+'/" '+c;
            dataTableArray.push(objData);
        }
        component.set("v.TradeData",dataTableArray);
        objectToIterate = creditHistory.bankClosures;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.dateOpened = objectToIterate[i].dateOpened;
            objData.subscriberName = objectToIterate[i].subscriberName;
            objData.balance = objectToIterate[i].balance;
            dataTableArray.push(objData);
        }
        component.set("v.BankingClosedForCauseData",dataTableArray);
        objectToIterate = creditHistory.summaryReport.tradeSummaries;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            objData.balance = (objectToIterate[i].balance).toString();
            if(objectToIterate[i].highCredit != undefined){
                objData.highCredit = (objectToIterate[i].highCredit).toString();
            }else{
                objData.highCredit = '';
            }
            
            if(objectToIterate[i].type != undefined){
                objData.type = (objectToIterate[i].type).toString();
            }else{
                objData.highCredit = '';
            }
            if(objectToIterate[i].creditLimit != undefined){
                objData.creditLimit = (objectToIterate[i].creditLimit).toString();
            }else{
                objData.creditLimit = '';
            }
            if(objectToIterate[i].available != undefined){
                objData.available = (objectToIterate[i].available).toString();
            }else{
                objData.available = '';
            }
            objData.count = (objectToIterate[i].count).toString();
            objData.pastDue = (objectToIterate[i].pastDue).toString();
            objData.payment = (objectToIterate[i].payment).toString();
            dataTableArray.push(objData);
        }
        component.set("v.FileSummaryData",dataTableArray);
    }
})
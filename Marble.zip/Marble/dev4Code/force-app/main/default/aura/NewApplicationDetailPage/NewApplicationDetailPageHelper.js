({
    fetchWrapperData : function(component, event) {
        var actionsaddress = [
            { label: 'Edit', name: 'Edit' },
        ];
            
            component.set('v.addressColumns', [
            {label: 'STREET ADDRESS', fieldName: 'StreetAddress__c', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'STREET ADDRESS', fieldName: '', type: 'text',wrapText: true ,initialWidth:170},
            {label: 'CITY', fieldName: 'City__c', type: 'text',wrapText: true },
            {label: 'Province', fieldName: 'Province__c', type: 'text',wrapText: true },           
            {label: 'POSTAL CODE', fieldName: 'PostalCode__c', type: 'text',wrapText: true ,"": {
            "iconName": {
            "fieldName": "displayIconName"
            }
            }},
            {label: 'COUNTRY', fieldName: 'Country__c', type: 'text',wrapText: true },
            {label: 'MOVED IN', fieldName: 'AddressSinceDate__c', wrapText: true,type: 'date-local'},
            {label: 'MOVED OUT', fieldName: 'AddressEndDate__c',wrapText: true , type: 'date-local',"cellAttributes": {
            "iconName": {
            "fieldName": "displayIconName1"
            }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsaddress } }
        ]);
        
        var actions = [
            { label: 'Edit', name: 'Edit' }   
        ];  
        
        var actionsphone = [
            { label: 'Edit', name: 'Edit' }   
        ];  
        
        
        
        
        component.set('v.emailColumns', [
            // {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'ADDRESS', fieldName: 'EmailAddress__c', type: 'email',wrapText: true,editable:true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c', type: 'boolean',wrapText: true ,editable:true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actions } }
        ]);
        
        component.set('v.phoneColumns', [
            {label: 'TYPE', fieldName: 'PhoneType__c', type: 'text',wrapText: true ,editable: true},
            {label: 'NUMBER', fieldName: 'PhoneNumber__c', type: 'phone',wrapText: true , editable: true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c' , type: 'boolean',wrapText: true , editable: true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsphone } }
        ]);
        
        
        component.set('v.coaddressColumns', [
            {label: 'STREET ADDRESS', fieldName: 'StreetAddress__c', wrapText: true , type: 'text',initialWidth:170},
            {label: 'CITY', fieldName: 'City__c', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'COUNTRY', fieldName: 'Country__c', type: 'text',wrapText: true },
            {label: 'Unit', fieldName: 'Unit__c', type: 'text',wrapText: true ,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            {label: 'Province', fieldName: 'Province__c', type: 'text',wrapText: true },
            {label: 'MOVED IN', fieldName: 'AddressSinceDate__c', type: 'date-local',wrapText: true },
            {label: 'MOVED OUT', fieldName: 'AddressEndDate__c', wrapText: true ,type: 'date-local',"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName1"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsaddress } }
        ]);
        
        component.set('v.coemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text',wrapText: true ,editable: true},
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email',wrapText: true , editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean',wrapText: true , editable: true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }
            }
        ]);
        
        component.set('v.cophoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text',wrapText: true ,editable: true},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone', wrapText: true ,editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean',wrapText: true , editable: true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsphone } }
        ]);
        
        
        
        component.set('v.cosaddressColumns', [
            {label: 'STREET ADDRESS', fieldName: 'StreetAddress__c', type: 'text',wrapText: true ,initialWidth:170},
            {label: 'CITY', fieldName: 'City__c', type: 'text',wrapText: true ,initialWidth:170},
            {label: 'COUNTRY', fieldName: 'Country__c', type: 'text',wrapText: true },
            {label: 'Unit', fieldName: 'Unit__c', type: 'text',wrapText: true ,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            {label: 'Province', fieldName: 'Province__c', type: 'text',wrapText: true },
            {label: 'MOVED IN', fieldName: 'AddressSinceDate__c',wrapText: true , type: 'date-local'},
            {label: 'MOVED OUT', fieldName: 'AddressEndDate__c', wrapText: true ,type: 'date-local',"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName1"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsaddress } }
        ]);
        
        component.set('v.cosemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text',editable: true,wrapText: true },
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email',wrapText: true , editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean',wrapText: true , editable: true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }}
        ]);
        
        component.set('v.cosphoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone',wrapText: true , editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean', wrapText: true ,editable: true,"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName"
                }
            }},
            { type: 'action', typeAttributes: { rowActions: actionsphone } }
        ]);
        
        component.set('v.cosLoanDebtColumns', [
            {label: 'LOAN/DEBT TYPE', fieldName: '', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'GRANTOR', fieldName: '', type: 'text', editable: true,wrapText: true,initialWidth:170 },
            {label: 'MONTHLY PAYMENT', fieldName: '' , type: 'text', editable: true,wrapText: true },
            {label: 'OUTSTANDING BALANCE', fieldName: '' , type: 'text', editable: true,wrapText: true }
        ]);
        
        component.set('v.cosempColumns', [
            {label: 'COMPANY', fieldName: 'Name', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'JOB TITLE', fieldName: 'Position__c', wrapText: true ,type: 'text',cellAttributes: { alignment: 'left' }},
            {label: 'START DATE', fieldName: 'EmploymentStartDate__c' ,wrapText: true , type: 'date-local'},
            {label: 'END DATE', fieldName: 'EmploymentEndDate__c' , wrapText: true ,type: 'date-local',"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName30"
                }
            }},
            {label: 'FIRST JOB', fieldName: 'IsFirstJob__c' , wrapText: true ,type: 'text'},
            { type: 'action', typeAttributes: { rowActions: actions } }
        ]);
        
        component.set('v.coempColumns', [
            {label: 'COMPANY', fieldName: 'Name', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'JOB TITLE', fieldName: 'Position__c',wrapText: true , type: 'text',cellAttributes: { alignment: 'left' }},
            {label: 'START DATE', fieldName: 'EmploymentStartDate__c' ,wrapText: true , type: 'date-local'},
            {label: 'END DATE', fieldName: 'EmploymentEndDate__c' ,wrapText: true , type: 'date-local',"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName20"
                }
            }},
            {label: 'FIRST JOB', fieldName: 'IsFirstJob__c' , type: 'text',wrapText: true },
            { type: 'action', typeAttributes: { rowActions: actions } }
        ]);
        
        component.set('v.empColumns', [
            {label: 'COMPANY', fieldName: 'Name', type: 'text',wrapText: true ,initialWidth:170},
            {label: 'JOB TITLE', fieldName: 'Position__c',wrapText: true , type: 'text',cellAttributes: { alignment: 'left' }},
            {label: 'START DATE', fieldName: 'EmploymentStartDate__c' , wrapText: true ,type: 'date-local'},
            {label: 'END DATE', fieldName: 'EmploymentEndDate__c' , wrapText: true ,type: 'date-local',"cellAttributes": {
                "iconName": {
                    "fieldName": "displayIconName10"
                }
            }},
            {label: 'FIRST JOB', fieldName: 'IsFirstJob__c' , type: 'text',wrapText: true },
            { type: 'action', typeAttributes: { rowActions: actions } }
        ]);
        
        component.set('v.borrowerLiabilityColumns', [
            {label: 'LOAN TYPE', fieldName: 'LiabilityType__c', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'LOAN TYPE', fieldName: '', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'GRANTOR', fieldName: 'CreditorManual__c', wrapText: true,initialWidth:170 ,type: 'text',cellAttributes: { alignment: 'left' }},
            {label: 'MONTHLY PAYMENT', fieldName: 'PaymentAmountManual__c' , wrapText: true ,type: 'currency', cellAttributes: { alignment: 'left' }},
            {label: 'OUTSTANDING BALANCE', fieldName: 'RemainingBalanceManual__c' , wrapText: true ,type: 'currency',cellAttributes: { alignment: 'left' }},
            { type: 'action', typeAttributes: { rowActions: actions } }
            
        ]);  
        
        
        component.set('v.cosignerLiabilityColumns', [
            {label: 'LOAN TYPE', fieldName: 'LiabilityType__c', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'LOAN TYPE', fieldName: '', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'GRANTOR', fieldName: 'CreditorManual__c', wrapText: true,initialWidth:170 ,type: 'text', cellAttributes: { alignment: 'left' }},
            {label: 'MONTHLY PAYMENT', fieldName: 'PaymentAmountManual__c' , wrapText: true ,type: 'currency', cellAttributes: { alignment: 'left' }},
            {label: 'OUTSTANDING BALANCE', fieldName: 'RemainingBalanceManual__c' , wrapText: true ,type: 'currency',cellAttributes: { alignment: 'left' }},
            { type: 'action', typeAttributes: { rowActions: actions } }
            
        ]);  
        
        
        component.set('v.coborrowerLiabilityColumns', [
            {label: 'LOAN TYPE', fieldName: 'LiabilityType__c', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'LOAN TYPE', fieldName: '', type: 'text',wrapText: true,initialWidth:170 },
            {label: 'GRANTOR', fieldName: 'CreditorManual__c', type: 'text',wrapText: true,initialWidth:170 , cellAttributes: { alignment: 'left' }},
            {label: 'MONTHLY PAYMENT', fieldName: 'PaymentAmountManual__c' , type: 'currency', wrapText: true ,cellAttributes: { alignment: 'left' }},
            {label: 'OUTSTANDING BALANCE', fieldName: 'RemainingBalanceManual__c' , type: 'currency',wrapText: true ,cellAttributes: { alignment: 'left' }},
            { type: 'action', typeAttributes: { rowActions: actions } }
            
        ]);  
        
        
        var recId = component.get('v.recordId');
        var action = component.get("c.getApplicationData");
        action.setParams({
            "appId": recId
        });
        action.setCallback(this, function(response){
            console.log("Action Called");
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.applicationWrapper", response.getReturnValue());
                var applicationwrapper = response.getReturnValue();
                console.log("Value of Consent : "+applicationwrapper.ConsentOfBorrowerTest);
                if(applicationwrapper != null ){
                    var applicationRec = applicationwrapper.ApplicationDetail;
                    component.set('v.currentApplicationStatus', applicationRec.ApplicationStatus__c);
                    //   component.set('v.currentLoanAmount',applicationRec.LoanAmount__c);
                    var borrower = applicationwrapper.Borrower;
                    var coborrower = applicationwrapper.CoBorrower;
                    var cosigners = applicationwrapper.CoSigner;
                    var fastappsapp ;
                    var autofastapp;
                    var fastappsappcob ;
                    var autofastappcob;
                    var fastappsappcos ;
                    var autofastappcos;
                    var borrwerBudget = applicationwrapper.BorrowerBudget;
                    var coborrwerBudget = applicationwrapper.CoBorrowerBudget;
                    var cosignerBudget = applicationwrapper.CoSignerBudget;
                    var borlia = applicationwrapper.borrowerLiability;
                    var coblia = applicationwrapper.coborrowerLiability;
                    var coslia = applicationwrapper.cosignerLiability;
                    
                    
                    //Liability dattable Mapping Borrower
                    if(borlia != null && borlia != undefined ){
                        component.set('v.borrowerLiabilityData',borlia);
                        borlia.forEach(function(record){
                            if(record.LiabilityType__c == 'MORTGAGE_PAYMENT')
                                component.set('v.borliamortage',record);
                        });
                        
                    }
                    
                    if(coblia != null && coblia != undefined ){
                        component.set('v.coborrowerLiabilityData',coblia);
                        coblia.forEach(function(record){
                            if(record.LiabilityType__c == 'MORTGAGE_PAYMENT')
                                component.set('v.cobliamortage',record);
                        });
                    }
                    
                    if(coslia != null && coslia != undefined ){
                        component.set('v.cosignerLiabilityData',coslia);
                          coslia.forEach(function(record){
                            if(record.LiabilityType__c == 'MORTGAGE_PAYMENT')
                                component.set('v.cosliamortage',record);
                        });
                        
                    }
                    
                    
                    var ftasaList = applicationwrapper.FastTrackAppSpecficApplicant;
                    console.log('fasttrackonscreen');
                    console.log(JSON.stringify(ftasaList));
                    ftasaList.forEach(function(record){ 
                        if(record.BorrowingStructure__r.Type__c == 'BORROWER'){
                            if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                                component.set('v.ftasa', record)
                                fastappsapp = record;
                            }else{
                                component.set('v.ftasaAutomatic', record);
                                autofastapp = record;
                            }  
                        }else if(record.BorrowingStructure__r.Type__c == 'COBORROWER'){
                            if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                                component.set('v.ftasaCoborrower', record)
                                fastappsappcob = record;
                            }else{
                                component.set('v.ftasaAutomaticCoborrower', record);
                                autofastappcob = record;
                            }  
                        }else if(record.BorrowingStructure__r.Type__c == 'COSIGNER'){
                            if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                                component.set('v.ftasaCosigner', record)
                                fastappsappcos = record;
                            }else{
                                component.set('v.ftasaAutomaticCosigner', record);
                                autofastappcos = record;
                            }  
                        }
                        
                    }); 
                    
                    component.set('v.applicationRec',applicationRec);
                    component.set('v.borrower',borrower[0]);
                    component.set('v.borrowerId',borrower[0].Id);
                    if(coborrower != null && coborrower.length > 0 ){
                        component.set('v.coborrower',coborrower[0]);
                        component.set('v.coborrowerId',coborrower[0].Id);
                    }
                    if(cosigners != null && cosigners.length > 0){
                        component.set('v.cosigners', cosigners);
                        component.set('v.cosignerId',cosigners[0].Id);
                    }
                    
                    //Manual// Auto Entry for borrower
                    if(fastappsapp != null && fastappsapp != '' && fastappsapp !='undefined' ){
                        if(autofastapp != null && autofastapp != '' && autofastapp !='undefined' ){
                            if(!fastappsapp.ManualUpdate__c){
                                fastappsapp.InConsumerProposal__c = autofastapp.InConsumerProposal__c;
                                fastappsapp.ConsumerProposalDate__c = autofastapp.ConsumerProposalDate__c;
                            }   
                            if(!fastappsapp.ManualPreApproval__c){
                                fastappsapp.ConsumerLoanAmount__c = autofastapp.ConsumerLoanAmount__c;
                                fastappsapp.PayPerCheque__c = autofastapp.PayPerCheque__c;
                                fastappsapp.MonthsAtCurrentJob__c = autofastapp.MonthsAtCurrentJob__c;
                                fastappsapp.PayFrequency__c = autofastapp.PayFrequency__c;
                                fastappsapp.HasActivePaydayLoans__c = autofastapp.HasActivePaydayLoans__c;
                                fastappsapp.HasMoreThanThreeNSFs__c = autofastapp.HasMoreThanThreeNSFs__c;
                            }
                        }
                        /*MD01 component.set('v.jointproposal',fastappsapp.JointProposal__c);*/
                        /*MD01	component.set('v.consumerproposal',fastappsapp.InConsumerProposal__c);*/
                        component.set('v.ftasa',fastappsapp );
                        console.log(JSON.stringify(component.get('v.ftasa')));
                    }
                    
                    //Manual// Auto Entry for coborrower
                    if(fastappsappcob != null && fastappsappcob != '' && fastappsappcob !='undefined' ){
                        if(autofastappcob != null && autofastappcob != '' && autofastappcob !='undefined' ){
                            if(!fastappsappcob.ManualUpdate__c){
                                fastappsappcob.InConsumerProposal__c = autofastappcob.InConsumerProposal__c;
                                fastappsappcob.ConsumerProposalDate__c = autofastappcob.ConsumerProposalDate__c;
                            }   
                            if(!fastappsappcob.ManualPreApproval__c){
                                fastappsappcob.ConsumerLoanAmount__c = autofastappcob.ConsumerLoanAmount__c;
                                fastappsappcob.PayPerCheque__c = autofastappcob.PayPerCheque__c;
                                fastappsappcob.MonthsAtCurrentJob__c = autofastappcob.MonthsAtCurrentJob__c;
                                fastappsappcob.PayFrequency__c = autofastappcob.PayFrequency__c;
                                fastappsappcob.HasActivePaydayLoans__c = autofastappcob.HasActivePaydayLoans__c;
                                fastappsappcob.HasMoreThanThreeNSFs__c = autofastappcob.HasMoreThanThreeNSFs__c;
                            }
                        }
                        component.set('v.ftasaCoborrower',fastappsappcob );
                        console.log(JSON.stringify(component.get('v.ftasaCoborrower')));
                    }
                    
                    //Manual// Auto Entry for cosigner
                    if(fastappsappcos != null && fastappsappcos != '' && fastappsappcos !='undefined' ){
                        if(autofastappcos != null && autofastappcos != '' && autofastappcos !='undefined' ){
                            if(!fastappsappcos.ManualUpdate__c){
                                fastappsappcos.InConsumerProposal__c = autofastappcos.InConsumerProposal__c;
                                fastappsappcos.ConsumerProposalDate__c = autofastappcos.ConsumerProposalDate__c;
                            }   
                            if(!fastappsappcos.ManualPreApproval__c){
                                fastappsappcos.ConsumerLoanAmount__c = autofastappcos.ConsumerLoanAmount__c;
                                fastappsappcos.PayPerCheque__c = autofastappcos.PayPerCheque__c;
                                fastappsappcos.MonthsAtCurrentJob__c = autofastappcos.MonthsAtCurrentJob__c;
                                fastappsappcos.PayFrequency__c = autofastappcos.PayFrequency__c;
                                fastappsappcos.HasActivePaydayLoans__c = autofastappcos.HasActivePaydayLoans__c;
                                fastappsappcos.HasMoreThanThreeNSFs__c = autofastappcos.HasMoreThanThreeNSFs__c;
                            }
                        }
                        component.set('v.ftasaCosigner',fastappsappcos );
                        console.log(JSON.stringify(component.get('v.ftasaCosigner')));
                    }
                    
                    if(borrower != null && borrower != '' && borrower !='undefined' ){
                        
                        
                        //        component.set('v.', borrower[0].Addresses__r);
                        if(borrower[0].Addresses__r != null && borrower[0].Addresses__r.length > 0 ){
                            var addresses = borrower[0].Addresses__r;
                            var finalAddress =[];
                            addresses.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    component.set('v.borPrimAddress',record);
                                } 
                                
                                if(!record.Unit__c)
                                    record.displayIconName = 'utility:dash';  
                                
                                if(!record.AddressEndDate__c)
                                    record.displayIconName1 = 'utility:dash';  
                                
                                finalAddress.push(record);
                                
                            }); 
                            component.set('v.addressList', finalAddress);
                        }
                        
                        if(applicationwrapper.ConsentOfBorrower){
                            component.set('v.borrowerconsent',"true");
                            component.set('v.previousborrowerconsent',"true");
                            
                        }else{
                            component.set('v.borrowerconsent',"");
                            component.set('v.previousborrowerconsent',"");
                        }
                        
                        
                        if( borrower[0].Emails__r != null){
                            var emailList = borrower[0].Emails__r;
                            var finalEmailList =[]
                            emailList.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    //    record.displayIconName = 'utility:check';  
                                }else{
                                    record.displayIconName = 'utility:dash';  
                                }
                                finalEmailList.push(record);
                            });
                            component.set('v.emailList', finalEmailList);
                        }
                        
                        if(  borrower[0].Phones__r != null){
                            var phoneList =  borrower[0].Phones__r;
                            var finalPhoneList =[]
                            phoneList.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    //    record.displayIconName = 'utility:check';  
                                }else{
                                    record.displayIconName = 'utility:dash';  
                                }
                                finalPhoneList.push(record);
                            });
                            component.set('v.phoneList', finalPhoneList);
                        } 
                        //  component.set('v.phoneList', borrower[0].Phones__r);
                        
                        if(borrower[0].Employments__r != null && borrower[0].Employments__r != undefined){
                            
                            var emptList = borrower[0].Employments__r;
                            var finalEmpList =[];
                            emptList.forEach(function(record){
                                if(!record.EmploymentEndDate__c){
                                    // record.EmploymentEndDate__c = null;
                                    record.displayIconName10 = 'utility:dash';  
                                }
                                
                                finalEmpList.push(record);
                            });
                            component.set('v.empList', finalEmpList);
                            
                            //   component.set('v.empList', borrower[0].Employments__r);
                            if(borrower[0].Employments__r[0] != null && borrower[0].Employments__r[0] != undefined)
                                component.set('v.presentEmp', borrower[0].Employments__r[0]);
                        }
                        
                        
                        if(borrwerBudget != null && borrwerBudget != undefined){
                            if(borrwerBudget.INCOME != undefined)
                                component.set('v.borrowerIncomeBudgetRecord', borrwerBudget.INCOME);
                            if(borrwerBudget.RENT_OR_MORTGAGE != undefined)
                                component.set('v.borrowerMortgageBudgetRecord',borrwerBudget.RENT_OR_MORTGAGE);
                            if(borrwerBudget.PROPERTY_TAXES != undefined)
                                component.set('v.borrowerPropertyBudgetRecord',borrwerBudget.PROPERTY_TAXES);
                            if(borrwerBudget.HOME_INSURANCE != undefined)
                                component.set('v.borrowerHomeInsuranceBudgetRecord',borrwerBudget.HOME_INSURANCE);
                            if(borrwerBudget.STRATA_FEES != undefined)
                                component.set('v.borrowerStrataBudgetRecord',borrwerBudget.STRATA_FEES);
                        }
                        
                    }
                    
                    if(coborrower != null && coborrower != '' && coborrower !='undefined'){  
                        if(applicationwrapper.ConsentOfCoBorrower){
                            component.set('v.coborrowerconsent',"true");
                            component.set('v.previouscobrwconsent',"true");   
                        }else{
                            component.set('v.coborrowerconsent',"");
                            component.set('v.previouscobrwconsent',"");
                        }
                        
                        
                        if(coborrower[0].Addresses__r != null && coborrower[0].Addresses__r.length > 0 ){
                            var addresses = coborrower[0].Addresses__r;
                            var finalAddress =[];
                            addresses.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    component.set('v.cobPrimAddress',record);
                                }
                                if(!record.Unit__c)
                                    record.displayIconName = 'utility:dash';  
                                
                                if(!record.AddressEndDate__c)
                                    record.displayIconName1 = 'utility:dash';
                                
                                finalAddress.push(record);
                            });  
                            component.set('v.coaddressList', finalAddress); 
                        }
                        
                        
                        if( coborrower[0].Emails__r != null){
                            var emailList = coborrower[0].Emails__r;
                            var finalEmailList =[]
                            emailList.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    //    record.displayIconName = 'utility:check';  
                                }else{
                                    record.displayIconName = 'utility:dash';  
                                }
                                finalEmailList.push(record);
                            });
                            component.set('v.coemailList', finalEmailList);
                        }
                        
                        if(  coborrower[0].Phones__r != null){
                            var phoneList =  coborrower[0].Phones__r;
                            var finalPhoneList =[]
                            phoneList.forEach(function(record){ 
                                if(record.IsPrimary__c){
                                    //    record.displayIconName = 'utility:check';  
                                }else{
                                    record.displayIconName = 'utility:dash';  
                                }
                                finalPhoneList.push(record);
                            });
                            component.set('v.cophoneList', finalPhoneList);
                        } 
                        
                        
                        
                        
                        
                        //   component.set('v.coemailList', coborrower[0].Emails__r);                    
                        //   component.set('v.cophoneList', coborrower[0].Phones__r);    
                        console.log(JSON.stringify(coborrower[0].Employments__r));
                        if(coborrower[0].Employments__r != null && coborrower[0].Employments__r != undefined){
                            
                            
                            var emptList = coborrower[0].Employments__r;
                            var finalEmpList =[];
                            emptList.forEach(function(record){
                                if(!record.EmploymentEndDate__c){
                                    // record.EmploymentEndDate__c = null;
                                    record.displayIconName20 =  'utility:dash';  
                                }
                                
                                finalEmpList.push(record);
                            });
                            component.set('v.coempList', finalEmpList);
                            
                            //     component.set('v.coempList', coborrower[0].Employments__r);
                            if(coborrower[0].Employments__r != null && coborrower[0].Employments__r != undefined)
                                component.set('v.cobpresentEmp', coborrower[0].Employments__r[0]);
                        }
                        
                        
                        
                        if(coborrwerBudget != null && coborrwerBudget != undefined){
                            if(coborrwerBudget.INCOME != undefined)
                                component.set('v.coborrowerIncomeBudgetRecord', coborrwerBudget.INCOME);
                            if(coborrwerBudget.RENT_OR_MORTGAGE != undefined)
                                component.set('v.coborrowerMortgageBudgetRecord',coborrwerBudget.RENT_OR_MORTGAGE);  
                            if(coborrwerBudget.PROPERTY_TAXES != undefined)
                                component.set('v.coborrowerPropertyBudgetRecord',coborrwerBudget.PROPERTY_TAXES);
                            if(coborrwerBudget.HOME_INSURANCE != undefined)
                                component.set('v.coborrowerHomeInsuranceBudgetRecord',coborrwerBudget.HOME_INSURANCE);
                            if(coborrwerBudget.STRATA_FEES != undefined)
                                component.set('v.coborrowerStrataBudgetRecord',coborrwerBudget.STRATA_FEES);
                            
                        }
                    }
                    
                    if(cosigners != null && cosigners != undefined){
                        var inactivecos =[]
                        var activecos;
                        cosigners.forEach(function(record){ 
                            component.set('v.activecosigner',record);
                            
                            activecos = record                                                         
                        }); 
                        if(activecos != null && activecos != undefined){
                            
                            if(applicationwrapper.ConsentOfCoSigner){
                                component.set('v.cosignerconsent',"true");
                                component.set('v.previouscosionsent',"true");
                            }else{
                                component.set('v.cosignerconsent',"");
                                component.set('v.previouscosionsent',"");
                            }
                            // component.set('v.cosaddressList', activecos.Addresses__r);   
                            if(activecos.Addresses__r != null && activecos.Addresses__r.length > 0 ){
                                var addresses = activecos.Addresses__r;
                                var finalAddress =[];
                                addresses.forEach(function(record){ 
                                    if(record.IsPrimary__c){
                                        component.set('v.cosPrimAddress',record);
                                    }
                                    
                                    if(!record.Unit__c)
                                        record.displayIconName = 'utility:dash';  
                                    
                                    if(!record.AddressEndDate__c)
                                        record.displayIconName1 = 'utility:dash';  
                                    
                                    finalAddress.push(record);
                                }); 
                                
                                component.set('v.cosaddressList', finalAddress); 
                            }
                            
                            if(  activecos.Emails__r != null){
                                var emailList =  activecos.Emails__r;
                                var finalEmailList =[]
                                emailList.forEach(function(record){ 
                                    if(record.IsPrimary__c){
                                        //    record.displayIconName = 'utility:check';  
                                    }else{
                                        record.displayIconName = 'utility:dash';  
                                    }
                                    finalEmailList.push(record);
                                });
                                component.set('v.cosemailList', finalEmailList);
                            }
                            
                            
                            //    component.set('v.cosemailList', activecos.Emails__r);     
                            
                            
                            if(  activecos.Phones__r != null){
                                var phoneList =  activecos.Phones__r;
                                var finalPhoneList =[]
                                phoneList.forEach(function(record){ 
                                    if(record.IsPrimary__c){
                                        //    record.displayIconName = 'utility:check';  
                                    }else{
                                        record.displayIconName = 'utility:dash';  
                                    }
                                    finalPhoneList.push(record);
                                });
                                component.set('v.cosphoneList', finalPhoneList);
                            } 
                            
                            //   component.set('v.cosphoneList', activecos.Phones__r);                    
                            component.set('v.cosempList', activecos.Employments__r);

                            
                            
                            if(activecos.Employments__r != null && activecos.Employments__r != undefined){
                                
                                
                                var emptList = activecos.Employments__r;
                                var finalEmpList =[];
                                emptList.forEach(function(record){
                                    if(!record.EmploymentEndDate__c){
                                        // record.EmploymentEndDate__c = null;
                                        record.displayIconName30 = 'utility:dash';  
                                    }
                                    
                                    finalEmpList.push(record);
                                });
                                component.set('v.cospresentEmp', finalEmpList);
                                
                                //        component.set('v.cospresentEmp', activecos.Employments__r[0]);
                            }
                            
                            
                            
                            if(cosignerBudget != null && cosignerBudget != undefined){
                                if(cosignerBudget.INCOME != undefined)
                                    component.set('v.cosignerIncomeBudgetRecord', cosignerBudget.INCOME);
                                if(cosignerBudget.RENT_OR_MORTGAGE != undefined)
                                    component.set('v.cosignerMortgageBudgetRecord',cosignerBudget.RENT_OR_MORTGAGE);   
                                if(cosignerBudget.PROPERTY_TAXES != undefined)
                                    component.set('v.cosignerPropertyBudgetRecord',cosignerBudget.PROPERTY_TAXES);
                                if(cosignerBudget.HOME_INSURANCE != undefined)
                                    component.set('v.cosignerHomeInsuranceBudgetRecord',cosignerBudget.HOME_INSURANCE);
                                if(cosignerBudget.STRATA_FEES != undefined)
                                    component.set('v.cosignerStrataBudgetRecord',cosignerBudget.STRATA_FEES);
                                
                            }
                        }
                        
                    }
                    
                }
                
                if(component.get('v.eventcall'))
                    component.set('v.isVisible',true);
            }
        });
        $A.enqueueAction(action);
        //  component.find("tab1").set("v.selectedTabId", "coborrowerTabId");
        
    },
    
    updateRecs : function(component, event, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            coborrowr.Consent__pc = component.get('v.coborrowerconsent');
            objList.push(coborrowr);
            
        }else if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            console.log(JSON.stringify(borrowr));
            var previousconsent = component.get('v.previousborrowerconsent');
            borrowr.Consent__pc = component.get('v.borrowerconsent');
            if(previousconsent != component.get('v.borrowerconsent') ){
                updateApplication =true;
            }
            
            objList.push(borrowr);    
            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            cosignr.Consent__pc = component.get('v.cosignerconsent');
            objList.push(cosignr);        
        }else if(rectype =='appSpecfic'){
            var appsepcRec = component.get('v.ftasa');
            /* MD01 appsepcRec.JointProposal__c = component.get('v.jointproposal');*/
            /** MD01 appsepcRec.InConsumerProposal__c = component.get('v.consumerproposal');*/
            appsepcRec.MunualUpdate__c =true;
            objList.push(appsepcRec);
        }
        console.log(JSON.stringify(appsepcRec));
        var action = component.get("c.updateRecords");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        //  window.open('/'+ component.get('v.recordId'),'_self');
                        location.reload(true);
                    }), 5000
                );
                
                
                if(accType =='coborrower'){
                    component.set('v.cobviewmode',true);
                    component.set('v.cobappLabel','Edit');
                }
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
                
                if(accType =='cosigner' ){
                    component.set('v.cosviewmode',true);
                    component.set('v.cosappLabel','Edit');
                }
                
                if(accType =='appSpecfic' ){
                    component.set('v.ftasaviewmode',true);
                    component.set('v.ftasaLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    updateBorrowerPreApproval : function(component, event, helper, bsType) {
        
        var currentApplication = component.get('v.applicationRec');
        var updateApp = false;
        var objList = [];
        var liab =[];
        if(component.get('v.currentApplicationStatus') != currentApplication.ApplicationStatus__c){
            updateApp = true;
            
        }
        var fastTrackApp;
        var account;
        if(bsType == 'borrower'){
            fastTrackApp = component.get('v.ftasa');
            var borrower = component.get('v.borrower');
            account = borrower;
            if(borrower.NumberOfDependents__pc != null){
                delete borrower["Name"];
                objList.push(borrower);
                
            }
            
            var borCurrentEMp = component.get('v.presentEmp');
            var CurrentAddress = component.get('v.borPrimAddress');
            
            if(CurrentAddress != null && CurrentAddress != undefined)
                objList.push(CurrentAddress);
            
            if( borCurrentEMp != null && borCurrentEMp != undefined )
                objList.push(borCurrentEMp);
            
            //Income Update
            if(component.get('v.borrowerIncomeBudgetRecord') != null && component.get('v.borrowerIncomeBudgetRecord') != undefined)
            {
                var income = component.get('v.borrowerIncomeBudgetRecord');
                objList.push(income);
            }
            
            //Mortgage Update
            if(component.get('v.borrowerMortgageBudgetRecord') != null && component.get('v.borrowerMortgageBudgetRecord') != undefined)
            {
                var mortgage = component.get('v.borrowerMortgageBudgetRecord');
                objList.push(mortgage);
            }
            
            //Proprty Update
            if(component.get('v.borrowerPropertyBudgetRecord') != null && component.get('v.borrowerPropertyBudgetRecord') != undefined)
            {
                var property = component.get('v.borrowerPropertyBudgetRecord');
                objList.push(property);
            }
            
            //Home Insurance Update
            if(component.get('v.borrowerHomeInsuranceBudgetRecord') != null && component.get('v.borrowerHomeInsuranceBudgetRecord') != undefined)
            {
                var homeinsurance = component.get('v.borrowerHomeInsuranceBudgetRecord');
                objList.push(homeinsurance);
            }
            
            //--Strata Fees Upate-->
            
            if(component.get('v.borrowerStrataBudgetRecord') != null && component.get('v.borrowerStrataBudgetRecord') != undefined)
            {
                var strata = component.get('v.borrowerStrataBudgetRecord');
                objList.push(strata);
            }
            
            if(component.get('v.borliamortage') != null && component.get('v.borliamortage') != undefined){
                var morty = component.get('v.borliamortage');
                morty.BorrowingStructure__c =  fastTrackApp.BorrowingStructure__c;
                liab.push(morty);
            }
            
        }
        else if(bsType =='coborrower'){
            fastTrackApp = component.get('v.ftasaCoborrower');
            var cborrower = component.get('v.coborrower');
            account = cborrower;
            if(cborrower.NumberOfDependents__pc != null){
                delete cborrower["Name"];
                objList.push(cborrower);
            }         
            
            var cobCurrentEMp = component.get('v.cobpresentEmp');
            if(cobCurrentEMp != null && cobCurrentEMp != undefined)
                objList.push(cobCurrentEMp);
            
            
            var CurrentAddress = component.get('v.cobPrimAddress');
            
            if(CurrentAddress != null && CurrentAddress != undefined)
                objList.push(CurrentAddress);
            
            if(component.get('v.coborrowerIncomeBudgetRecord') != null && component.get('v.coborrowerIncomeBudgetRecord') != undefined)
            {
                var income = component.get('v.coborrowerIncomeBudgetRecord');
                objList.push(income);
            }
            
            //Mortgage Update
            if(component.get('v.coborrowerMortgageBudgetRecord') != null && component.get('v.coborrowerMortgageBudgetRecord') != undefined)
            {
                var mortgage = component.get('v.coborrowerMortgageBudgetRecord');
                objList.push(mortgage);
            }
            
            //Proprty Update
            if(component.get('v.coborrowerPropertyBudgetRecord') != null && component.get('v.coborrowerPropertyBudgetRecord') != undefined)
            {
                var property = component.get('v.coborrowerPropertyBudgetRecord');
                objList.push(property);
            }
            
            //Home Insurance Update
            if(component.get('v.coborrowerHomeInsuranceBudgetRecord') != null && component.get('v.coborrowerHomeInsuranceBudgetRecord') != undefined)
            {
                var homeinsurance = component.get('v.coborrowerHomeInsuranceBudgetRecord');
                objList.push(homeinsurance);
            }
            
            //--Strata Fees Upate-->
            
            if(component.get('v.coborrowerStrataBudgetRecord') != null && component.get('v.coborrowerStrataBudgetRecord') != undefined)
            {
                var strata = component.get('v.coborrowerStrataBudgetRecord');
                objList.push(strata);
            }
            
             if(component.get('v.cobliamortage') != null && component.get('v.cobliamortage') != undefined){
                var morty = component.get('v.cobliamortage');
                morty.BorrowingStructure__c =  fastTrackApp.BorrowingStructure__c;
                liab.push(morty);
            }
        }
        
        
            else if(bsType == 'cosigner'){
                fastTrackApp = component.get('v.ftasaCosigner');
                var csorrower = component.get('v.activecosigner');
                account = csorrower;
                if(csorrower.NumberOfDependents__pc != null){
                    delete csorrower["Name"];
                    objList.push(csorrower);
                } 
                
                var cosCurrentEMp = component.get('v.cospresentEmp');
                if(cosCurrentEMp != undefined && cosCurrentEMp != null)
                    objList.push(cosCurrentEMp);
                
                var CurrentAddress = component.get('v.cosPrimAddress');
                
                if(CurrentAddress != null && CurrentAddress != undefined)
                    objList.push(CurrentAddress);
                
                if(component.get('v.cosignerIncomeBudgetRecord') != null && component.get('v.cosignerIncomeBudgetRecord') != undefined)
                {
                    var income = component.get('v.cosignerIncomeBudgetRecord');
                    objList.push(income);
                }
                //Mortgage Update
                if(component.get('v.cosignerMortgageBudgetRecord') != null && component.get('v.cosignerMortgageBudgetRecord') != undefined)
                {
                    var mortgage = component.get('v.cosignerMortgageBudgetRecord');
                    objList.push(mortgage);
                }
                
                //Proprty Update
                if(component.get('v.cosignerPropertyBudgetRecord') != null && component.get('v.cosignerPropertyBudgetRecord') != undefined)
                {
                    var property = component.get('v.cosignerPropertyBudgetRecord');
                    objList.push(property);
                }
                
                //Home Insurance Update
                if(component.get('v.cosignerHomeInsuranceBudgetRecord') != null && component.get('v.cosignerHomeInsuranceBudgetRecord') != undefined)
                {
                    var homeinsurance = component.get('v.cosignerHomeInsuranceBudgetRecord');
                    objList.push(homeinsurance);
                }
                
                //--Strata Fees Upate-->
                
                if(component.get('v.cosignerStrataBudgetRecord') != null && component.get('v.cosignerStrataBudgetRecord') != undefined)
                {
                    var strata = component.get('v.cosignerStrataBudgetRecord');
                    objList.push(strata);
                }
                
                 if(component.get('v.cosliamortage') != null && component.get('v.cosliamortage') != undefined){
                var morty = component.get('v.cosliamortage');
                  morty.BorrowingStructure__c =  fastTrackApp.BorrowingStructure__c;
                liab.push(morty);
            }
            }
        
        if(fastTrackApp.EmploymentStartDate__c != null){
            var res = fastTrackApp.EmploymentStartDate__c.split("-");            
            fastTrackApp.EmploymentStartMonth__c = res[1];
            fastTrackApp.EmploymentStartYear__c = res[0];
        }
        
        
        
        if((fastTrackApp.ConsumerLoanAmount__c != undefined && fastTrackApp.ConsumerLoanAmount__c != '') || 
           (fastTrackApp.PayPerCheque__c != undefined && fastTrackApp.PayPerCheque__c != '') ||
           (fastTrackApp.MonthsAtCurrentJob__c != undefined && fastTrackApp.MonthsAtCurrentJob__c != '' )||
           (fastTrackApp.PayFrequency__c != undefined && fastTrackApp.PayFrequency__c != '') ||
           (fastTrackApp.HasActivePaydayLoans__c != undefined && fastTrackApp.HasActivePaydayLoans__c != '') ||
           (fastTrackApp.HasMoreThanThreeNSFs__c != undefined && fastTrackApp.HasMoreThanThreeNSFs__c != ''))
        {fastTrackApp.ManualPreApproval__c =true;}
        
        
        if(fastTrackApp.InConsumerProposal__c != '' &&  fastTrackApp.InConsumerProposal__c != undefined && fastTrackApp.InConsumerProposal__c != null
           || (fastTrackApp.ConsumerProposalDate__c != undefined && fastTrackApp.ConsumerProposalDate__c != null))
        {fastTrackApp.ManualUpdate__c = true}
        console.log(JSON.stringify(fastTrackApp));
        objList.push(fastTrackApp);
        
        var previousborrconsent = component.get('v.previousborrowerconsent');
        var borrowerconsent = component.get('v.borrowerconsent');
        var insertborconsent = false;
        
        var previouscoborrconsent = component.get('v.previouscobrwconsent');
        var coborrowerconsent =component.get('v.coborrowerconsent');
        var insertcoborconsent = false;
        
        var previouscosconsent = component.get('v.previouscosionsent');
        var cosignerconsent =component.get('v.cosignerconsent');
        var insertcosigconsent = false;
        
        if(previousborrconsent != borrowerconsent && borrowerconsent == "true"){
            insertborconsent = true;
        }else if(previouscoborrconsent != coborrowerconsent && coborrowerconsent == "true"){
            insertcoborconsent = true;
        }else if(previouscosconsent != cosignerconsent && cosignerconsent == "true"){
            insertcosigconsent = true;
        }
        
        
        var action1 = component.get("c.insertConsent");
        action1.setParams({
            "acc": account,
            "applcation": currentApplication,
            "borrowerConsent" : insertborconsent,
            "coborrowerConsent": insertcoborconsent,
            "cosignerConsent": insertcosigconsent                    
        });
        
        action1.setCallback(this, function(response){
            var state1 = response.getState();
            if (component.isValid() && state1 === "SUCCESS") {
                
                var action = component.get("c.updateFastTrack");
                action.setParams({
                    "sobjList": objList ,
                    "lia": liab,
                    "updateApplication": updateApp
                });
                
                action.setCallback(this, function(response){
                    var state = response.getState();
                    if (component.isValid() && state === "SUCCESS") {
                        component.set('v.loading',true);
                        var recId = response.getReturnValue();                
                        
                        window.setTimeout(
                            $A.getCallback(function() {
                                component.set("v.loading",false);
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    "title": "Success!",
                                    "message": 'Updated Successfully!',
                                    "type": "success",
                                });
                                toastEvent.fire();
                                //  location.reload(true);
                                component.set("v.loading",false);
                                var redirectParam='';
                                if(bsType =='borrower')
                                    redirectParam ='boraddional';
                                else if(bsType == 'coborrower')
                                    redirectParam='cobaddional';
                                    else if(bsType == 'cosigner')
                                        redirectParam='cosaddional';
                                var navLink = component.find("navLink");
                                var pageRef = {
                                    type: 'standard__recordPage',
                                    attributes: {
                                        actionName: 'view',
                                        objectApiName: 'Application__c',
                                        recordId : component.get('v.recordId'),
                                        
                                    },
                                    state: {
                                        c__redirect : redirectParam,
                                         c__isOpenedEmailBor : component.get('v.isOpenedEmailBor') ? 'true': 'false',
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                                        
                                        
                                        
                                    },
                                };
                                navLink.navigate(pageRef, true);
                            }), 3000
                        );
                        if(accType =='coborrower'){
                            component.set('v.bpaviewmode',true);
                            component.set('v.bpaappLabel','Edit');
                        }
                    }
                    else if (state === "ERROR") {
                        var errors = action.getError();
                        var finalErrorMessage;
                        if (errors) {
                            var databaseError = errors[0].message;
                            finalErrorMessage =  databaseError;
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Error!",
                                "message": finalErrorMessage,
                                "type": "error",
                            });
                            toastEvent.fire();          
                        }
                    }
                });
                $A.enqueueAction(action); 
                
                
                
            }
            else if (state1 === "ERROR") {
                var errors = action1.getError();
                var finalErrorMessage;
                if (errors) {
                    //   var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors[0],
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action1);     
    },
    
    updateRecsBor : function(component, event,helper, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        var consent1 =false;
        if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            delete borrowr["Name"];
            objList.push(borrowr);                
        }else if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            delete coborrowr["Name"];
            objList.push(coborrowr);            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            delete cosignr["Name"];
            objList.push(cosignr);        
        }
        
        var action = component.get("c.updateRecordsBor");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec'),
            "ftapp" : component.get('v.ftasa'),
            "consent": consent1
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        var redirectParam ='';
                        if(rectype =='borrower')
                            redirectParam ='borprofile';
                        else if(rectype == 'coborrower')
                            redirectParam='cobprofile';
                            else if(rectype == 'cosigner')
                                redirectParam='cosprofile';
                        
                        console.log('v.isOpenedEmailBor');
                        console.log(component.get('v.isOpenedEmailBor'));
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                            state: {
                                c__redirect : redirectParam, 
                                c__isOpenedEmailBor : component.get('v.isOpenedEmailBor') ? 'true': 'false',
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                                
                            },
                        };
                        navLink.navigate(pageRef, true);
                    }), 2000
                );
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    saveEmail : function(component, event, helper){
        var action = component.get("c.addNewEmail");
        var currentEmailObj = component.get('v.newEmailObj');
        var redirectParam='';
        if(component.get('v.newEmailIsPrimary__c') == 'true')
            currentEmailObj.IsPrimary__c =true;
        else
            currentEmailObj.IsPrimary__c =false;
        
        var currentActiveTab = component.get("v.mainTabName");
        var allEmailList = [];
        if(currentActiveTab == 'borrower'){
            allEmailList = component.get('v.emailList');
        }else if(currentActiveTab == 'coborrower'){
            allEmailList = component.get('v.coemailList');
        }else if(currentActiveTab == 'cosigner'){
            allEmailList = component.get('v.cosemailList');
        }
        
        console.log(JSON.stringify(component.get('v.newEmailIsPrimary__c')));
        if(currentEmailObj.emailAddress__c == ''){
            // component.set('v.popupErrorMessage','Email address is required');
            return;
        }else if(component.get('v.newEmailIsPrimary__c') == ''){
            // component.set('v.popupErrorMessage','Active is required');
            return;
        }
        
        var isPrimaryFound =false;
        var primessage;
        if(currentActiveTab == 'borrower'){
            var bor = component.get('v.borrowerId');
            currentEmailObj.Account__c = bor;
            redirectParam ='borprofile';
            
        }
        else if(currentActiveTab == 'coborrower'){
            var cob = component.get('v.coborrowerId');
            currentEmailObj.Account__c = cob;
            redirectParam ='cobprofile';
            
        }
            else if(currentActiveTab == 'cosigner'){
                var cos = component.get('v.cosignerId');
                currentEmailObj.Account__c = cos;
                redirectParam ='cosprofile';
            }
        
        
        /*      var emList = component.get('v.emailList');            
        if(!currentEmailObj.IsPrimary__c){
             emList.forEach(function(record){
                 
                 if(record.IsPrimary__c){
                     isPrimaryFound = true;
                 }
             });
            
             if(!isPrimaryFound){
                component.set('v.popupErrorMessage', 'One Primary email address is mandatory');
                return;
            }
        }*/
        
        
        component.set("v.loading",true);
        
        
        action.setParams({
            "emailObj" : currentEmailObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            var mess ='';
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var mess ='';
                        if(currentEmailObj.Id != undefined)
                            mess ='Email updated successfully!';
                        else
                            mess ='Email added successfully!';  
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": mess,
                            "type": "success",
                        });
                        toastEvent.fire();
                        allEmailList.push(res.data.result);
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                            state: {
                                c__redirect : redirectParam,
                                c__isOpenedEmailBor : component.get('v.isOpenedEmailBor') ? 'true': 'false',
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                                
                            }
                        };
                        navLink.navigate(pageRef, true);
                        
                    }
                    //added by Rahul
                    else if(res.status == 'failed'){
                        if(res.message.includes('A person should have only one primary email allowed'))
                            res.message = 'A person is allowed to have only one primary email';
                        else if(res.message.includes('duplicate'))
                            res.message = 'Email already exists';
                            else if(res.message.includes('A person should have atleast one primary email'))
                                res.message='At least one email must be active';
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    savePhone1 : function(component, event, helper){
        var action = component.get("c.addNewPhone");
        var currentObj = component.get('v.newPhoneObj');
        var redirectParam='';
        if(component.get('v.newPhoneIsPrimary__c') == 'true')
            currentObj.IsPrimary__c =true;
        else
            currentObj.IsPrimary__c =false;
        
        var currentActiveTab = component.get("v.mainTabName");
        var allPreviousList = [];
        if(currentActiveTab == 'borrower'){
            allPreviousList = component.get('v.phoneList');
            redirectParam = 'borprofile';
        }else if(currentActiveTab == 'coborrower'){
            allPreviousList = component.get('v.cophoneList');
            redirectParam = 'cobprofile'
        }else if(currentActiveTab == 'cosigner'){
            allPreviousList = component.get('v.cosphoneList');
            redirectParam ='cosprofile';
        }
        
        if(currentObj.PhoneType__c == ''){
            //component.set('v.popupErrorMessage','Phone type is required');
            return;
        }else if(component.get('v.newPhoneIsPrimary__c') == ''){
            //component.set('v.popupErrorMessage','Active is required');
            return;
        }
            else if(currentObj.PhoneNumber__c == ''){
                // component.set('v.popupErrorMessage','Phone number is required');
                return;
            }
        
        if(currentActiveTab == 'borrower'){
            var bor = component.get('v.borrowerId');
            currentObj.Account__c = bor;
        }
        else if(currentActiveTab == 'coborrower'){
            var cob = component.get('v.coborrowerId');
            currentObj.Account__c = cob;
        }
            else if(currentActiveTab == 'cosigner'){
                var cos = component.get('v.cosignerId');
                currentObj.Account__c = cos;
            }
        console.log(JSON.stringify(currentObj));
        component.set("v.loading",true);
        action.setParams({
            "phoneObj" : currentObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var mess ='';
                        if(currentObj.Id != undefined)
                            mess = 'Phone updated successfully!';
                        else
                            mess = 'Phone added successfully!';
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": mess,
                            "type": "success",
                        });
                        toastEvent.fire();
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                            state: {
                                c__redirect : redirectParam,
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                                
                            }
                        };
                        navLink.navigate(pageRef, true);
                        
                    }
                    //added by rahul
                    
                    else if(res.status == 'failed'){
                        if(res.message.includes('Phone number is invalid'))  
                            res.message = 'Phone number is invalid';
                        else if(res.message.includes('A person should have only one primary phone allowed'))
                            res.message = 'A person should have only one primary phone allowed';
                            else if(res.message.includes('atleast one primary phone'))
                                res.message = 'At least one phone must be active';
                                else
                                    res.message = 'Phone number is invalid';
                        component.set('v.popupErrorMessage',res.message);
                        
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    if(databaseError.includes('Phone number is invalid'))  
                        finalErrorMessage = 'Phone number is invalid';
                    else if(databaseError.includes('A person should have only one primary phone allowed'))
                        finalErrorMessage = 'A person should have only one primary phone allowed';
                    
                    component.set('v.popupErrorMessage',finalErrorMessage);
                }
            }
        });
        $A.enqueueAction(action); 
    },
    saveAddress : function(component, event, helper){
        var action = component.get("c.addNewAddress");
        var currentObj = component.get('v.newAddressObj');
        var currentActiveTab = component.get("v.mainTabName");
        var allPreviousList = [];
        var redirectParam ='';
        if(currentActiveTab == 'borrower'){
            allPreviousList = component.get('v.addressList');
        }else if(currentActiveTab == 'coborrower'){
            allPreviousList = component.get('v.coaddressList');
        }else if(currentActiveTab == 'cosigner'){
            allPreviousList = component.get('v.cosaddressList');
        }
        
        
        if(currentObj.StreetAddress__c == '' || currentObj.StreetAddress__c == null){
            // component.set('v.popupErrorMessage','Street is required');
            return;
        }
        else if(currentObj.City__c == '' || currentObj.City__c == null){
            // component.set('v.popupErrorMessage','City is required');
            return;
        }else if(currentObj.Province__c == '' || currentObj.Province__c == null){
            //component.set('v.popupErrorMessage','Province is required');
            return;
        }
            else if(currentObj.PostalCode__c == '' || currentObj.PostalCode__c == null){
                //component.set('v.popupErrorMessage','Postal Code is required');
                return;
            }
                else if(currentObj.AddressSinceDate__c == null){
                    //component.set('v.popupErrorMessage','Moved In Date is required');
                    return;
                }
        
        currentObj.Country__c = 'Canada';
        
        if(currentActiveTab == 'borrower'){
            var bor = component.get('v.borrowerId');
            currentObj.Account__c = bor;
            redirectParam = 'borprofile';
        }
        else if(currentActiveTab == 'coborrower'){
            var cob = component.get('v.coborrowerId');
            currentObj.Account__c = cob;
            redirectParam = 'cobprofile';
        }
            else if(currentActiveTab == 'cosigner'){
                var cos = component.get('v.cosignerId');
                currentObj.Account__c = cos;
                redirectParam = 'cosprofile';
            }
        
        component.set("v.loading",true);
        
        action.setParams({
            "addressObj" : currentObj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(res.data != null && res.data.result != null){
                        var mess ='';
                        if(currentObj.Id != undefined)
                            mess='Address updated successfully';
                        else
                            mess='Address added successfully';
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": mess,
                            "type": "success",
                        });
                        toastEvent.fire();
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                            state: {
                                c__redirect : redirectParam,
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                                
                            }
                        };
                        navLink.navigate(pageRef, true);
                        
                        
                    }else if(res.status == 'failed'){
                        if(res.message.includes('A9A 9A9'))
                            res.message ='Postal code must be In A9A9A9 format';
                        component.set('v.popupErrorMessage',res.message);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
                component.set("v.loading",false);
            }
        });
        $A.enqueueAction(action); 
    },
    fetchPicklistValues : function(component, event, helper,objName1,fieldName1){
        var action = component.get("c.getPicklistValues");
        action.setParams({
            "objName" : objName1,
            "fieldName" : fieldName1
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var res = response.getReturnValue();    
                if(res != null){
                    if(fieldName1 == 'Province__c'){
                        component.set('v.addressProvinceOptions',res);
                    }
                }else if(res.status == 'failed'){
                    component.set('v.popupErrorMessage',res.message);
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    resetPopUpErrorMessage : function(component, event, helper){
        component.set("v.isOpenEmail", false);
        component.set("v.isOpenPhone", false);
        component.set("v.isOpenAddress", false);
        component.set('v.popupErrorMessage','');
        
        var email ={};
        email.EmailAddress__c ='';
        component.set('v.newEmailObj',email);
        component.set('v.newEmailIsPrimary__c','');
        
        
        var phone ={};
        phone.PhoneType__c = '';
        phone.PhoneNumber__c =null;
        component.set('v.newPhoneIsPrimary__c','');
        component.set('v.newPhoneObj',phone);
        
        
        var address ={};
        address.StreetAddress__c='';
        address.Unit__c ='';
        address.City__c ='';
        address.Province__c ='';
        address.PostalCode__c='';
        address.Country__c ='';
        address.AddressSinceDate__c = null;
        address.AddressEndDate__c = null;
        
        component.set('v.newAddressObj',address);
        
        
        var emp ={};
        emp.Name='';
        emp.Position__c ='';
        emp.EmploymentStartDate__c = null;
        emp.EmploymentEndDate__c = null;
        emp.IsFirstJob__c =''
        component.set('v.cobEmp',emp);
        component.set('v.cosEmp',emp);
        component.set('v.borEmp',emp);
        
        var lia = {};
        lia.LiabilityType__c ='';
        lia.CreditorManual__c ='';
        lia.PaymentAmountManual__c = null;
        lia.RemainingBalanceManual__c = null;
        component.set('v.borrowerLiabilityNew',lia);
        component.set('v.coborrowerLiabilityNew',lia);
        component.set('v.cosignerLiabilityNew',lia);
        
        
        
        
        
    },
    fetchEmailTemplatesList : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                var templateListVal = [];
                if(res != null && res.data != null && res.data.result != null){
                    // console.log('Hey'+component.get("v.isAddCoBorrower"));
                    if(component.get("v.isAddCoBorrower")){
                        for(var i=0;i<res.data.result.length;i++){
                            if(res.data.result[i].Name == "Co-Borrower Request"){
                                templateListVal.push(res.data.result[i]);
                                break;
                            }
                        }
                    }
                    else{
                        for(var i=0;i<res.data.result.length;i++){
                            if(res.data.result[i].Name == "Co-signer Request"){
                                templateListVal.push(res.data.result[i]);
                                break;
                            }
                        }
                    }
                    if(templateListVal.length == 1){
                        component.set('v.emailTemplateList',templateListVal);  
                        component.set('v.emailTemplateSelectedVal',templateListVal[0].Id);
                        helper.fetchTemplateBody(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    fetchTemplateBody : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        
        if(component.get("v.emailTemplateSelectedVal") == ''){
            component.set('v.templatePreviewBody','');
            component.set('v.loading',false);
            return;
        }
        action.setParams({
            "templateId" : component.get("v.emailTemplateSelectedVal")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                if(res != null && res.data != null && res.data.result != null){
                    console.log(res.data.result[0].HtmlValue);
                    var filertedtext = res.data.result[0].HtmlValue.split('</head>');
                    console.log(filertedtext[1]);
                    component.set('v.templatePreviewBody',filertedtext[1]);
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    resetButtonVisiblility: function(component, event, helper) {
        component.set('v.cobviewmode',true);
        component.set('v.borviewmode',true);
        component.set('v.cosviewmode',true);
        component.set('v.bpaviewmode',true);
        component.set('v.cobpaviewmode',true);
        component.set('v.cosignerbpaviewmode',true);
        component.set('v.showSaveButtonBor',false);
        component.set('v.showSaveButtonbpa',false);
        component.set('v.showEditBtnBor',true);
        component.set('v.showEditBtnbpa',true);
    },
    
    AddCoBorrowerCoSigner: function(component, event, helper, type) {
        
        //21-March -Maanas//
        var accLookup;
        var newAcc;
        if(component.get('v.selectedLookUpRecord').Id == undefined){
            accLookup = null;
        }
        else{
            accLookup = component.get('v.selectedLookUpRecord');
        }
        
        if(type == 'coborrower'){
            newAcc = component.get('v.accountRec');
        }else if(type == 'cosigner'){
            newAcc = component.get('v.accountRecCos');
        }
        
        if(accLookup != null)
            newAcc = null;
        
        var action = component.get("c.createUpdateAccount");
        action.setParams({
            "existingAccount": accLookup,
            "newRec": newAcc,
            "applicantType" : type,
            "applicationId" : component.get('v.recordId')
            
        });            
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var recId = response.getReturnValue();
                if(recId == 'fail'){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": 'Add Failed: User Already Present as Borrower/Co-Borrower/Co-Signer on the Application!',
                        "type": "error",
                    });
                    toastEvent.fire();
                }else{
                    var message1='';
                    var redirectParam='';
                    if(component.get('v.isAddCoBorrower')){
                        message1 = 'Co-borrower has been added!';
                        redirectParam = 'cobprofile';
                    }
                    else if(component.get('v.isAddCoSigner')){
                        message1 = 'Co-signer has been added!';
                        redirectParam = 'cosprofile';    
                    }
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": message1,
                        "type": "success",
                    });
                    toastEvent.fire();
                    var navLink = component.find("navLink");
                    var pageRef = {
                        type: 'standard__recordPage',
                        attributes: {
                            actionName: 'view',
                            objectApiName: 'Application__c',
                            recordId : component.get('v.recordId')
                        },
                        state: {
                            c__redirect : redirectParam
                            
                        }
                    };
                    
                    navLink.navigate(pageRef, true);
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    if(databaseError.includes("A9A"))
                        finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                    else
                        finalErrorMessage =  databaseError;
                    
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action);   
        
    },
    clearEmailPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.EmailAddress__c = '';                                               
        newObj.IsPrimary__c = '';
        component.set("v.newEmailObj",newObj);
    },
    clearPhonePopUpsValues: function(component, event, helper) { 
        var newObj = {};
        newObj.PhoneNumber__c = '';                                               
        newObj.PhoneType__c = '';
        newObj.IsPrimary__c = '';
        component.set("v.newPhoneObj",newObj);
    },
    clearAddressPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.StreetAddress__c = '';                                               
        newObj.City__c = '';
        newObj.Province__c = '';
        newObj.Country__c = '';
        newObj.PostalCode__c = '';
        newObj.IsPrimary__c = '';
        component.set("v.newAddressObj",newObj);
    },
    clearNewBorrowerPopUpsValues: function(component, event, helper) {
        var newObj = {};
        newObj.FirstName = '';                                               
        newObj.LastName = '';
        newObj.PersonEmail = '';
        newObj.Username__c = '';
        component.set("v.accountRec",newObj);
        component.set("v.selectedLookUpRecord",'');
    },
    
    removeApplicant : function(component, event, helper, ApplicantType){
        
        var objList = [];
        if(ApplicantType == 'COBORROWER'){
            var coborrowr = component.get('v.coborrower');
            objList.push(coborrowr);            
        }else if(ApplicantType =='COSIGNER'){
            var cosignr = component.get('v.activecosigner');
            objList.push(cosignr);
        }
        
        var action = component.get("c.deactivateApplicant");
        action.setParams({
            "toDeactivateList": objList,
            "ApplicationId": component.get('v.recordId')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                var finalMessage;
                
                if(ApplicantType=='COBORROWER'){
                    finalMessage = 'Co-borrower has been removed!';
                }
                else if(ApplicantType=='COSIGNER')
                    finalMessage = 'Co-signer has been removed!';
                
                toastEvent.setParams({
                    "title": "Success!",
                    "message": finalMessage,
                    "type": "success",
                });
                toastEvent.fire();
                var navLink = component.find("navLink");
                var pageRef = {
                    type: 'standard__recordPage',
                    attributes: { 
                        actionName: 'view',
                        objectApiName: 'Application__c',
                        recordId : component.get('v.recordId')
                    },
                };
                navLink.navigate(pageRef, true);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": databaseError,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    fetchEmailTemplatesRequestCobCos : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();   
                var emailListrecords = [] ;
                if(res != null && res.data != null && res.data.result != null){
                    
                    var records = res.data.result;
                    
                    records.forEach(function(record){ 
                        if(record.Name == 'Request borrower for a co-borrower' || record.Name == 'Request borrower for a co-signer'){
                            emailListrecords.push(record);
                        }
                    });
                    component.set('v.emailTemplateList',emailListrecords);
                }
                
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    sendReqforCObCos : function (component,event, selectedTemplate){
        
        var borrower = component.get('v.borrower');
        var action = component.get("c.sendReqforCosCob");
        action.setParams({
            "template" : selectedTemplate,
            "borrowerData" : borrower
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Request sent to Borrower!',
                    "type": "success",
                });
                toastEvent.fire(); 
                component.set('v.isrequestCobCos',false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action);
        
    },
    sendCoborrEmailInvite : function (component,event,selectedTemplate){
        var coborrower = component.get('v.coborrower');
        var action = component.get("c.sendEmailInviteToCoborrower");
        action.setParams({
            "template" : selectedTemplate,
            "coborrowerData" : coborrower,
            "applicationId": component.get('v.recordId')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Request sent to Co-Borrower!',
                    "type": "success",
                });
                toastEvent.fire(); 
                component.set('v.openCoborrowerEmailInviteBox',false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    sendCosignerEmailInvite : function (component,event,selectedTemplate){
        var cosigner = component.get('v.activecosigner');
        var action = component.get("c.sendEmailInviteToCosigner");
        action.setParams({
            "template" : selectedTemplate,
            "cosignerData" : cosigner,
            "applicationId": component.get('v.recordId')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Request sent to Co-Signer!',
                    "type": "success",
                });
                toastEvent.fire(); 
                component.set('v.openCosignerEmailInviteBox',false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();
                    component.set('v.openCosignerEmailInviteBox',false);
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
   fetchEmailTemplatesListCoBorr : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                
                var res = response.getReturnValue();    
                var templateListVal = [];
                if(res != null && res.data != null && res.data.result != null){
                    for(var i=0;i<res.data.result.length;i++){
                        if(res.data.result[i].Name == "Co-Borrower Request"){
                            templateListVal.push(res.data.result[i]);
                            break;
                        }
                    }
                    if(templateListVal.length == 1){
                    	component.set('v.emailTemplateList',templateListVal);  
                        component.set('v.emailTemplateSelectedVal',templateListVal[0].Id);
                        helper.fetchTemplateBody(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    fetchEmailTemplatesListCoSignr : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                
                var res = response.getReturnValue();    
                var templateListVal = [];
                if(res != null && res.data != null && res.data.result != null){
                    for(var i=0;i<res.data.result.length;i++){
                        if(res.data.result[i].Name == "Co-signer Request"){
                            templateListVal.push(res.data.result[i]);
                            break;
                        }
                    }
                    if(templateListVal.length == 1){
                    	component.set('v.emailTemplateList',templateListVal);  
                        component.set('v.emailTemplateSelectedVal',templateListVal[0].Id);
                        helper.fetchTemplateBody(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    }
})
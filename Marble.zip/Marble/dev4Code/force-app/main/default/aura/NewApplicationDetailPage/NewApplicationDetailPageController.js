({
    openModelEmail: function(component, event, helper) {
        console.log('EmailBox');
        component.set("v.isOpenEmail", true);
    },
    
    closeModelEmail: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        //component.set("v.isOpenEmail", false);
        component.set('v.showPrimaryemail',true);
        component.set('v.emailLabel','Add');
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    
    SaveEmail: function(component, event, helper) {
        component.set('v.popupErrorMessage','');
        var allValid = component.find('emailpop').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
        
        var emailObj = component.get('v.newEmailObj');
        var emailList = component.get('v.emailList');
        var isNew =false;
        
        if(emailObj.Id == undefined){
            isNew = true;
        }
        
        var isCurrentPrimary = component.get('v.newEmailIsPrimary__c');
        var primaryPresent = false;
        
        if(isNew && isCurrentPrimary == 'false'){
            emailList.forEach(function(record){  
                if(record.IsPrimary__c)
                    primaryPresent = true;
            });
            
            
            if(!primaryPresent){
                component.set('v.popupErrorMessage','At least one email must be active' );
                return;
            }
        }/*else{
            if(isCurrentPrimary =='false'){
            for(var i = 0; i < emailList.length; i++) {
                if(emailList[i].Id == emailObj.Id) {
                    emailList.splice(i, 1);
                    
                }
            }
            
            emailList.forEach(function(record){  
                if(record.IsPrimary__c)
                    primaryPresent = true;
            });
            
            if(!primaryPresent && (isCurrentPrimary == 'false')){
                component.set('v.popupErrorMessage','At least one email must be active' );
                return;
            	}
            }
        }*/
        
        
        helper.saveEmail(component, event, helper);
        
    },
    onTabChangeProfile: function(component, event, helper) {
        component.set("v.currentTab", 'Profile');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeCoBorrower: function(component, event, helper) {
        component.set("v.mainTabName", 'coborrower');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeCoSigner: function(component, event, helper) {
        component.set("v.mainTabName", 'cosigner');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeBorrower: function(component, event, helper) {
        component.set("v.mainTabName", 'borrower');
        helper.resetButtonVisiblility(component, event, helper); 
    }, 
    onTabChangeAdditional: function(component, event, helper) {
        component.set("v.currentTab", 'Additional');
        helper.resetButtonVisiblility(component, event, helper); 
    },
    editboraddtional: function(component, event, helper) {
        alert("Your in Add");
    },
    openModelPhone: function(component, event, helper) {
        console.log('PhoneBox');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpenPhone", true);
        component.set('v.phoneLabel','Add');
    },
    
    closeModelPhone: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpenPhone", false);
        helper.resetPopUpErrorMessage(component, event, helper);
        
    },
    
    SavePhone: function(component, event, helper) { 
        var allValid = component.find('phonebor').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
        
        var phone = component.get('v.newPhoneObj');
        
        /* if(phone.PhoneNumber__c == '' && phone.PhoneType__c =='' && phone.IsPrimary__c == ''){
            
            //component.set('v.popupErrorMessage','Please fill Phone Number/ Type/ Active required fields');
        }*/
        //else{
        component.set('v.popupErrorMessage','');
        helper.savePhone1(component, event, helper);
        // }
        //component.set("v.isOpenPhone", false);
    },
    openModelAddress: function(component, event, helper) {
        component.set("v.loading",true);
        component.set('v.addressLabel','Add');
        // for Display Model,set the "isOpen" attribute to "true"
        helper.fetchPicklistValues(component, event, helper,'Address__c','Province__c');
        //helper.fetchPicklistValues(component, event, helper,'Address__c','AddressEndMonth__c');
        //helper.fetchPicklistValues(component, event, helper,'Address__c','AddressEndYear__c');
        component.set("v.isOpenAddress", true);
        component.set('v.newAddressObj.Country__c','Canada');
    },
    saveBorrowerBpa: function(component, event, helper) {
        console.log('saveBorrowerBpa');
        
        var borrower = component.get('v.borrower');
        if(component.get('v.ftasa.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
        {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                "type": "error",
            });
            toastEvent.fire();   
        }else if((component.get('v.ftasa.InConsumerProposal__c') =='NO' || component.get('v.ftasa.InConsumerProposal__c') =='') && component.get('v.ftasa.ConsumerProposalDate__c') != undefined){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                "type": "error",
            });
            toastEvent.fire();
        }
            else{
                
                
                if( component.get('v.borrowerconsent') == 'true'){
                    var addressList = component.get('v.addressList');
                    if(addressList == null ||  addressList.length == 0){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please enter atleast one address before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                    if(borrower.FirstName == '' && borrower.LastName == '' && ( borrower.PersonBirthdate == null ||  borrower.PersonBirthdate == '' || borrower.PersonBirthdate == undefined ) && borrower.SIN__pc ==''){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please atleast either (Firstname/LastName/DOB) Or SIN before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                }
                helper.updateBorrowerPreApproval(component, event, helper,'borrower');   
            }
        
    },
    saveCoBorrowerBpa: function(component, event, helper) {
        
        var coborrower = component.get('v.coborrower');
        if(component.get('v.ftasaCoborrower.InConsumerProposal__c') =='YES' && component.get('v.ftasaCoborrower.ConsumerProposalDate__c') == undefined)
        {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                "type": "error",
            });
            toastEvent.fire();   
        }else if((component.get('v.ftasaCoborrower.InConsumerProposal__c') =='NO' || component.get('v.ftasaCoborrower.InConsumerProposal__c') =='') && component.get('v.ftasaCoborrower.ConsumerProposalDate__c') != undefined){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                "type": "error",
            });
            toastEvent.fire();
        }
            else{
                if( component.get('v.coborrowerconsent') == 'true'){
                    var addressList = component.get('v.coaddressList');
                    if(addressList == null ||  addressList.length == 0){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please enter atleast one address before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                    if(coborrower.FirstName == '' && coborrower.LastName == '' && ( coborrower.PersonBirthdate == null ||  coborrower.PersonBirthdate == '' || coborrower.PersonBirthdate == undefined ) && coborrower.SIN__pc ==''){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please atleast either (Firstname/LastName/DOB) Or SIN before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                }
                helper.updateBorrowerPreApproval(component, event, helper,'coborrower');   
            }
        
    },
    saveCoSignerBpa: function(component, event, helper) {
        var cosigner = component.get('v.activecosigner')
        if(component.get('v.ftasaCosigner.InConsumerProposal__c') =='YES' && component.get('v.ftasaCosigner.ConsumerProposalDate__c') == undefined)
        {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                "type": "error",
            });
            toastEvent.fire();   
        }else if((component.get('v.ftasaCosigner.InConsumerProposal__c') =='NO' || component.get('v.ftasaCosigner.InConsumerProposal__c') =='') && component.get('v.ftasaCosigner.ConsumerProposalDate__c') != undefined){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                "type": "error",
            });
            toastEvent.fire();
        }
            else{
                if( component.get('v.cosignerconsent') == 'true'){
                    var addressList = component.get('v.cosaddressList');
                    if(addressList == null ||  addressList.length == 0){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please enter atleast one address before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                    if(cosigner.FirstName == '' && cosigner.LastName == '' && ( cosigner.PersonBirthdate == null ||  cosigner.PersonBirthdate == '' || cosigner.PersonBirthdate == undefined ) && cosigner.SIN__pc ==''){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Please atleast either (Firstname/LastName/DOB/SIN) Or SIN before making a credit consent.',
                            "type": "error",
                        });
                        toastEvent.fire();
                        return;
                    }
                }
                helper.updateBorrowerPreApproval(component, event, helper,'cosigner');   
            }
        
    },
    
    
    
    saveBorrowerBor: function(component, event, helper) {
        
        
        
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            
            var allValid = component.find('reqAppbor').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            
            if(!allValid)
                return;
            helper.updateRecsBor(component, event, helper, 'borrower'); 
        }else if(currentActiveTab == 'coborrower'){
            
            var allValid = component.find('reqAppcob').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            
            if(!allValid)
                return;
            
            helper.updateRecsBor(component, event, helper, 'coborrower'); 
        }else if(currentActiveTab == 'cosigner'){
            
            var allValid = component.find('reqAppcos').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            
            if(!allValid)
                return;
            helper.updateRecsBor(component, event, helper, 'cosigner');
        }
    },
    closeModelAddress: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpenAddress", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    SaveAddress: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        //alert('');
        var allValid = component.find('fieldIdAddress').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
        helper.saveAddress(component, event, helper);
    },
    openModelAddCoborrower: function(component, event, helper) {
        console.log('AddCoborrower');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set('v.loading',true);
        helper.fetchEmailTemplatesList(component, event, helper);
        component.set("v.isAddCoBorrower", true);
        component.set('v.templatePreviewBody','');
    },
    
    closeModelAddCoBorrower: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddCoBorrower", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    SaveCoborrower: function(component, event, helper){
        var allValid = component.find('fieldIdAddCobor').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
        
        var selectedAcc = component.get("v.selectedLookUpRecord");
        var accountRecData = component.get("v.accountRec");
        
        
        
        if(component.get('v.emailTemplateSelectedVal') == ''){
            component.set("v.popupErrorMessage", 'Select Email Template');
            return;
        }
        
        component.set("v.popupErrorMessage", '');
        
        
        
        helper.AddCoBorrowerCoSigner(component,event,helper,'coborrower');      
        
    },
    openModelAddCoSigner: function(component, event, helper) {
        console.log('AddCoborrower');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set('v.loading',true);
        helper.fetchEmailTemplatesList(component, event, helper);
        component.set("v.isAddCoSigner", true);
        component.set('v.templatePreviewBody','');
    },
    
    closeModelAddCoSigner: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddCoSigner", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    SaveCoSigner: function(component, event, helper) {
        var allValid = component.find('fieldIdAddCosig').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
        
        var selectedAcc = component.get("v.selectedLookUpRecord");
        var accountRecData = component.get("v.accountRecCos");
        
        
        /*  if(selectedAcc.Id == undefined  && accountRecData.FirstName == '' && accountRecData.LastName =='' && accountRecData.PersonEmail ==''){
           // component.set("v.popupErrorMessage", 'Select Atleast one Exisiting Account/Add New Account');
            return;
        }*/
        
        if(component.get('v.emailTemplateSelectedVal') == ''){
            component.set("v.popupErrorMessage", 'Select Email Template');
            return;
        }
        
        /*  if(selectedAcc.Id == undefined){
            if(!accountRecData.FirstName  || !accountRecData.LastName  || !accountRecData.PersonEmail){
              //  component.set("v.popupErrorMessage", 'FirstName/LastName/Email  are required');
                return;
            }
        }*/
        
        
        
        component.set("v.popupErrorMessage", '');     
        helper.AddCoBorrowerCoSigner(component,event,helper,'cosigner');
    },
    
    openModelRemoveCoBorrower: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isRemoveCoBorrower", true);
    },
    
    closeModelRemoveCoBorrower: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isRemoveCoBorrower", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    RemoveApplicant: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'coborrower')
            helper.removeApplicant(component,event,helper,'COBORROWER');
        if(currentActiveTab == 'cosigner'){
            helper.removeApplicant(component,event,helper,'COSIGNER');
        }
        
    },
    openModelRemoveCoSigner: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isRemoveCoSigner", true);
    },
    
    closeModelRemoveCoSigner: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isRemoveCoSigner", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    RemoveCoSigner: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer 
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('');
        component.set("v.isRemoveCoSigner", false);
    },
    
    openModelAddEmp: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isAddEmp", true);
        component.set('v.employmentLabel','Add');
    },
    
    closeModelAddEmp: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddEmp", false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    SaveAddEmp: function(component, event, helper) {
        
        
        
        
        var accId;
        var emp;
        var startdate;
        var enddate;
        var currentActiveTab = component.get("v.mainTabName");
        var redirectParam='';
        if(currentActiveTab == 'borrower'){
            accId =  component.get('v.borrower.Id');
            emp = component.get('v.borEmp');
            var allValid = component.find('fieldIdEmpbor').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            if(!allValid)
                return; 
            redirectParam = 'boraddional';
            
        }
        else if(currentActiveTab == 'coborrower'){
            accId =  component.get('v.coborrower.Id');   
            
            var allValid = component.find('fieldIdEmpcob').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            if(!allValid)
                return; 
            
            emp = component.get('v.cobEmp');
            redirectParam = 'cobaddional';
            
        }
            else if(currentActiveTab == 'cosigner'){
                accId =  component.get('v.activecosigner.Id');
                
                var allValid = component.find('fieldIdEmpcos').reduce(function (validSoFar, inputCmp) {
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && !inputCmp.get('v.validity').valueMissing;
                }, true);
                if(!allValid)
                    return; 
                
                emp = component.get('v.cosEmp');
                redirectParam = 'cosaddional';
            }
        
        
        /* if(emp.Name == ''){
            //  component.set('v.popupErrorMessage','Company is required');
            return;
        }
        else if(emp.Position__c == '' || emp.Position__c == undefined){
            //component.set('v.popupErrorMessage','Job Title is required');
            return;
        }
            else if(emp.EmploymentStartDate__c == null ){
                //   component.set('v.popupErrorMessage','Start Date is required');       
                return;
            }
        
                else if(emp.IsFirstJob__c == '' ){
                    //    component.set('v.popupErrorMessage','First Job is required');
                    return;
                }
        */
        emp.Account__c = accId;
        var sobj =[];
        sobj.push(emp);
        var action = component.get("c.insertEmp");
        action.setParams({
            "recsToinsert" : sobj
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var mess ='';
                if(emp.Id != undefined)
                    mess = 'Employment updated successfully!';
                else
                    mess = 'Employment added successfully!';
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": mess,
                    "type": "success",
                });
                toastEvent.fire();
                var navLink = component.find("navLink");
                var pageRef = {
                    type: 'standard__recordPage',
                    attributes: {
                        actionName: 'view',
                        objectApiName: 'Application__c',
                        recordId : component.get('v.recordId')
                    },
                    state: {
                        c__redirect : redirectParam,
                          c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                        
                    }
                };
                navLink.navigate(pageRef, true);               
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    openModelAddLoanDebt: function(component, event, helper) {
        console.log('RemoveCo');
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isAddLoanDebt", true);
    },
    
    closeModelAddLoanDebt: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isAddLoanDebt", false);
        component.set('v.loanDebtLabel','Add');
        helper.resetPopUpErrorMessage(component, event, helper);
        
    },
    
    SaveAddLoanDebt: function(component, event, helper) {
        
        var loanDebtLabel= component.get('v.loanDebtLabel');
        //console.log('loanDebtLabel'+loanDebtLabel);
        var accId;
        var liability;
        var startdate;
        var enddate;
        var applicantType;
        var currentActiveTab = component.get("v.mainTabName");
        
        var redirectParam='';
        
        if(currentActiveTab == 'borrower'){
            accId =  component.get('v.borrower.Id');
            liability = component.get('v.borrowerLiabilityNew');
            applicantType = "BORROWER";
            redirectParam ='boraddional';
            var allValid = component.find('fieldIdLoanDebtBor').reduce(function (validSoFar, inputCmp) {
            inputCmp.showHelpMessageIfInvalid();
            return validSoFar && !inputCmp.get('v.validity').valueMissing;
        }, true);
        if(!allValid)
            return;
            
            
        }
        else if(currentActiveTab == 'coborrower'){
            accId =  component.get('v.coborrower.Id');
            liability =  component.get('v.coborrowerLiabilityNew');
            applicantType = "COBORROWER";
            var allValid = component.find('fieldIdLoanDebtCobo').reduce(function (validSoFar, inputCmp) {
                inputCmp.showHelpMessageIfInvalid();
                return validSoFar && !inputCmp.get('v.validity').valueMissing;
            }, true);
            if(!allValid)
                return;
            redirectParam='cobaddional';
        }
            else if(currentActiveTab == 'cosigner'){
                accId =  component.get('v.activecosigner.Id');
                liability = component.get('v.cosignerLiabilityNew');
                applicantType = "COSIGNER";
                var allValid = component.find('fieldIdLoanDebtCos').reduce(function (validSoFar, inputCmp) {
                    inputCmp.showHelpMessageIfInvalid();
                    return validSoFar && !inputCmp.get('v.validity').valueMissing;
                }, true);
                if(!allValid)
                    return;
                redirectParam='cosaddional';
            } 
        /*   
        if(liability.LiabilityType__c == ''){
            //  component.set('v.popupErrorMessage','Loan/Debt Type is required');
            return;
        }
        
        else if(liability.CreditorManual__c == ''){
            //  component.set('v.popupErrorMessage','Grantor is required');
            return;
        } 
        
            else if(liability.PaymentAmountManual__c == '' || liability.PaymentAmountManual__c == null){
                //     component.set('v.popupErrorMessage','Monthly Payment is required');
                return;
            } 
        
                else if(liability.RemainingBalanceManual__c == '' || liability.RemainingBalanceManual__c == null ){
                    //     component.set('v.popupErrorMessage','Outstanding Balance is required');
                    return;
                } 
        
        */
        liability.PaymentFrequencyManual__c ='MONTHLY';
        var sobj =[];
        
        
        sobj.push(liability);
        var action = component.get("c.insertLiability");
        action.setParams({
            "recsToinsert" : sobj,
            "accountId" : accId,
            "appType" : applicantType,
            "appRecId" : component.get('v.recordId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                if(loanDebtLabel == 'Add'){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": 'Loan/Debt added successfully!',
                        "type": "success",
                    });
                    toastEvent.fire();
                }
                else{
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": 'Loan/Debt updated successfully!',
                        "type": "success",
                    });
                    toastEvent.fire();
                }
                var navLink = component.find("navLink");
                var pageRef = {
                    type: 'standard__recordPage',
                    attributes: {
                        actionName: 'view',
                        objectApiName: 'Application__c',
                        recordId : component.get('v.recordId')
                    },
                    state: {
                        c__redirect : redirectParam,
                          c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                        
                    }
                };
                navLink.navigate(pageRef, true);               
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    
    
    
    
 doInit    : function(component, event, helper) {
        
        // component.set("v.tabId", 'cosignerTabId');
        var pageReference = component.get("v.pageReference");
        
        var url = location.search.substr(1);
        var url2 = window.location.search;
        
        
        var params = {};
        var query = window.location.search;
        var vars = query.split('&'); 
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split('=');
            params[pair[0]] = decodeURIComponent(pair[1]);
        }
        
     if(params != null){
        //hide show email section Borrower
        if(params['c__isOpenedEmailBor'] != undefined && params['c__isOpenedEmailBor'] =='false')
            component.set('v.isOpenedEmailBor',false);
        else
            component.set('v.isOpenedEmailBor',true);
        
        //hide show phone section borrower
        if(params['c__isOpenedPhoneBor'] != undefined  && params['c__isOpenedPhoneBor'] =='false')
            component.set('v.isOpenedPhoneBor',false);
        else
            component.set('v.isOpenedPhoneBor',true);
        
        //hide show address section borrower
          if(params['c__isOpenedAddressBor'] != undefined  && params['c__isOpenedAddressBor'] =='false')
            component.set('v.isOpenedAddressBor',false);
        else
            component.set('v.isOpenedAddressBor',true);
        
        //hide show person section borrower
         if(params['c__isOpenedPersonalBor'] != undefined  && params['c__isOpenedPersonalBor'] =='false')
            component.set('v.isOpenedPersonalBor',false);
        else
            component.set('v.isOpenedPersonalBor',true);

        
        //hide show Employment section borrower
         if(params['c__isOpenedEmpBor'] != undefined  && params['c__isOpenedEmpBor'] =='false')
            component.set('v.isOpenedEmpBor',false);
        else
            component.set('v.isOpenedEmpBor',true);
        
        
        
        
		//hide show Income section borrower
         if(params['c__isOpenedIncomeBor'] != undefined  && params['c__isOpenedIncomeBor'] =='false')
            component.set('v.isOpenedIncomeBor',false);
        else
            component.set('v.isOpenedIncomeBor',true);
        
        
        	//hide show housing section borrower
         if(params['c__isOpenedHousingBor'] != undefined  && params['c__isOpenedHousingBor'] =='false')
            component.set('v.isOpenedHousingBor',false);
        else
            component.set('v.isOpenedHousingBor',true);
        
        
        
        
         //hide show payday section borrower
         if(params['c__isOpenedPayDayBor'] != undefined  && params['c__isOpenedPayDayBor'] =='false')
            component.set('v.isOpenedPayDayBor',false);
        else
            component.set('v.isOpenedPayDayBor',true);
        
        
        //hide show nsf section borrower
       if(params['c__isOpenedNSFBor'] != undefined  && params['c__isOpenedNSFBor'] =='false')
            component.set('v.isOpenedNSFBor',false);
        else
            component.set('v.isOpenedNSFBor',true);
        
        
        
            //hide show nsf section borrower
       if(params['c__isOpenedLoanBor'] != undefined  && params['c__isOpenedLoanBor'] =='false')
            component.set('v.isOpenedLoanBor',false);
        else
            component.set('v.isOpenedLoanBor',true);
        
        
           /*-------Coborrwer ---------*/
          //hide show email coborrower section
        if(params['c__isOpenedEmailCob'] != undefined && params['c__isOpenedEmailCob'] =='false')
            component.set('v.isOpenedEmailCob',false);
        else
            component.set('v.isOpenedEmailCob',true);
        
        
               //hide show phone section coborrower
        if(params['c__isOpenedPhoneCob'] != undefined  && params['c__isOpenedPhoneCob'] =='false')
            component.set('v.isOpenedPhoneCob',false);
        else
            component.set('v.isOpenedPhoneCob',true);
        
     //hide show address section Cobrower
          if(params['c__isOpenedAddressCob'] != undefined  && params['c__isOpenedAddressCob'] =='false')
            component.set('v.isOpenedAddressCob',false);
        else
            component.set('v.isOpenedAddressCob',true);
        
        //hide show person section Cobrower
         if(params['c__isOpenedPersonalCob'] != undefined  && params['c__isOpenedPersonalCob'] =='false')
            component.set('v.isOpenedPersonalCob',false);
        else
            component.set('v.isOpenedPersonalCob',true);

        
        //hide show Employment section Cobrower
         if(params['c__isOpenedEmpCob'] != undefined  && params['c__isOpenedEmpCob'] =='false')
            component.set('v.isOpenedEmpCob',false);
        else
            component.set('v.isOpenedEmpCob',true);
        
		//hide show Income section Cobrower
         if(params['c__isOpenedIncomeCob'] != undefined  && params['c__isOpenedIncomeCob'] =='false')
            component.set('v.isOpenedIncomeCob',false);
        else
            component.set('v.isOpenedIncomeCob',true);
        
        
        	//hide show housing section Cobrower
         if(params['c__isOpenedHousingCob'] != undefined  && params['c__isOpenedHousingCob'] =='false')
            component.set('v.isOpenedHousingCob',false);
        else
            component.set('v.isOpenedHousingCob',true);
        
        
         //hide show payday section Cobrower
         if(params['c__isOpenedPayDayCob'] != undefined  && params['c__isOpenedPayDayCob'] =='false')
            component.set('v.isOpenedPayDayCob',false);
        else
            component.set('v.isOpenedPayDayCob',true);
        
        
        //hide show nsf section Cobrower
       if(params['c__isOpenedNSFCob'] != undefined  && params['c__isOpenedNSFCob'] =='false')
            component.set('v.isOpenedNSFCob',false);
        else
            component.set('v.isOpenedNSFCob',true);
        

            //hide show nsf section Cobrower
       if(params['c__isOpenedLoanCob'] != undefined  && params['c__isOpenedLoanCob'] =='false')
            component.set('v.isOpenedLoanCob',false);
        else
            component.set('v.isOpenedLoanCob',true);
        
        
          /*-------Cosorrwer --*/
          //hide show email Cosorrower section
        if(params['c__isOpenedEmailCos'] != undefined && params['c__isOpenedEmailCos'] =='false')
            component.set('v.isOpenedEmailCos',false);
        else
            component.set('v.isOpenedEmailCos',true);
        
        
               //hide show phone section Cosorrower
        if(params['c__isOpenedPhoneCos'] != undefined  && params['c__isOpenedPhoneCos'] =='false')
            component.set('v.isOpenedPhoneCos',false);
        else
            component.set('v.isOpenedPhoneCos',true);
        
     //hide show address section Cosrower
          if(params['c__isOpenedAddressCos'] != undefined  && params['c__isOpenedAddressCos'] =='false')
            component.set('v.isOpenedAddressCos',false);
        else
            component.set('v.isOpenedAddressCos',true);
        
        //hide show person section Cosrower
         if(params['c__isOpenedPersonalCos'] != undefined  && params['c__isOpenedPersonalCos'] =='false')
            component.set('v.isOpenedPersonalCos',false);
        else
            component.set('v.isOpenedPersonalCos',true);

        
        //hide show Employment section Cosrower
         if(params['c__isOpenedEmpCos'] != undefined  && params['c__isOpenedEmpCos'] =='false')
            component.set('v.isOpenedEmpCos',false);
        else
            component.set('v.isOpenedEmpCos',true);
        
		//hide show Income section Cosrower
         if(params['c__isOpenedIncomeCos'] != undefined  && params['c__isOpenedIncomeCos'] =='false')
            component.set('v.isOpenedIncomeCos',false);
        else
            component.set('v.isOpenedIncomeCos',true);
        
        
        	//hide show housing section Cosrower
         if(params['c__isOpenedHousingCos'] != undefined  && params['c__isOpenedHousingCos'] =='false')
            component.set('v.isOpenedHousingCos',false);
        else
            component.set('v.isOpenedHousingCos',true);
        
        
         //hide show payday section Cosrower
         if(params['c__isOpenedPayDayCos'] != undefined  && params['c__isOpenedPayDayCos'] =='false')
            component.set('v.isOpenedPayDayCos',false);
        else
            component.set('v.isOpenedPayDayCos',true);
        
        
        //hide show nsf section Cosrower
       if(params['c__isOpenedNSFCos'] != undefined  && params['c__isOpenedNSFCos'] =='false')
            component.set('v.isOpenedNSFCos',false);
        else
            component.set('v.isOpenedNSFCos',true);
        

            //hide show nsf section Cosrower
       if(params['c__isOpenedLoanCos'] != undefined  && params['c__isOpenedLoanCos'] =='false')
            component.set('v.isOpenedLoanCos',false);
        else
            component.set('v.isOpenedLoanCos',true);
     
     }
        
        component.set('v.loading',true);
        component.set('v.isVisible',false);
        window.setTimeout(
            $A.getCallback(function() {
                component.set('v.loading',false);
                component.set('v.isVisible',true);
            }), 1000
        );
        var id = component.get('v.recordId');
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + today.getDate()); 
        
        helper.fetchWrapperData(component, event);
        
        var action = component.get("c.getCosigners");
        action.setParams({
            "applicationId": component.get('v.recordId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var cosMap = [];
                for(var key in result){
                    cosMap.push({label: result[key], value: key});
                }
                component.set("v.cosignerMap", cosMap);
            }
        });
        $A.enqueueAction(action);
        //Borrwer Additional
     if(url != ''){
        if(url != undefined && url.includes('c__redirect=boraddional')){
            component.set("v.tabId", 'borrowerTabId');
            component.set("v.tabIdbor", 'borrowerAddiotionalTabId');
            
            //BorrowerProfile
        }else if(url != undefined && url.includes('c__redirect=borprofile')){
            component.set("v.tabId", 'borrowerTabId');
            component.set("v.tabIdbor", 'borrowerProfileTabId');
            
            //Coborrower Profile
        }else if(url != undefined && url.includes('c__redirect=cobprofile')){
            component.set("v.tabId", 'coborrowerTabId');
            component.set("v.tabIdcob", 'coborrowerProfileTabId');
            
            //Coborrower Additional
        }else if(url != undefined && url.includes('c__redirect=cobaddional')){
            component.set("v.tabId", 'coborrowerTabId');
            component.set("v.tabIdcob", 'coborrowerAddiotionalTabId');
            
            //cosigner profile
        }else if(url != undefined && url.includes('c__redirect=cosprofile')){ 
            component.set("v.tabId", 'cosignerTabId');
            component.set("v.tabIdcos", 'coborrowerProfileTabId');
            
            //cosigner additional
        }else if( url != undefined && url.includes('c__redirect=cosaddional')){
            component.set("v.tabId", 'cosignerTabId');
            component.set("v.tabIdcos", 'cosignerAddiotionalTabId');
        }
     }
        helper.fetchPicklistValues(component, event, helper,'Address__c','Province__c');
        
    },
    
    editbq : function(component, event, helper) {
        
        if( component.get('v.bqappLabel') =='Save'){
            // helper.updateRecs(component, event);
        }else{
            component.set('v.bqviewmode',false);
            component.set('v.bqappLabel','Save');
        }
    },
    
    ftasaedit : function(component, event, helper) {
        if( component.get('v.ftasaLabel') =='Confirm'){
            if(component.get('v.ftasa.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                    "type": "error",
                });
                toastEvent.fire();   
            }else if((component.get('v.ftasa.InConsumerProposal__c') =='NO' || component.get('v.ftasa.InConsumerProposal__c') =='') && component.get('v.ftasa.ConsumerProposalDate__c') != undefined){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                    "type": "error",
                });
                toastEvent.fire();
            }
                else{
                    helper.updateRecs(component, event,'appSpecfic');    
                }
        }else{
            component.set('v.ftasaviewmode',false);
            component.set('v.ftasaLabel','Confirm');
        }
    },
    
    ftasacancel : function(component, event, helper) {
        component.set('v.ftasaviewmode',true);
        component.set('v.ftasaLabel','Edit');
    },
    
    editbpa : function(component, event, helper) {
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            component.set('v.bpaviewmode',false);
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.cobpaviewmode',false);
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosignerbpaviewmode',false);
        }
        component.set('v.showSaveButtonbpa',true);
        component.set('v.showEditBtnbpa',false);
        
    },
    editCobpa: function(component, event, helper) {
        //if(component.get('v.bpaappLabel') =='Confirm'){
        // helper.updateBorrowerPreApproval(component, event);            
        //}else{
        component.set('v.bpaviewmode',false);
        component.set('v.showEditBtnCobpa',false);
        component.set('v.showSaveButtonCobpa',true);
        //component.set('v.bpaappLabel','Confirm');
        //}
    },
    editCobor :  function(component, event, helper) {
        
        //if( component.get('v.cobappLabel') =='Save'){
        //helper.updateRecsBor(component, event,'coborrower');    
        //}else{
        component.set('v.cobviewmode',false);
        component.set('v.cobappLabel','Save');
        component.set('v.showSaveButtonCoBor',true);
        component.set('v.showEditBtnCoBor',false);
        //}
    },
    
    editbor:  function(component, event, helper) {
        //if( component.get('v.borappLabel') =='Save'){    
        //}else{
        var currentActiveTab = component.get("v.mainTabName");
        if(currentActiveTab == 'borrower'){
            component.set('v.borviewmode',false);
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.cobviewmode',false);
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosviewmode',false);
        }
        component.set('v.showSaveButtonBor',true);
        component.set('v.showEditBtnBor',false);
        //component.set('v.borappLabel','Save');
        //}
        
    },
    
    editcos : function(component, event, helper) {
        
        if( component.get('v.cosappLabel') =='Save'){
            helper.updateRecsBor(component, event,'cosigner');    
        }else{
            component.set('v.cosviewmode',false);
            component.set('v.cosappLabel','Save');
        }        
    },
    
    cancelcos: function(component, event, helper) {
        component.set('v.cosviewmode',true);
        component.set('v.cosappLabel','Edit');
        
    },
    
    cancelbor : function(component, event, helper) {
        component.set('v.borviewmode',true);
        component.set('v.borappLabel','Edit');
    },
    
    cancelcob : function(component, event, helper) {
        component.set('v.cobviewmode',true);
        component.set('v.cobappLabel','Edit');
    },
    
    cancelbpa : function(component, event, helper) {
        component.set('v.bpaviewmode',true);
        component.set('v.bpaappLabel','Edit');
    },
    
    cancelbq : function(component, event, helper) {
        component.set('v.bqviewmode',true);
        component.set('v.bqappLabel','Edit');
    },
    
    handleOnSubmit : function(component, event, helper) {},
    
    handleOnSuccess : function(component, event, helper) {},
    
    handleOnError : function(component, event, helper) {},
    
    addcoborrower : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Borrower');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','coborrower');
    },
    
    addcosigner : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Signer');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','cosigner');
    },
    
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    submitDetails: function(component, event, helper) {
        
        var callApex=true;
        var lookup = (component.get('v.selectedLookUpRecord'));
        if(component.get('v.selectedradio') == 'search' && (component.get('v.selectedLookUpRecord').Id == undefined))
        {
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Email Cannot be left Blank!',
                "type": "error"
            });
            toastEvent.fire();
        }else if (component.get('v.selectedradio') == 'add' && (component.get('v.accountRec.FirstName') =='' || component.get('v.accountRec.LastName') =='' ||  component.get('v.accountRec.PersonEmail') =='')) {
            
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Fill All Required Fields!',
                "type": "error"
            });
            toastEvent.fire();
        }
        
        
        if(callApex){ 
            if(component.get('v.apptype') =='cosigner'){
                var accrecord = component.get('v.accountRec');
                accrecord.IsActive__pc =true;
                component.set('v.accountRec',accrecord);
            }
            console.log(component.get('v.accountRec'));
            var action = component.get("c.createUpdateAccount");
            action.setParams({
                "existingAccount": component.get('v.selectedLookUpRecord'),
                "newRec": component.get('v.accountRec'),
                "applicantType" : component.get('v.apptype'),
                "applicationId" : component.get('v.recordId')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var recId = response.getReturnValue();
                    if(recId == 'fail'){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Add Failed: User Already Present as Borrower/Co-Borrower/Co-Signer!',
                            "type": "error",
                        });
                        toastEvent.fire();
                    }else{
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Added Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                        };
                        navLink.navigate(pageRef, true);
                        //  $A.get('e.force:refreshView').fire();
                        component.set("v.isModalOpen", false);
                    }
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    var finalErrorMessage;
                    if (errors) {
                        var databaseError = errors[0].message;
                        if(databaseError.includes("A9A"))
                            finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                        else
                            finalErrorMessage =  databaseError;
                        
                        
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": finalErrorMessage,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
        }
    },
    
    handleSaveEdition: function(component, event, helper) {
        var draftValues = event.getParam('draftValues');
        console.log(draftValues);
        var callApex=true;
        var message ='';
        
        var today = new Date();        
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        // if date is less then 10, then append 0 before date   
        if(dd < 10){
            dd = '0' + dd;
        } 
        // if month is less then 10, then append 0 before date    
        if(mm < 10){
            mm = '0' + mm;
        }
        
        var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
        
        for(var count=0;count < draftValues.length; count++){
            if(draftValues[count].AddressSinceDate__c != undefined ){
                if(draftValues[count].AddressSinceDate__c > todayFormattedDate)
                    message = 'Address Moved In date cannot be more than todays date!';
                
            }else if(draftValues[count].AddressEndDate__c != undefined ){
                if(draftValues[count].AddressEndDate__c > todayFormattedDate)
                    message = 'Address Moved out date cannot be more than todays date!';
            }
                else if(draftValues[count].EmploymentStartDate__c != undefined){
                    if(draftValues[count].EmploymentStartDate__c > todayFormattedDate)
                        message = 'Employment Start Date cannot be more than todays date!';
                    
                }else if(draftValues[count].EmploymentEndDate__c != undefined){
                    if(draftValues[count].EmploymentEndDate__c > todayFormattedDate)
                        message = 'Employment End Date cannot be more than todays date!';
                }
            
            if(message != ''){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": message,
                    "type": "error",
                });
                toastEvent.fire();
                return;
            }
        }
        
        
        var action = component.get("c.updateRecords");
        action.setParams({"sobjList" : draftValues, "toUpateApplication" : false, "appRecord" :undefined});
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (component.isValid() && state === "SUCCESS") {
                helper.fetchWrapperData(component, event);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Updated Successfully!',
                    "type": "success",
                });
                toastEvent.fire();    
            } else if (state === "ERROR") {
                var errors = action.getError();
                var finalmessage='';
                if (errors) {
                    if( errors[0].message.includes('Province: bad value for restricted picklist field' ) )
                        finalmessage= 'Invalid Province. Only AB, BC, MB, NB, NL, NS, NT, NU, ON, PE, QC, SK, YT Allowed';
                    else if(errors[0].message.includes('A person should have only one primary address'))
                        finalmessage = 'A person should have only one primary address';
                    
                        else if(errors[0].message.includes('Employment Start Month: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Month can only Be January,February,March,April,May,June,July,August,Septemeber,October,November,December';
                        }else if(errors[0].message.includes('Employment Start Year: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Year Can only be of format 2000, 2001, 2002...';
                        }
                            else if(errors[0].message.includes('A person should have only one primary email allowed'))
                                finalmessage = 'A person should have only one primary email allowed';
                                else
                                    finalmessage = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalmessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }            
        });
        $A.enqueueAction(action);
    },
    
    viewInactivecos :  function(component, event, helper) {
        component.set('v.isModalOpenCos',true);
    },
    
    closecosModel :  function(component, event, helper) {
        component.set('v.isModalOpenCos',false);
    },
    
    addAddress : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        /*   var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();            	
        }else if(addAdress =='coborroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
        }else if(addAdress =='cosigneraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
            
        }*/
        var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            let borrower = component.get('v.borrower');
            component.set('v.reqAccId',borrower.Id);
        }else if(addAdress =='coborroweraddress'){
            let coborrower = component.get('v.coborrower');
            component.set('v.reqAccId',coborrower.Id);
        }else if(addAdress =='cosigneraddress'){
            let cosigner = component.get('v.activecosigner');
            component.set('v.reqAccId',cosigner.Id);
        }
        
        component.set('v.showAddAddressCMP',true);
        
    },
    
    addEmail : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var email = event.getSource().getLocalId();
        if(email =='borroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();            	
        }else if(email =='coborroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();
            
        }else if(email =='cosigneremail'){
            var createEmail = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();  
        }
    },
    
    addPhone : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var phone = event.getSource().getLocalId();
        if(phone =='borrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();            	
        }else if(phone =='coborrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();
            
        }else if(phone =='cosignerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();  
        }
    },
    
    addEmployment : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var emp = event.getSource().getLocalId();
        if(emp =='borroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();            	
        }else if(emp =='coborroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();
            
        }else if(emp =='cosigneremp'){
            var createEmp = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();  
        }
    },
    
    sendconnecturl : function(component, event, helper) {
        
        var action = component.get("c.getBankUrl");
        action.setParams({
            "applicationId": component.get('v.recordId'),                
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "Bank Connection URL Sent Successfully!",
                    "type": "success"
                });
                toastEvent.fire();
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                if (errors) {
                    var databaseError = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": databaseError,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action);   
        
    },
    
    checkValidity : function(component, event, helper) {
        var validity = event.getSource().get("v.validity");
        console.log(validity)
    },
    
    checkReason :  function(component, event, helper) {
        if(component.get('v.applicationRec.ApplicationStatus__c') =='Rejected')
            component.set('v.showReason',true);
        else
            component.set('v.showReason',false);
    },
    
    activatecos : function(component, event, helper) {
        component.set('v.showActivateCosScreen',true);
        component.set('v.isModalOpenCos',false);
    },
    
    closecosaModel :function(component, event, helper) {
        component.set('v.showActivateCosScreen',false);
        component.set('v.cos','');
    },
    
    activateCosigner : function(component, event, helper) {
        var callApex =true;
        if(component.get('v.cos') == undefined || component.get('v.cos') =='' ){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Select Atleast One Co-Signer',
                "type": "error",
            });
            toastEvent.fire();
        }else{
            
            var action = component.get("c.updateActiveCosigner");
            action.setParams({
                "idToActivate": component.get('v.cos'),
                "activecos": component.get('v.activecosigner')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    component.set('v.loading',true);
                    
                    
                    window.setTimeout(
                        $A.getCallback(function() {
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                "title": "Success!",
                                "message": 'Co-Signer Activated!',
                                "type": "success",
                            });
                            toastEvent.fire();
                            component.set("v.loading",false);
                            location.reload(true);
                        }), 3000
                    );
                    component.set('v.showActivateCosScreen',false);
                    
                    
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    if (errors) {
                        var databaseError = errors[0].message;
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": databaseError,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
            
        }
    },
    handleVerticalMenu:function(component,event,helper)
    {
        component.set('v.eventcall',true);
        var tab = event.getParam("tab");
        if(tab=="applicants") {
           
              helper.fetchWrapperData(component, event);
            
        }
        else
            component.set('v.isVisible','false');
        
    },
    cancelSaveProfile : function(component,event,helper){
        
        
        var currentActiveTab = component.get("v.mainTabName");
        var redirectParam = '';
        
        if(currentActiveTab == 'borrower'){
            redirectParam ='borprofile';
        }else if(currentActiveTab == 'coborrower'){
            redirectParam='cobprofile';
        }else if(currentActiveTab == 'cosigner'){
            redirectParam='cosprofile';
        }
        
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__recordPage',
            attributes: {
                actionName: 'view',
                objectApiName: 'Application__c',
                recordId : component.get('v.recordId'),
                
            },
            state: {
                c__redirect : redirectParam,
                     c__isOpenedEmailBor : component.get('v.isOpenedEmailBor') ? 'true': 'false',
                                c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                
            },
        };
        navLink.navigate(pageRef, true);
    },
    
    cancelSave : function(component,event,helper){
        
        var currentActiveTab = component.get("v.mainTabName");
        var redirectParam = '';
        
        if(currentActiveTab == 'borrower'){
            redirectParam ='boraddional';
        }else if(currentActiveTab == 'coborrower'){
            redirectParam='cobaddional';
        }else if(currentActiveTab == 'cosigner'){
            redirectParam='cosaddional';
        }
        
        var navLink = component.find("navLink");
        var pageRef = {
            type: 'standard__recordPage',
            attributes: {
                actionName: 'view',
                objectApiName: 'Application__c',
                recordId : component.get('v.recordId'),
                
            },
            state: {
                c__redirect : redirectParam,
                  c__isOpenedPhoneBor : component.get('v.isOpenedPhoneBor') ? 'true': 'false',
                                c__isOpenedAddressBor : component.get('v.isOpenedAddressBor') ? 'true': 'false',
                                c__isOpenedPersonalBor : component.get('v.isOpenedPersonalBor') ? 'true': 'false',
                                c__isOpenedEmpBor : component.get('v.isOpenedEmpBor') ? 'true': 'false',
                                c__isOpenedIncomeBor : component.get('v.isOpenedIncomeBor') ? 'true': 'false',
                                c__isOpenedHousingBor : component.get('v.isOpenedHousingBor') ? 'true': 'false',
                                c__isOpenedPayDayBor : component.get('v.isOpenedPayDayBor') ? 'true': 'false',
                                c__isOpenedNSFBor : component.get('v.isOpenedNSFBor') ? 'true': 'false',
                                c__isOpenedLoanBor : component.get('v.isOpenedLoanBor') ? 'true': 'false',
                                c__isOpenedEmailCob : component.get('v.isOpenedEmailCob') ? 'true': 'false',
                                c__isOpenedPhoneCob : component.get('v.isOpenedPhoneCob') ? 'true': 'false',
                                c__isOpenedAddressCob : component.get('v.isOpenedAddressCob') ? 'true': 'false',
                                c__isOpenedPersonalCob : component.get('v.isOpenedPersonalCob') ? 'true': 'false',
                                c__isOpenedEmpCob : component.get('v.isOpenedEmpCob') ? 'true': 'false',
                                c__isOpenedIncomeCob : component.get('v.isOpenedIncomeCob') ? 'true': 'false',
                                c__isOpenedHousingCob : component.get('v.isOpenedHousingCob') ? 'true': 'false',
                                c__isOpenedPayDayCob : component.get('v.isOpenedPayDayCob') ? 'true': 'false',
                                c__isOpenedNSFCob : component.get('v.isOpenedNSFCob') ? 'true': 'false',
                                c__isOpenedLoanCob : component.get('v.isOpenedLoanCob') ? 'true': 'false',
                                c__isOpenedEmailCos : component.get('v.isOpenedEmailCos') ? 'true': 'false',
                                c__isOpenedPhoneCos : component.get('v.isOpenedPhoneCos') ? 'true': 'false',
                                c__isOpenedAddressCos : component.get('v.isOpenedAddressCos') ? 'true': 'false',
                                c__isOpenedPersonalCos : component.get('v.isOpenedPersonalCos') ? 'true': 'false',
                                c__isOpenedEmpCos : component.get('v.isOpenedEmpCos') ? 'true': 'false',
                                c__isOpenedIncomeCos : component.get('v.isOpenedIncomeCos') ? 'true': 'false',
                                c__isOpenedHousingCos : component.get('v.isOpenedHousingCos') ? 'true': 'false',
                                c__isOpenedPayDayCos : component.get('v.isOpenedPayDayCos') ? 'true': 'false',
                                c__isOpenedNSFCos : component.get('v.isOpenedNSFCos') ? 'true': 'false',
                                c__isOpenedLoanCos : component.get('v.isOpenedLoanCos') ? 'true': 'false',
                
                
            },
        };
        navLink.navigate(pageRef, true);
    },
    
    
    
    
    showTemplateBody:function(component,event,helper){
        component.set('v.loading','true');
        
        helper.fetchTemplateBody(component,event,helper);
    },
    
    toggleEmailBor : function(component, event, helper) {
        component.set("v.isOpenedEmailBor", !component.get("v.isOpenedEmailBor"));
    },
    
    togglePhoneBor : function(component, event, helper) {
        component.set("v.isOpenedPhoneBor", !component.get("v.isOpenedPhoneBor"));
    },
    toggleAddressBor : function(component, event, helper) {
        component.set("v.isOpenedAddressBor", !component.get("v.isOpenedAddressBor"));
    },
    toggleEmpBor : function(component, event, helper) {
        component.set("v.isOpenedEmpBor", !component.get("v.isOpenedEmpBor"));
    },
    togglePersonalBor : function(component, event, helper) {
        component.set("v.isOpenedPersonalBor", !component.get("v.isOpenedPersonalBor"));
    },
    toggleEmailCob : function(component, event, helper) {
        component.set("v.isOpenedEmailCob", !component.get("v.isOpenedEmailCob"));
    },
    togglePhoneCob : function(component, event, helper) {
        component.set("v.isOpenedPhoneCob", !component.get("v.isOpenedPhoneCob"));
    },
    toggleAddressCob : function(component, event, helper) {
        component.set("v.isOpenedAddressCob", !component.get("v.isOpenedAddressCob"));
    },
    toggleEmpCob : function(component, event, helper) {
        component.set("v.isOpenedEmpCob", !component.get("v.isOpenedEmpCob"));
    },
    togglePersonalCob : function(component, event, helper) {
        component.set("v.isOpenedPersonalCob", !component.get("v.isOpenedPersonalCob"));
    },
    toggleEmailCos : function(component, event, helper) {
        component.set("v.isOpenedEmailCos", !component.get("v.isOpenedEmailCos"));
    },
    togglePhoneCos : function(component, event, helper) {
        component.set("v.isOpenedPhoneCos", !component.get("v.isOpenedPhoneCos"));
    },
    toggleAddressCos : function(component, event, helper) {
        component.set("v.isOpenedAddressCos", !component.get("v.isOpenedAddressCos"));
    },
    toggleEmpCos : function(component, event, helper) {
        component.set("v.isOpenedEmpCos", !component.get("v.isOpenedEmpCos"));
    },
    togglePersonalCos : function(component, event, helper) {
        component.set("v.isOpenedPersonalCos", !component.get("v.isOpenedPersonalCos"));
    },
    toggleIncomeBor :  function(component, event, helper) {
        component.set("v.isOpenedIncomeBor", !component.get("v.isOpenedIncomeBor"));
    },
    toggleIncomeCob :   function(component, event, helper) {
        component.set("v.isOpenedIncomeCob", !component.get("v.isOpenedIncomeCob"));
    },
    toggleIncomeCos :   function(component, event, helper) {
        component.set("v.isOpenedIncomeCos", !component.get("v.isOpenedIncomeCos"));   
    },
    
    toggleHousingBor :   function(component, event, helper) {
        component.set("v.isOpenedHousingBor", !component.get("v.isOpenedHousingBor"));   
    },
    
    toggleHousingCob :   function(component, event, helper) {
        component.set("v.isOpenedHousingCob", !component.get("v.isOpenedHousingCob"));   
    },
    
    toggleHousingCos :   function(component, event, helper) {
        component.set("v.isOpenedHousingCos", !component.get("v.isOpenedHousingCos"));   
    },
    
    togglePayDayBor :  function(component, event, helper) {
        component.set("v.isOpenedPayDayBor", !component.get("v.isOpenedPayDayBor"));   
    },
    
    togglePayDayCob :  function(component, event, helper) {
        component.set("v.isOpenedPayDayCob", !component.get("v.isOpenedPayDayCob"));   
    },
    
    togglePayDayCos :  function(component, event, helper) {
        component.set("v.isOpenedPayDayCos", !component.get("v.isOpenedPayDayCos"));   
    },
    
    toggleNSFBor:  function(component, event, helper) {
        component.set("v.isOpenedNSFBor", !component.get("v.isOpenedNSFBor")); 
    },
    
    toggleNSFCob:  function(component, event, helper) {
        component.set("v.isOpenedNSFCob", !component.get("v.isOpenedNSFCob"));
    },
    
    toggleNSFCos:  function(component, event, helper) {
        component.set("v.isOpenedNSFCos", !component.get("v.isOpenedNSFCos"));
    },
    
    toggleLoanBor:  function(component, event, helper) {
        component.set("v.isOpenedLoanBor", !component.get("v.isOpenedLoanBor"));
    },
    
    toggleLoanCob:  function(component, event, helper) {
        component.set("v.isOpenedLoanCob", !component.get("v.isOpenedLoanCob"));
    },
    toggleLoanCos:  function(component, event, helper) {
        component.set("v.isOpenedLoanCos", !component.get("v.isOpenedLoanCos"));
    },
    
    removeCob: function(component, event, helper) {
        component.set('v.isRemoveCoBorrower',true);
    },
    
    removecos: function(component,event,helper){
        component.set('v.isRemoveCoSigner',true);
    }
    ,
    handleExistingAccountSelect : function(component,event,helper){
        var selectedAccountGetFromEvent = event.getParam("recordByEvent");
        if(component.get('v.isAddCoBorrower')){
            var borAccount = component.get('v.accountRec');
            
            borAccount.FirstName = selectedAccountGetFromEvent.FirstName;
            borAccount.LastName = selectedAccountGetFromEvent.LastName;
            borAccount.PersonEmail = selectedAccountGetFromEvent.PersonEmail;
            borAccount.Username__pc = selectedAccountGetFromEvent.Username__pc;
            component.set('v.accountRec',borAccount);
            
        }
        else if(component.get('v.isAddCoSigner')){
            var cosAccount = component.get('v.accountRecCos');
            cosAccount.FirstName = selectedAccountGetFromEvent.FirstName;
            cosAccount.LastName = selectedAccountGetFromEvent.LastName;
            cosAccount.PersonEmail = selectedAccountGetFromEvent.PersonEmail;
            cosAccount.Username__pc = selectedAccountGetFromEvent.Username__pc;
            component.set('v.accountRecCos',cosAccount);
        }
        
    },
    
    clearAccount : function(component,event,helper){
        console.log('hello');
        
        var acc = {};
        acc.FirstName ='';
        acc.LastName ='';
        acc.PersonEmail ='';
        acc.Username__c ='';
        component.set('v.templatePreviewBody','');
        component.set('v.emailTemplateSelectedVal','');
        component.set('v.popupErrorMessage','');
        if(component.get('v.isAddCoBorrower')){
            component.set('v.accountRec',acc);
        }
        else if(component.get('v.isAddCoSigner')){ 
            component.set('v.accountRecCos',acc);
        }
    },
    
    handleRowAction : function(component,event,helper){
        
        var row = event.getParam('row');
        console.log(JSON.stringify(row)); 
        component.set('v.isOpenEmail',true);
        component.set('v.emailLabel','Update');
        component.set('v.newEmailObj',row);
        if(row.IsPrimary__c)
            
            component.set('v.newEmailIsPrimary__c','true');
        else
            component.set('v.newEmailIsPrimary__c','false');      
        
        
        
    },
    
    handleRowActionPhone : function(component,event,helper){
        
        
        
        var row = event.getParam('row');
        
        if(row.PhoneType__c.toUpperCase() === 'HOME')
            row.PhoneType__c = 'HOME';
        if(row.PhoneType__c.toUpperCase() === 'MOBILE')
            row.PhoneType__c = 'MOBILE';
        if(row.PhoneType__c.toUpperCase() === 'FAX')
            row.PhoneType__c = 'FAX';
        if(row.PhoneType__c.toUpperCase() === 'WORK')
            row.PhoneType__c = 'WORK';
        
        console.log(JSON.stringify(row)); 
        component.set('v.isOpenPhone',true);
        component.set('v.phoneLabel','Update');
        component.set('v.newPhoneObj',row);
        
        //alert(row.PhoneType__c);
        
        if(row.IsPrimary__c)
            
            component.set('v.newPhoneIsPrimary__c','true');
        else
            component.set('v.newPhoneIsPrimary__c','false');      
        
    },
    
    handleRowActionAddress : function(component,event,helper){
        var row = event.getParam('row');
        component.set('v.isOpenAddress',true);
        component.set('v.addressLabel','Update');
        component.set('v.newAddressObj',row);
        
    },
    
    handleRowActionEmp: function(component,event,helper){
        var row = event.getParam('row');
        component.set('v.isAddEmp',true);
        component.set('v.employmentLabel','Update');
        
        
        var currentActiveTab = component.get("v.mainTabName");
        
        if(currentActiveTab == 'borrower'){
            component.set('v.borEmp',row);; 
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.cobEmp',row); 
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosEmp',row);
        }
        
    },
    
    handleRowActionLoan : function(component,event,helper){
        
        var row = event.getParam('row');
        component.set('v.isAddLoanDebt',true);
        component.set('v.loanDebtLabel','Update');
        
        
        var currentActiveTab = component.get("v.mainTabName");
        
        if(currentActiveTab == 'borrower'){
            component.set('v.borrowerLiabilityNew',row);; 
        }else if(currentActiveTab == 'coborrower'){
            component.set('v.coborrowerLiabilityNew',row); 
        }else if(currentActiveTab == 'cosigner'){
            component.set('v.cosignerLiabilityNew',row);
        }
    },
    
    requestBorrower : function(component,event,helper){
        
        component.set("v.loading",true);
        helper.fetchEmailTemplatesRequestCobCos(component, event, helper);
        component.set('v.isrequestCobCos',true);
        component.set('v.templatePreviewBody','');   
    },
    
    closereqModal : function(component,event,helper){
        
        component.set('v.isrequestCobCos',false);
        helper.resetPopUpErrorMessage(component, event, helper);
    },
    
    sendRequestbor : function(component,event,helper){
        
        if(component.get('v.emailTemplateSelectedVal') == ''){
            component.set("v.popupErrorMessage", 'Select Email Template');
            return;
        }
        
        var selectedTemplate =component.get('v.emailTemplateSelectedVal');
        helper.sendReqforCObCos(component,event, selectedTemplate);
    },
    emailCoborrowerModalBox : function(component,event,helper){
        component.set("v.loading",true);
        component.set('v.openCoborrowerEmailInviteBox',true);
        helper.fetchEmailTemplatesListCoBorr(component,event,helper);
        //helper.fetchTemplateBodyForCoborr(component,event,helper);
    },
    closeCoborrowerModalBox : function(component,event,helper){
        component.set('v.openCoborrowerEmailInviteBox',false);
    },
    sendEmailToCoborr : function(component,event,helper){
        var selectedTemplate =component.get('v.emailTemplateSelectedVal');
        //helper.sendReqforCObCos(component,event, selectedTemplate);
        helper.sendCoborrEmailInvite(component,event,selectedTemplate);
    },
    emailCosignerModalBox : function(component,event,helper){
        component.set("v.loading",true);
        component.set('v.openCosignerEmailInviteBox',true);
        helper.fetchEmailTemplatesListCoSignr(component,event,helper);
        //helper.fetchTemplateBodyForCosigner(component,event,helper);
    },
    closeCosignerModalBox : function(component,event,helper){
        component.set('v.openCosignerEmailInviteBox',false);
    },
    sendEmailToCosigner : function(component,event,helper){
        var selectedTemplate =component.get('v.emailTemplateSelectedVal');
        //helper.sendReqforCObCos(component,event, selectedTemplate);
        helper.sendCosignerEmailInvite(component,event,selectedTemplate);
    }
    
})
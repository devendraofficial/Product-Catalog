({
    BankAccount: function(component, event, helper) {
        //Fetching the Bank Account Details
         console.log("BankAccount Controller Start");
        var action = component.get("c.fetchBankAccount");
        var recordId = component.get('v.recordId');
        action.setParams({
            RecordID: recordId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){        
                var apexReponse = response.getReturnValue();
                console.log("BankDetails"+apexReponse);
                component.set("v.BankAccount", apexReponse.cosignerBankDetails);
                console.log("cosignercosigner "+apexReponse.cosignerBankDetails);
                 if(apexReponse.cosignerBankDetails != 'undefined'){
                        component.set("v.isBankAccountNull",true);
                     console.log("cosignercosigner if ");
                    }
                    else{
                        console.log("cosignercosigner else");
                        component.set("v.isBankAccountNull",false);
                    }
               
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("BankAccount Controller Start End");
    },
    fetchBankAccounts:function(component,event,helper){
        var customstartdate = '1970-01-01';
        console.log("customstartdate : "+customstartdate);
        var customenddate = '2020-05-01';
        console.log("customenddate : "+customenddate);
        component.set("v.filterCustomStartDate",customstartdate);
        component.set("v.filterCustomEndDate",customenddate);
        component.set("v.enableInfiniteLoading",true);
        console.log("enableInfiniteLoading fetchBankAccounts : "+component.get("v.enableInfiniteLoading"));
        component.set("v.currentCount",0);
        helper.getData(component, helper);
    },
    
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
    },
    
    Emails : function(component, event, helper) { 
      
    },

    JointAccount : function(component, event, helper) {        
        var isJointChecked = component.find('JointAccount').get('v.checked');
        console.log("Bank Account ID :"+component.get("v.BankAccountID"));
        helper.fetchJointAccounts(component, helper);
    },
    
    handleLoadMore :function(component, event, helper){
        console.log("handleLoadMore Action");
            console.log("currentCount : "+component.get("v.currentCount"));
            console.log("totalRows : "+component.get("v.totalRows"));
            if(!(component.get("v.currentCount") >= component.get("v.totalRows"))){
                //To display the spinner
                event.getSource().set("v.isLoading", true); 
                //To handle data returned from Promise function
                helper.loadData(component).then(function(data){ 
                    var currentData = component.get("v.data");
                    var newData = currentData.concat(data);
                    
                    
                    
                    component.set("v.data", newData);
                    //To hide the spinner
                    event.getSource().set("v.isLoading", false); 
                });
            }
            else{
                //To stop loading more rows
                component.set("v.enableInfiniteLoading",false);
                console.log("enableInfiniteLoading : "+component.get("v.enableInfiniteLoading"));
                event.getSource().set("v.isLoading", false);
             
            }
     
    },
    
    handleRowAction  : function(component, event, helper) {        
        alert('Row is selected');
    }, 
    updateSelectedText : function(component, event, helper) {
        var  sum = 0;      
        var selectedRows = event.getParam('selectedRows');
        console.log(selectedRows);
        component.set("v.selectedRowsCount" ,selectedRows.length );
        let obj =[] ; 
        for (var i = 0; i < selectedRows.length; i++){
            sum = sum + Math.round(selectedRows[i].CreditAmount) + Math.round(selectedRows[i].DebitAmount);
            console.log(sum);
        }
        console.log(Object.values(selectedRows));
        if(selectedRows.length <= 0){
            component.set("v.Sum" ,0);
        }
        else{
            component.set("v.Sum" ,sum);
        }
  }, 
    
    filterThisMonth  : function(component, event, helper) {        
        component.set("v.filterDate",'THIS_MONTH');
    }, 
    filterLatest3Months  : function(component, event, helper) {        
        component.set("v.filterDate",'Last_N_Months:3');
    },
    filterThisYear  : function(component, event, helper) {        
        component.set("v.filterDate",'THIS_YEAR');
    },
    filterLastYear  : function(component, event, helper) {        
        component.set("v.filterDate",'LAST_YEAR');
    },
    filterAllDates  : function(component, event, helper) {        
        component.set("v.filterDate",'All');
    },
    Update: function(component, event, helper) {
        component.set("v.isOpen", false);
        // component.set("v.filterCustomStartDate");
       var customstartdate = component.find("customStartDate").get("v.value");
        if(customstartdate != ''){
            console.log("In if");
            component.set("v.filterCustomStartDate",customstartdate);
        }
        else{
             component.set("v.filterCustomStartDate",null);
        }
        //filterCustomStartDate,filterCustomEndDate
        console.log('customstartdate : '+customstartdate);
        var customenddate = component.find("customEndDate").get("v.value");
        if(customenddate != ''){
            console.log("In if2");
            component.set("v.filterCustomEndDate",customenddate);
        }
        else{
             component.set("v.filterCustomEndDate",null);
        }
        console.log('customenddate : '+customenddate);
        var filterdate = component.get("v.filterDate");
        var flaglist = component.get("v.filterFlag");
        helper.FilterTransactionsHelper(component, helper);
        
    },
    AutoLoan  : function(component, event, helper) {   
        var filterautoLoan = component.find("autoLoan").get("v.checked");
        console.log('AutoLoan : '+filterautoLoan);
        var flaglist = component.get("v.filterFlag");
        if(!flaglist.includes("AUTO_LOAN")){
            flaglist.push("AUTO_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'AUTO_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist); 
    },
    
    Collection  : function(component, event, helper) {        
        var filtercollection = component.find("collection").get("v.checked");  
        console.log('Collection : '+filtercollection);
        var flaglist = component.get("v.filterFlag");
        if(filtercollection){
            flaglist.push("COLLECTION");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'COLLECTION') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },    
    
    CreditRebuilding  : function(component, event, helper) {        
        var filtercreditRebuilding =component.find("creditRebuilding").get("v.checked");  
        console.log('CreditRebuilding : '+filtercreditRebuilding);
        var flaglist = component.get("v.filterFlag");
        if(filtercreditRebuilding){
            flaglist.push("CREDIT_REBUILDING_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'CREDIT_REBUILDING_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    DebtManagement  : function(component, event, helper) {        
        var filterdebtManagement = component.find("debtManagement").get("v.checked");  
        console.log('DebtManagement : '+filterdebtManagement);
        var flaglist = component.get("v.filterFlag");
        if(filterdebtManagement){
            flaglist.push("DEBT_MANAGEMENT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'DEBT_MANAGEMENT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    HighCostLoan  : function(component, event, helper) {        
        var filterhighCostLoan = component.find("highCostLoan").get("v.checked");
        console.log('HighCostLoan : '+filterhighCostLoan);
        var flaglist = component.get("v.filterFlag");
        if(filterhighCostLoan){
            flaglist.push("HIGH_COST_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'HIGH_COST_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    NSF  : function(component, event, helper) {        
        var filterNSF = component.find("NSF").get("v.checked");
        console.log('NSF : '+filterNSF);
        var flaglist = component.get("v.filterFlag");
        if(filterNSF){
            flaglist.push("NSF");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'NSF') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    Overdraft  : function(component, event, helper) {        
        var filteroverdraft = component.find("overdraft").get("v.checked");  
        console.log('Overdraft : '+filteroverdraft);
        var flaglist = component.get("v.filterFlag");
        if(filteroverdraft){
            flaglist.push("OVERDRAFT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'OVERDRAFT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    PaydayLoan  : function(component, event, helper) {        
        var filterpaydayLoan = component.find("paydayLoan").get("v.checked");
        console.log('PaydayLoan : '+filterpaydayLoan);
        var flaglist = component.get("v.filterFlag");
        if(filterpaydayLoan){
            flaglist.push("PAYDAY_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'PAYDAY_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    TrusteePayment  : function(component, event, helper) {        
        var filtertrusteePayment = component.find("trusteePayment").get("v.checked");
        console.log('TrusteePayment : '+filtertrusteePayment);
        var flaglist = component.get("v.filterFlag");
        if(filtertrusteePayment){
            flaglist.push("TRUSTEE_PAYMENT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'TRUSTEE_PAYMENT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    searchBankTransaction: function(component, event, helper){
         var data = component.get("v.Filterdata"),
        term = component.get("{!v.searchKeyWord}"),
        results = data, regex;
    
        if(term !=''){
        regex = new RegExp(term, "i");
        // filter checks each row, constructs new array where function returns true
        results = data.filter(row => regex.test(row.Name)  || 
                              regex.test(row.CreditAmount) || 
                              regex.test(row.Amount__c)|| 
                              regex.test(row.IsReccuring__c)||
                             regex.test(row.ResultingBalance__c) ||
                             regex.test(row.Flags__c)||
                             regex.test(row.SubCategory) ||
                             regex.test(row.DebitAmount)) 
                              ;
       component.set("v.data",results);
   		component.set("v.enableInfiniteLoading",false);
        }else{
             component.set("v.data",component.get("v.Filterdata") );
            component.set("v.enableInfiniteLoading",true);
        }
    },
    handleSort: function(component, event, helper) {
        helper.handleSort(component, event);
    },
    openNewWindow: function(component, event, helper){
        console.log('1');
        /*   var action = component.get("c.fetchBankTransactionVF");
        var recordId = component.get('v.BankAccountID');
        console.log('2');
        action.setParams({
            RecordID: recordId
        });
        action.setCallback(this, function(response) {
            console.log('3');
            var state = response.getState();
            console.log('4');
            if(state === 'SUCCESS') {
                console.log('5');
                var creditData = response.getReturnValue();
                //   var recordId = creditData[0].Id;
                console.log('6');
                window.open('/apex/BankTransactionVFPage?id='+recordId);
            }
            else {
                alert('No data found');
            }
        });
        $A.enqueueAction(action);*/
        console.log('End');
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef : "c:BankStatementDefaultPage",
            componentAttributes: {
                recordId : component.get("v.recordId")
            }
        });
      window.open( evt.fire());
    },
    
    handleVerticalMenu:function(component,event,helper){
        var tab = event.getParam("tab");
        if(tab=="BankStatement"){
            component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false');
        
    },
  
})
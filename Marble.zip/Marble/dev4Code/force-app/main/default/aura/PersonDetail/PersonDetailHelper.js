({
	fetchData : function(component,event,helper) {
		
         var action = component.get("c.getPersonDetails");
        action.setParams({ LoanApplicationId : component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               
                component.set('v.personDetails',response.getReturnValue().app);
                component.set('v.loanAmount',response.getReturnValue().outstandingBalance);
                component.set('v.accDetails',response.getReturnValue().acc);
                component.set('v.recoveredDocuments',response.getReturnValue().recDocList);
			
				
            }
        });
        $A.enqueueAction(action);
        
	}
})
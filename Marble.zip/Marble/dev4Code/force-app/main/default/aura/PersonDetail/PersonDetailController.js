({
	doInit : function(component, event, helper) {
		helper.fetchData(component,event,helper);
	},
    handleVerticalMenu:function(component,event,helper)
    {
       var tab = event.getParam("tab");
        
        
        if(tab=="documents")
        {
            
           component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false')

    }
})
({
    fetchData : function(component,event,helper) {
         component.set('v.showEmpty',false);
        var actions = [
            { label: 'edit', name: 'edit' }   
        ]        
        component.set('v.mycolumns', [
            {label: 'ADDED', fieldName: 'CreatedDate', type: 'date'},
            {label: 'FILE NAME', fieldName: 'Title', type: 'button' , typeAttributes: { label: { fieldName: 'Title' } ,name:'View' ,'class': 'custom'}},
            {label: 'TYPE', fieldName: 'DocumentType', type: 'text' },
            {label: 'STATUS', fieldName: 'DocumentStatus__c', type: 'text' },
            { type: 'action', typeAttributes: { rowActions: actions } }           
        ]);       
        var action = component.get("c.getProDocumentsList");
        var val = component.get("v.recordId");
        console.log('value1'+val);
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType'),searchName :component.get('v.searchName')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {        
               //  component.set('v.recoveredDocuments',response.getReturnValue());

                var recordData = response.getReturnValue();
                recordData.forEach(function(Rec){
       

                        
                    if(Rec.DocumentStatus__c  == 'Pending')
                        Rec.Name= Rec.DocumentType__c+' (Pending)';
                    else
                        Rec.Name= Rec.DocumentType__c;
                    
                    Rec.Content_Versions__r ? Rec.Content_Versions__r.forEach(function(Rec2){
                        console.log('finals'+Rec2.Title);
                        Rec2.DocumentType=Rec.DocumentType__c;
                        Rec2.DocumentStatus=Rec.DocumentStatus__c;
                    }):''})
            
                

                component.set('v.recoveredDocuments',recordData);
                 component.set('v.recoveredDocumentsCopy',recordData);
              component.set('v.recoveredDocumentsCopy1',recordData);
                
            }
        });
        $A.enqueueAction(action);        
    },
    
    
  
    
    
    
    
    
    fetchData2 : function(component,event,helper) {
       
      component.set('v.showEmpty',false);
       
        var action = component.get("c.getProDocumentsList1");
        var val = component.get("v.recordId");
        console.log('value1'+val);
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType'),searchName :component.get('v.searchName')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {        

                 var activeSection =[];
                var recordData = response.getReturnValue();
                recordData.forEach(function(Rec){
       
                  
						activeSection.push(Rec.DocumentType__c);
					
                        
                  if(Rec.DocumentStatus__c  == 'Pending')
                        Rec.Name= Rec.DocumentType__c+' (Pending)';
                    else
                        Rec.Name= Rec.DocumentType__c;
                    
                    Rec.Content_Versions__r ? Rec.Content_Versions__r.forEach(function(Rec2){
                        console.log('finals'+Rec2.Title);
                        Rec2.DocumentType=Rec.DocumentType__c;
                        Rec2.DocumentStatus=Rec.DocumentStatus__c;
                    }):''})
            
               
                component.set('v.recoveredDocuments',recordData);
                setTimeout(function(){
                	component.find("accordion").set('v.activeSectionName', activeSection);    
                }, 50);
                
                
if(recordData.length ==0)
    component.set('v.showEmpty',true);
                else
         component.set('v.showEmpty',false);        
                
            }
        });
        $A.enqueueAction(action);        
    },
    


})
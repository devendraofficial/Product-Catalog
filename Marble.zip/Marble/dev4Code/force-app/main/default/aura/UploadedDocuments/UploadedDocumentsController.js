({
    viewUploadModal : function(component, event, helper) {
        component.set('v.viewUploadModal','true');
    },
    viewRequestModal : function(component, event, helper) {
        component.set('v.viewRequestModal','true');
    },
    viewNewModal: function(component, event, helper) {
        component.set('v.viewNewModal','true');
    },
      closeNewModal: function(component, event, helper) {
        
         
      
 component.set('v.viewNewModal','false');

          var appEvent = $A.get("e.c:RefreshDocumentDetailsEvent");
          appEvent.fire();

    },
    
    handleApplicationEvent: function (component,event,helper)
    {
       //componet.set('v.viewRequestModal','false');
       component.set('v.viewNewModal','false'); 
        component.set('v.viewUploadModal','false');
        component.set('v.editModal','false');
          helper.fetchData(component,event,helper);
        var message = event.getParam("message");
        if(message!=null)
        {
            
            
            
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": message+" uploaded successfully!",
                "type": 'success',
            });
            toastEvent.fire();
            
            
        }
    },
    
    
    closeUpdateModal : function(component, event, helper) {  
        
        component.set('v.viewUploadModal','false');
    },
    
    closeRequestModal: function(component, event, helper) {  
        
        component.set('v.viewRequestModal','false');
        helper.fetchData(component,event,helper);
        
           var appEvent = $A.get("e.c:RefreshDocument");
                appEvent.fire();
    },
    closeEditModal: function(component, event, helper) {  
        
        component.set('v.editModal','false');
        helper.fetchData(component,event,helper);
        
      
      
    },
    closeRequest: function(component, event, helper) {  
        
        component.set('v.editModal','false');
    },
    handleSectionToggle: function (component, event) {
        
        
    },
    doInit:function (component, event,helper) {
        
 
        helper.fetchData(component,event,helper);
    },
    
    handleRowAction: function (component, event, helper) {
        
        var action = event.getParam('action');
       
        var row = event.getParam('row');
          component.set('v.row',row);
        switch (action.name) {
            case 'edit':
                
              
                component.set('v.editModal','true');
                break;
                
                 case 'View':
                
 				
                component.set('v.viewModal','true');
                break;
        }
                        
            
    },
    handleChangeUserTypeEvent :function(component,event,helper){
        var message = event.getParam("message");
        
        
        component.set('v.currentUserType',message);
         helper.fetchData(component,event,helper);
    },
   handleValueChange:function(component,event,helper)
    {

     /*            var searchName= component.get('v.searchName');
        if(searchName !='')
        {
             var isEnterKey = event.keyCode === 13;
        if (isEnterKey) {
             helper.fetchData2(component,event,helper);
          
        }
           
          
        }
        else
        {
              component.set('v.showEmpty',false);
            helper.fetchData(component,event,helper); 
        }   
          */     
       
    },
    
     handleValueChange1:function(component,event,helper)
    {

                 var searchName= component.get('v.searchName');
       
             var isEnterKey = event.keyCode === 13;
        if (isEnterKey) {
             if(searchName !='')
        {
             helper.fetchData2(component,event,helper);
        }
            else{
               helper.fetchData(component,event,helper);  
            }
           
          
        }
     
               
       
    },
    
    closeModal:function(component,event,helper)
    {
      
         var actions = [
            { label: 'edit', name: 'edit' }
           
        ]
        
        //  helper.fetchdata(component,event,helper);
        component.set('v.mycolumns', [
            {label: 'ADDED', fieldName: 'CreatedDate', type: 'date'},
            {label: 'FILE NAME', fieldName: 'Name', type: 'text' , editable: true},
            {label: 'TYPE', fieldName: 'DocumentType', type: 'text' },
            {label: 'STATUS', fieldName: 'DocumentStatus', type: 'text' },
           { type: 'action', typeAttributes: { rowActions: actions } }
            
        ]);
        
        
        
        var action = component.get("c.getProDocumentsList");
        var val = component.get("v.recordId");
        console.log('value1'+val);
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType'),searchName :component.get('v.searchName')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                
                component.set('v.recoveredDocuments',response.getReturnValue());
                console.log(component.get('v.recoveredDocuments'));
                var recordData = component.get('v.recoveredDocuments');
                recordData.forEach(function(Rec){
                  if(Rec.DocumentStatus__c == 'PENDING')
    Rec.Name= Rec.DocumentType__c+'(PENDING)';
                else 
                    Rec.Name= Rec.DocumentType__c;
                     Rec.Documents__r ? Rec.Documents__r.forEach(function(Rec2){
                        Rec2.DocumentType=Rec.DocumentType__c;
                        Rec2.DocumentStatus=Rec.DocumentStatus__c;
                    }):''})
                
                console.log(JSON.stringify(recordData));
                component.set('v.recoveredDocuments',recordData);	
                
                
                component.set('v.viewUploadModal','false');
                var val = event.getParam("message");
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                     "title": "Success!",
                    "message": val+" uploaded successfully!",
                    "type": 'success',
                });
                toastEvent.fire();
                
                
               // var appEvent = $A.get("e.c:RefreshDocumentDetailsEvent");
               // appEvent.fire();
                
                
                
            }
        });
        $A.enqueueAction(action);
        
        
        
        
        
    },
   
         handleVerticalMenu:function(component,event,helper)
    {
       var tab = event.getParam("tab");
        
        
        if(tab=="documents")
        {
            
           component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false')

    },
    closePreview:function(component,event,helper)
    {
    component.set('v.viewModal','false');
    },
    handleValueChangeRecoveredDocuments:function(component,event,helper)
    {
        var searchName = component.get('v.searchName');
        if(searchName!='')
        {       
            var activeSection =[];
            var recordData = component.get('v.recoveredDocuments');
            recordData.forEach(function(Rec){ 
                activeSection.push(Rec.DocumentType__c);        
            })
            component.find("accordion").set('v.activeSectionName', activeSection);     
        }    
    },
    handlechangeDocumentListEvent:function(component,event,helper)
    {
        var documentList = event.getParam("documentList");
        console.log('evt'+documentList);
        component.set('v.selectedDocuments',documentList);
       

    },
    onblur:function(component,event,helper)
    {
       // component.set('v.showEmpty',false);
    }
})
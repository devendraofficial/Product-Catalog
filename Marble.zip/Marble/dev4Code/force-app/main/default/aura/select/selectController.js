({
    doInit : function(component, event, helper) {
        
        var idVal=component.get('v.LAId');
        console.log('idVal'+idVal);
        var action = component.get("c.getProDocuments");
        action.setParams({ LoanApplicationId :component.get('v.LAId'),accountType:component.get('v.accountType') });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                
                
                var DocId= component.get('v.currentDocument');
                var newList = [];
                
                response.getReturnValue().forEach(function(record){
                    if(record.DocumentType__c!=DocId)
                    {
                        
                        newList.push(record.DocumentType__c);
                        
                        
                    }
                    
                })
                
                
                component.set('v.newList',newList);
                
                
                
            }
        });
        $A.enqueueAction(action);
        
        var val = component.get('v.newList');
        console.log('newList'+val);
        /*	var DocId= component.get('v.currentDocument');
        var DocumentHeaders=component.get('v.productDocumentTypes');
        var newList = [];
        var i = 1;
        DocumentHeaders.forEach(function(record){
            if(record.Name!=DocId)
            {
                
               newList.push(record.Name);
                
            }
           
        })
      
        component.set('v.newList',newList); */
    },
    handleOnChange:function(component,event,helper)
    {
        var acc=component.get('v.accountType');
        
        var type=component.get('v.type');
        if(type=='main')
        {  var currentLoan = component.get('v.LAId');
         var action = component.get("c.changeDocumentsName");
         action.setParams({ documentHeaderId : event.getSource().get('v.name'),newName : event.getSource().get('v.value'),LAId : currentLoan ,accountType :acc});
         action.setCallback(this, function(response) {
             var state = response.getState();
             if (state === "SUCCESS") {
                 
                 var compEvent = component.getEvent("sampleComponentEvent");
                 
                 compEvent.fire();
                 
             }
         });
         $A.enqueueAction(action);
         
        }
        if(type=='sub')
        {
            var currentLoan = component.get('v.LAId');
            var currentdoc = component.get('v.currentDocumentDetailId');
            var action = component.get("c.changeDocumentName");
            action.setParams({ documentHeaderId : event.getSource().get('v.name'),newName : event.getSource().get('v.value'),docDetailId : currentdoc,LAId : currentLoan ,accountType :component.get('v.accountType')});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    
                    var compEvent = component.getEvent("sampleComponentEvent");
                    
                    compEvent.fire();
                    
                }
            });
            $A.enqueueAction(action);
            
            
        }
    }
})
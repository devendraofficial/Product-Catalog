({
	inlineEditName : function(component, event, helper) {
        
        
        var id =component.get('v.DocumentId');
        component.set("v.nameEditMode", true); 
        setTimeout(function(){ 
            component.find("inputId").focus();
        }, 100);
        
	},

    
      onNameChange : function(component,event,helper){ 
        if(event.getSource().get("v.value").trim() != ''){ 
          
                   
       
        }
    },
       closeNameBox : function (component, event, helper) {

        component.set("v.nameEditMode", false); 
		
          
           
         var action = component.get("c.changeDocName");
        action.setParams({ docId :component.get('v.DocumentId'),NewName : component.get('v.Documentname')});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                   console.log('return'+response.getReturnValue());
                                  //    helper.fetchData(component,event,helper);
                                      $A.get('e.force:refreshView').fire();
                   
                }
            });
            $A.enqueueAction(action);
           
           
           
           
           
                            

        if(event.getSource().get("v.value").trim() == ''){
            component.set("v.showErrorClass",true);
        }else{
            component.set("v.showErrorClass",false);
        }
    }, 
    
})
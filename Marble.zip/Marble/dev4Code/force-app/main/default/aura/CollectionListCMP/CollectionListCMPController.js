({
    doInit : function(component, event, helper) {
        var collections =[];
        var len =0;
        if(component.get("v.collectionlist") != null && component.get("v.collectionlist") != "undefined" ){
            collections =   component.get("v.collectionlist");
            len = collections.length;
            
        }
        if(len == 0){
            collections.push({
                'Contact__c':''
            });
            component.set("v.collectionlist",collections);            
        }
    }
    ,
    additem : function(component, event, helper){
        var collections =[];
        var len =0;
        if(component.get("v.collectionlist") != null && component.get("v.collectionlist") != "undefined" ){
            collections =   component.get("v.collectionlist");
            len = collections.length;
            
        }
        // if(len <= 4){
        collections.push({
            'Contact__c':''
        });
        component.set("v.collectionlist",collections);
        /* }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error",
                "message": "You can add only up to 5 preferred collection date and time.",
                "type": "error",
                 "mode": "sticky"
            });
            toastEvent.fire();  
        }*/
    },
    removeCollection : function(component, event, helper){
        
        var selCollection = event.getParam("itemIndex");
        var collectionlist = component.get("v.collectionlist");
        var toBeDeletecollectionlist = component.get("v.toBeDeletecollectionlist");
           
        if(collectionlist.length > 1){
               toBeDeletecollectionlist.push(collectionlist[selCollection]);
            component.set("v.toBeDeletecollectionlist",toBeDeletecollectionlist);
            collectionlist.splice(selCollection, 1);
        }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error",
                "message": "Minimum one Entry Needed!",
               "type": "error",
               
            });
            toastEvent.fire();
        }
        component.set("v.collectionlist",collectionlist);
    } 
    
})
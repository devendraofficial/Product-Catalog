({
    deleteItem : function(component, event, helper) {
        var event = component.getEvent("deleteCollection");
        event.setParams({
            "itemIndex": component.get('v.itemIndex')
        });
        event.fire();
    },
    
    doInit: function(component, event, helper) {
        if(component.get('v.objectName') =='Address__c'){
            helper.fetchProvincePicklist(component);
        }
    },
    
    setPrimaryPhone : function(component, event, helper) {        
        component.set('v.collectionRec.IsPrimary__c',component.get('v.primaryPhone'));
    },
    
    setTextAllowed : function(component, event, helper) { 
        component.set('v.collectionRec.IsTextAllowed__c',component.get('v.textAllowed'));
    },
    
    setPrimaryEmail : function(component, event, helper) {        
        component.set('v.collectionRec.IsPrimary__c',component.get('v.primaryEmail'));
    },
})
({
	fetchProvincePicklist : function(component){
        var action = component.get("c.getPicklistvalues");
        action.setParams({
            'objectName': component.get("v.objectName"),
            'field_apiname': component.get("v.province"),
            'nullRequired': true // includes --None--
        });
        action.setCallback(this, function(a) {
            var state = a.getState();
            if (state === "SUCCESS"){
                component.set("v.provincePicklist", a.getReturnValue());
            } else if (state === "ERROR") {
                var errors = action.getError();
                if (errors) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors.message,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            } 
        });
        $A.enqueueAction(action);
    }
})
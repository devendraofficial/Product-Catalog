({
    toggle : function(component, event, helper) {
        component.set("v.isOpened", !component.get("v.isOpened"));
    },
    open : function(component, event, helper){
        component.set("v.isOpened", true);
    },
    close : function(component, event, helper){
        component.set("v.isOpened", false);
    }
})
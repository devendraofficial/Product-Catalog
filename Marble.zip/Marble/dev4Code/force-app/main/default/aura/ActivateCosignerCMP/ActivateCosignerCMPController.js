({
    //get Contact List from apex controller
    doInit : function(component, event, helper) {
        var action = component.get("c.getCosigners");
         action.setParams({
            "applicationId": component.get('v.appId')
         });
        action.setCallback(this, function(response){
            var state = response.getState();
          	 if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var cosMap = [];
                for(var key in result){
                    cosMap.push({label: result[key], value: key});
                }
                component.set("v.cosignerMap", cosMap);
            }
        });
        $A.enqueueAction(action);
    },
    
    activateCosigner : function(component, event, helper) {
        if(component.get('v.cos') == undefined){
            var toastEvent = $A.get("e.force:showToast");
                	toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Please Select Atleast One Co-Signer',
                    "type": "error",
                });
                toastEvent.fire();
        }
    }

})
({
    doInit : function(component, event,helper){
        
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + today.getDate()); 
        
        /*var current = component.get("c.getPicklistvalues");
        current.setParams({
            'objectName': 'Address__c',
            'field_apiname': component.get("v.currentaddress"),
            'nullRequired': true // includes --None--
        });
        
        current.setCallback(this, function(c) {
            var state = c.getState();
            if (state === "SUCCESS"){
                component.set("v.currentAddressPicklist", c.getReturnValue());
            } else if (state === "ERROR") {
                var errors = current.getError();
                if (errors) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors.message,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            } 
        });
        
        var mailing = component.get("c.getPicklistvalues");
        mailing.setParams({
            'objectName': 'Address__c',
            'field_apiname': component.get("v.mailingaddress"),
            'nullRequired': true // includes --None--
        });
        
        mailing.setCallback(this, function(m) {
            var state = m.getState();
            if (state === "SUCCESS"){
                component.set("v.mailingAddressPicklist", m.getReturnValue());
            } else if (state === "ERROR") {
                var errors = mailing.getError();
                if (errors) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors.message,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            } 
        });*/
        
        var action = component.get("c.getPicklistvalues");
        action.setParams({
            'objectName': 'Address__c',
            'field_apiname': component.get("v.province"),
            'nullRequired': true // includes --None--
        });
        
        action.setCallback(this, function(a) {
            var state = a.getState();
            if (state === "SUCCESS"){
                component.set("v.provincePicklist", a.getReturnValue());
            } else if (state === "ERROR") {
                var errors = action.getError();
                if (errors) {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": errors.message,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            } 
        });
        $A.enqueueAction(action);
        //$A.enqueueAction(current);
        //$A.enqueueAction(mailing);
        var sAdd = component.get('v.singleAddress');
        
    },
    
    addPreviousAddress : function(component, event,helper){
        var result = new Date();
        result.setMonth(result.getMonth() - 12);
        var previousYear = $A.localizationService.formatDate(result,"YYYY-MM-DD");
        
        var selectedDate = component.get("v.singleAddress.AddressSinceDate__c");
        var cheprimary = component.get('v.singleAddress.IsPrimary__c');
        console.log(selectedDate <= previousYear);
        if (previousYear <= selectedDate && cheprimary != undefined && cheprimary){
            component.set('v.modLabel','Add Previous Address');
            component.set('v.isModOpen',true);
            component.set('v.errorMessage',$A.get("$Label.c.Present_Address_Validation"));            
        }
    },
    CallSaveAddress : function(component, event,helper){
        
        
        var action = component.get("c.insertAddress");
        var singAddress = component.get('v.singleAddress');
        var preAddress = component.get('v.previousAddress');
        var callApex =true;
        
         if(singAddress.StreetAddress__c == '' || singAddress.StreetAddress__c == undefined ||
           singAddress.City__c == '' || singAddress.City__c ==undefined ||
           singAddress.Province__c =='' || singAddress.Province__c == undefined ||
           singAddress.Country__c == '' || singAddress.Country__c == undefined ||
           singAddress.PostalCode__c == '' || singAddress.PostalCode__c == undefined ||
           singAddress.AddressSince__c == null || singAddress.AddressSince__c == '' || singAddress.AddressSince__c == undefined){
            callApex = false;
            
            
        }
        
        if(singAddress != null && singAddress != undefined){
            singAddress.Account__c = component.get('v.accId');
        }
        
        if(preAddress != null && preAddress != undefined){
            preAddress.Account__c = component.get('v.accId');
        }
        
        action.setParams({
            "sAddress": singAddress,
            "pAddress": preAddress
            
        });
        if(callApex){
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var recId = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Added Successfully!',
                    "type": "success",
                });
                toastEvent.fire();
                component.set("v.showAddAddressCMP", false);
                //Get the event using registerEvent name. 
        		var cmpEvent = component.getEvent("RefreshCmpEvent"); 
        		cmpEvent.fire();   
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action); 
        }else{
            var erMsg = 'Please Fill All Required Address Fields(Street,City,Province,Country,Postal Code)';
              var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": erMsg,
                "type": "error",
            });
            toastEvent.fire();
        }
    },
    
    cancel : function(component, event,helper){
        component.set('v.showAddAddressCMP',false);
    }
})
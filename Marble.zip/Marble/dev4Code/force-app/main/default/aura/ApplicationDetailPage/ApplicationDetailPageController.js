({

    init: function(component, event, helper)  {
        var action = component.get("c.getField1s");
         var recordId = component.get('v.recordId');;
        action.setParams({
            recordId: recordId
        });
        action.setCallback(this, function(response) {
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {        
                     component.set('v.wrapperList', response.getReturnValue());
                    console.log('v.wrapperList');
                    console.log(v.wrapperList);
                }
            }
        );
        $A.enqueueAction(action);        
    },
    
})
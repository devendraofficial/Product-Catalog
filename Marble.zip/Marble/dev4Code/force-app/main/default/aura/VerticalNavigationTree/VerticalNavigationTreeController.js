({
    handleSectionToggle: function (component, event) {
        
        var openSections = event.getParam('openSections');
        
        if(openSections.length > 0){
        var cmpOve = component.find('ove');
        $A.util.removeClass(cmpOve, 'slds-is-active');
        
        var cmpDas = component.find('das');
        $A.util.removeClass(cmpDas, 'slds-is-active');
        
        var cmpApplicant = component.find('applicant');
        $A.util.removeClass(cmpApplicant, 'slds-is-active');
        
        var cmpDoc = component.find('doc');
        $A.util.removeClass(cmpDoc, 'slds-is-active');
        
         var cmpLoa = component.find('loa');
        $A.util.removeClass(cmpLoa, 'slds-is-active');
        
         var cmpFud = component.find('fud');
        $A.util.removeClass(cmpFud, 'slds-is-active');
        
         var cmpFdl = component.find('fdl');
        $A.util.removeClass(cmpFdl, 'slds-is-active');
        }
        
        var openSections = event.getParam('openSections');
        component.set('v.bankActive',false);
        component.set('v.creditActive',false);

        if (openSections.length === 0) {
            component.set('v.activeSectionsMessage', "All sections are closed");
        } else {
            component.set('v.activeSectionsMessage', "Open sections: " + openSections.join(', '));
        }
    },
    
    bankStatementInvoker : function (component, event) {
        component.set('v.applicantdefault',false);
        component.set('v.bankActive',true);
        component.set('v.creditActive',false);
        var appEvent = $A.get("e.c:VerticalMenuEvent");
            appEvent.setParams({
                "tab" : 'BankStatement' });
            appEvent.fire();
          
    },
    
    doInit : function (component, event) {
        
       component.set('v.applicantdefault',true);
        
        
    },
    
    
    
     creditStatementInvoker : function (component, event) {
         
            component.set('v.bankActive',false);
        component.set('v.creditActive',true);
         var appEvent = $A.get("e.c:VerticalMenuEvent");
            appEvent.setParams({
                "tab" : 'CreditReport' });
            appEvent.fire();
    },
    
    handleOnSelect : function (component, event) {
        event.preventDefault();
         component.set("v.activeSections",'[]');
        var tab = event.getParam('name');
        console.log(tab);
        if(tab == 'Applicants')
            component.set('v.applicantdefault',true);
        else
           component.set('v.applicantdefault',false);  
        
        var appEvent = $A.get("e.c:VerticalMenuEvent");
        appEvent.setParams({
            "tab" : tab });
        appEvent.fire();
    }
})
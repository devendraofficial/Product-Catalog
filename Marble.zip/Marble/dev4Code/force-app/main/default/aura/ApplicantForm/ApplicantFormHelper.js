({
    fetchWrapperData : function(component, event) {
        
        component.set('v.addressColumns', [
            {label: 'STREET ADDRESS', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'CITY', fieldName: 'City__c', type: 'text'},
            {label: 'COUNTRY', fieldName: 'Country__c', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true},
            {label: 'MOVED IN', fieldName: '', type: 'text'},
            {label: 'MOVED OUT', fieldName: '', type: 'text'}
        ]);
        
        component.set('v.emailColumns', [
           // {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'ADDRESS', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.phoneColumns', [
            {label: 'TYPE', fieldName: 'PhoneType__c', type: 'text'},
            {label: 'NUMBER', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'ACTIVE', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.empColumns', [
            {label: 'COMPANY', fieldName: '', type: 'text'},
            {label: 'JOB TITLE', fieldName: '', type: 'text'},
            {label: 'START DATE', fieldName: '', type: 'text'},
            {label: 'END DATE', fieldName: '', type: 'text'},
            {label: 'FIRST JOB', fieldName: '', type: 'text'}
            //{label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
           // {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            //{label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        
        component.set('v.coaddressColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Street Address', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true}
        ]);
        
        component.set('v.coemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.cophoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.coempColumns', [
            {label: 'Company', fieldName: 'Name', type: 'text'},
            {label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
            {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            {label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        
        component.set('v.cosaddressColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Unit', fieldName: 'Unit__c', type: 'text', editable: true},
            {label: 'Street Address', fieldName: 'StreetAddress__c', type: 'text', editable: true},
            {label: 'Province', fieldName: 'Province__c', type: 'text', editable: true}
        ]);
        
        component.set('v.cosemailColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Email Address', fieldName: 'EmailAddress__c', type: 'email', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c', type: 'boolean', editable: true}
        ]);
        
        component.set('v.cosphoneColumns', [
            {label: 'Name', fieldName: 'Name', type: 'text'},
            {label: 'Phone Number', fieldName: 'PhoneNumber__c', type: 'phone', editable: true},
            {label: 'Is Primary', fieldName: 'IsPrimary__c' , type: 'boolean', editable: true}
        ]);
        
        component.set('v.cosLoanDebtColumns', [
            {label: 'LOAN/DEBT TYPE', fieldName: '', type: 'text'},
            {label: 'GRANTOR', fieldName: '', type: 'text', editable: true},
            {label: 'MONTHLY PAYMENT', fieldName: '' , type: 'text', editable: true},
            {label: 'OUTSTANDING BALANCE', fieldName: '' , type: 'text', editable: true}
        ]);
        
        component.set('v.cosempColumns', [
            {label: 'Company', fieldName: 'Name', type: 'text'},
            {label: 'Employment Length', fieldName: 'EmploymentLength__c', type: 'number',cellAttributes: { alignment: 'left' }, editable: true},
            {label: 'Employment Start Month', fieldName: 'EmploymentStartMonth__c' , type: 'text', editable: true},
            {label: 'Employment Start Year', fieldName: 'EmploymentStartYear__c' , type: 'text', editable: true}
        ]);
        var recId = component.get('v.recordId');
        var action = component.get("c.getApplicationData");
        action.setParams({
            "appId": recId
        });
        action.setCallback(this, function(response){
            console.log("Action Called");
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.applicationWrapper", response.getReturnValue());
                var applicationwrapper = response.getReturnValue();
                console.log("Value of Consent : "+applicationwrapper.ConsentOfBorrowerTest);
                if(applicationwrapper != null ){
                    var applicationRec = applicationwrapper.ApplicationDetail;
                    component.set('v.currentApplicationStatus', applicationRec.ApplicationStatus__c);
                    //   component.set('v.currentLoanAmount',applicationRec.LoanAmount__c);
                    var borrower = applicationwrapper.Borrower;
                    var coborrower = applicationwrapper.CoBorrower;
                    var cosigners = applicationwrapper.CoSigner;
                    var fastappsapp ;
                    var autofastapp;
                    var ftasaList = applicationwrapper.FastTrackAppSpecficApplicant;
                    
                    ftasaList.forEach(function(record){ 
                        if(record.Type__c =='MANUAL' || record.Type__c =='Manual'){
                            component.set('v.ftasa', record)
                            fastappsapp = record;
                            console.log(JSON.stringify(fastappsapp));
                        }else{
                            component.set('v.ftasaAutomatic', record);
                            autofastapp = record;
                            console.log(JSON.stringify(autofastapp));
                        }                               
                    }); 
                    
                    component.set('v.applicationRec',applicationRec);
                    component.set('v.borrower',borrower[0]);
                    component.set('v.coborrower',coborrower[0]);
                    component.set('v.cosigners', cosigners);
                    
                    if(fastappsapp != null && fastappsapp != '' && fastappsapp !='undefined' ){
                        if(autofastapp != null && autofastapp != '' && autofastapp !='undefined' ){
                            if(!fastappsapp.MunualUpdate__c){
                                fastappsapp.InConsumerProposal__c = autofastapp.InConsumerProposal__c;
                                fastappsapp.ConsumerProposalDate__c = autofastapp.ConsumerProposalDate__c;
                            }   
                            if(!fastappsapp.ManualPreApproval__c){
                                fastappsapp.ConsumerLoanAmount__c = autofastapp.ConsumerLoanAmount__c;
                                fastappsapp.PayPerCheque__c = autofastapp.PayPerCheque__c;
                                fastappsapp.MonthsAtCurrentJob__c = autofastapp.MonthsAtCurrentJob__c;
                                fastappsapp.PayFrequency__c = autofastapp.PayFrequency__c;
                                fastappsapp.HasActivePaydayLoans__c = autofastapp.HasActivePaydayLoans__c;
                                fastappsapp.HasMoreThanThreeNSFs__c = autofastapp.HasMoreThanThreeNSFs__c;
                            }
                        }
                        /*MD01 component.set('v.jointproposal',fastappsapp.JointProposal__c);*/
                        /*MD01	component.set('v.consumerproposal',fastappsapp.InConsumerProposal__c);*/
                        component.set('v.ftasa',fastappsapp );
                        console.log(JSON.stringify(component.get('v.ftasa')));
                    }
                    
                    if(borrower != null && borrower != '' && borrower !='undefined' ){
                        component.set('v.addressList', borrower[0].Addresses__r);
                        component.set('v.borrowerconsent',applicationwrapper.ConsentOfBorrower);
                        component.set('v.previousborrowerconsent',applicationwrapper.ConsentOfBorrower);
                        component.set('v.emailList', borrower[0].Emails__r);
                        component.set('v.phoneList', borrower[0].Phones__r);
                        component.set('v.empList', borrower[0].Employments__r);
                    }
                    
                    if(coborrower != null && coborrower != '' && coborrower !='undefined'){  
                        component.set('v.coborrowerconsent',applicationwrapper.ConsentOfCoBorrower);
                        component.set('v.previouscobrwconsent',coborrower[0].Consent__pc);                        
                        component.set('v.coaddressList', coborrower[0].Addresses__r);                    
                        component.set('v.coemailList', coborrower[0].Emails__r);                    
                        component.set('v.cophoneList', coborrower[0].Phones__r);                    
                        component.set('v.coempList', coborrower[0].Employments__r);
                    }
                    
                    if(cosigners != null && cosigners != undefined){
                        var inactivecos =[]
                        var activecos;
                        cosigners.forEach(function(record){ 
                            if(record.IsActive__pc){
                                component.set('v.activecosigner',record);
                                activecos = record
                            }else{
                                inactivecos.push(record);
                            }                               
                        }); 
                        
                        component.set('v.inactivecosigners',inactivecos);
                        console.log('inactive');
                        console.log(JSON.stringify(component.get('v.inactivecosigners')));
                        if(activecos != null && activecos != undefined){
                            component.set('v.cosignerconsent',applicationwrapper.ConsentOfCoSigner);
                            component.set('v.cosaddressList', activecos.Addresses__r);                    
                            component.set('v.cosemailList', activecos.Emails__r);                    
                            component.set('v.cosphoneList', activecos.Phones__r);                    
                            component.set('v.cosempList', activecos.Employments__r);
                        }
                        
                    }
                    
                }
                
            }
        });
        $A.enqueueAction(action);
        
    },
    
    updateRecs : function(component, event, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            coborrowr.Consent__pc = component.get('v.coborrowerconsent');
            objList.push(coborrowr);
            
        }else if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            console.log(JSON.stringify(borrowr));
            var previousconsent = component.get('v.previousborrowerconsent');
            borrowr.Consent__pc = component.get('v.borrowerconsent');
            if(previousconsent != component.get('v.borrowerconsent') ){
                updateApplication =true;
            }
            
            objList.push(borrowr);    
            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            cosignr.Consent__pc = component.get('v.cosignerconsent');
            objList.push(cosignr);        
        }else if(rectype =='appSpecfic'){
            var appsepcRec = component.get('v.ftasa');
            /* MD01 appsepcRec.JointProposal__c = component.get('v.jointproposal');*/
            /** MD01 appsepcRec.InConsumerProposal__c = component.get('v.consumerproposal');*/
            appsepcRec.MunualUpdate__c =true;
            objList.push(appsepcRec);
        }
        console.log(JSON.stringify(appsepcRec));
        var action = component.get("c.updateRecords");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec')
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        //  window.open('/'+ component.get('v.recordId'),'_self');
                        location.reload(true);
                    }), 5000
                );
                
                
                if(accType =='coborrower'){
                    component.set('v.cobviewmode',true);
                    component.set('v.cobappLabel','Edit');
                }
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
                
                if(accType =='cosigner' ){
                    component.set('v.cosviewmode',true);
                    component.set('v.cosappLabel','Edit');
                }
                
                if(accType =='appSpecfic' ){
                    component.set('v.ftasaviewmode',true);
                    component.set('v.ftasaLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    updateBorrowerPreApproval : function(component, event) {
        
        var currentApplication = component.get('v.applicationRec');
        var updateApp = false;
        var objList = [];
        if(component.get('v.currentApplicationStatus') != currentApplication.ApplicationStatus__c 
           /*  || component.get('v.currentLoanAmount') != currentApplication.LoanAmount__c*/){
            updateApp = true;
            
        }
        
        
        var fastTrackApp = component.get('v.ftasa');
        fastTrackApp.ManualPreApproval__c =true;
        objList.push(fastTrackApp);
        
        var action = component.get("c.updateFastTrack");
        action.setParams({
            "sobjList": objList ,
            "application": currentApplication,
            "updateApplication": updateApp
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                
                window.setTimeout(
                    $A.getCallback(function() {
                        component.set("v.loading",false);
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        location.reload(true);
                    }), 5000
                );
                if(accType =='coborrower'){
                    component.set('v.bpaviewmode',true);
                    component.set('v.bpaappLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
        
    },
    
    updateRecsBor : function(component, event, rectype){
        
        var objList = [];
        var accType = rectype;
        var updateApplication =false;
        var consent1 =false;
        if(rectype =='borrower'){
            var borrowr = component.get('v.borrower');
            console.log(JSON.stringify(borrowr));
            var previousconsent = component.get('v.previousborrowerconsent');
            consent1 = component.get('v.borrowerconsent');
            borrowr.Consent__pc = component.get('v.borrowerconsent');
            if(previousconsent != component.get('v.borrowerconsent') ){
                updateApplication =true;
            }
            
            objList.push(borrowr);    
            
        }else if(rectype =='coborrower'){
            var coborrowr = component.get('v.coborrower');
            var previouscobconsent = component.get('v.previouscobrwconsent');
            coborrowr.Consent__pc = component.get('v.coborrowerconsent');
            consent1 = component.get('v.coborrowerconsent');
            if(previouscobconsent != component.get('v.coborrowerconsent') ){
                updateApplication =true;
            }
            objList.push(coborrowr);
            
        }else if(rectype =='cosigner'){
            var cosignr = component.get('v.activecosigner');
            var previouscosconsent = component.get('v.previouscosionsent');
            cosignr.Consent__pc = component.get('v.cosignerconsent');
            consent1 = component.get('v.cosignerconsent');
            if(previouscosconsent != component.get('v.cosignerconsent') ){
                updateApplication =true;
            }
            objList.push(cosignr);        
        }
        
        var action = component.get("c.updateRecordsBor");
        action.setParams({
            "sobjList": objList,
            "toUpateApplication" : updateApplication,
            "appRecord" : component.get('v.applicationRec'),
            "ftapp" : component.get('v.ftasa'),
            "consent": consent1
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set('v.loading',true);
                var recId = response.getReturnValue();                
                window.setTimeout(
                    $A.getCallback(function() {
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Updated Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        component.set("v.loading",false);
                        //  window.open('/'+ component.get('v.recordId'),'_self');
                        location.reload(true);
                    }), 5000
                );
                
                if(accType =='borrower' ){
                    component.set('v.borviewmode',true);
                    component.set('v.borappLabel','Edit');
                }
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
})
({
    handleOnSelect:function(component,event,helper)
    {
        event.preventDefault();
        var tab = event.getParam('name');
        var appEvent = $A.get("e.c:VerticalMenuEvent");
        appEvent.setParams({
            "tab" : tab });
        appEvent.fire();
        component.find("accordion").set('v.activeSectionName', '');
    },
    handleBankStatement:function(component,event,helper){
         event.preventDefault();
        var tab = event.getParam('name');
        var appEvent = $A.get("e.c:VerticalMenuEvent");
        appEvent.setParams({
            "tab" : tab });
        appEvent.fire();
    },
    handleAccordianSelect:function(component,event,helper)
    {
        
        var tab = component.find("accordion").get('v.activeSectionName');
        var activeTabName = '';
        if(tab.length == 1 && tab[0] == 'FinancialHistory'){
            activeTabName = 'FinancialHistory';
            //component.find("accordion").set('v.FinancialHistory', activeTabName);
        }
        if(tab.length > 1){
            for(var i=0;i<tab.length;i++){
                if(tab[i] == 'BankStatement' && helper.previousOpenTab != 'BankStatement'  ){
                    activeTabName = 'BankStatement';
                    helper.previousOpenTab = 'BankStatement';
                    break;
                }else if(tab[i] == 'CreditReport' && helper.previousOpenTab != 'CreditReport'){
                    activeTabName = 'CreditReport';
                    helper.previousOpenTab = 'CreditReport';
                    break;
                }
            }
            
        }
        if(activeTabName != 'FinancialHistory'){
            var appEvent = $A.get("e.c:VerticalMenuEvent");
            appEvent.setParams({
                "tab" : activeTabName });
            appEvent.fire();
        }
    },
});
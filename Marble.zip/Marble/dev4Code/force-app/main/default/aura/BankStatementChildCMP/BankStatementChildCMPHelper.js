({
    helperMethod : function(component, helper) {
        component.set('v.columns', [
            { label: '', fieldName: 'Flags',"cellAttributes" : {"class": {"fieldName": "redFlag"},"iconName": {"fieldName": "redFlagIcon"}},initialWidth: 5},
            { label: 'DATE', fieldName: 'TransactionDate__c', type: 'date', sortable: true},
            { label: 'TRANSACTION', fieldName: 'Description__c', type: 'text',wrapText: true },
            { label: 'CATEGORY', fieldName: 'ParentCategory', type: 'text' ,initialWidth: 150 },
            { label: 'SUB CATEGORY', fieldName: 'SubCategory', type: 'text' },
            { label: 'RECURRING', fieldName: 'IsReccuring__c', type: 'text'},
			{ label: 'CREDIT', fieldName: 'CreditAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClassRed"},"iconName": {"fieldName": "displayIconNameCredit","iconPosition":"right"},alignment: 'left'}},
            { label: 'DEBIT', fieldName: 'DebitAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClass"},"iconName": {"fieldName": "displayIconNameDebit","iconPosition":"right"},alignment: 'left'}},
            { label: 'BALANCE', fieldName: 'ResultingBalance__c', type: 'currency'}
        ]);
        
        var action = component.get("c.fetchBankTransaction");
        var bankAccountID = component.find("Accountselected").get("v.value");
        component.set("v.BankAccountID",bankAccountID);
        var pageSize = component.get("v.pageSize").toString();
        var pageNumber = component.get("v.pageNumber").toString();
        // set the parameters to method   
        action.setParams({
            'RecordID' : bankAccountID
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){        
                var apexReponse = response.getReturnValue();
                component.set("v.bankStatementDetails", apexReponse.bankAccountDetails);
                
                // component.set("v.data", apexReponse.bankTransactionDetails);
                var bankAcocunt = apexReponse.bankAccountDetails;
                console.log("Bank:"+JSON.stringify(bankAcocunt));
                if(bankAcocunt.IsJoinAccount__c){
                    component.find('JointAccount1').set('v.checked',bankAcocunt.IsJoinAccount__c);
                }
                console.log("Bank:j");
                
                /*   for(var i=0;i<apexReponse.bankTransactionDetails.length;i++){
                        
                    }
                    if(bankAcocunt.IsJoinAccount__c){
                        component.find('selectedJointAccount').set('v.value','YES');
                        
                    }else{
                        component.find('selectedJointAccount').set('v.value','NO');
                        // console.log("NO");
                    }*/
                var banktrans  =  apexReponse.bankTransactionDetails;
                //  console.log("Value in 1 ");
                for(var i=0;i<apexReponse.bankTransactionDetails.length;i++){
                    //  console.log("Loop "+banktrans[i].IsReccuring__c);
                   
                      if(banktrans[i].Flags__c != null && banktrans[i].Flags__c != undefined){
                        var flags = banktrans[i].Flags__c;
                            var res = flags.split(";");
                            if(res.length > 0){
                                banktrans[i].redFlag = 'redcolor1';
                                banktrans[i].redFlagIcon ='utility:bookmark';
                                
                            }
                        }
                    	
                          if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.SubCategory__c != undefined){
                             banktrans[i].SubCategory = banktrans[i].BudgetCategory__r.SubCategory__c;
                        }
                    
                        if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.ParentCategory__c != undefined){
                             banktrans[i].ParentCategory = banktrans[i].BudgetCategory__r.ParentCategory__c;
                        }

                    
                    if(banktrans[i].IsReccuring__c == false){
                        banktrans[i].IsReccuring__c = 'N';
                        //  console.log("Value in 3 "+banktrans[i].IsReccuring__c);
                    }
                    else{
                        banktrans[i].IsReccuring__c = 'Y';
                        //  console.log("Value in 2 "+banktrans[i].IsReccuring__c);
                    }
                    
                  if(banktrans[i].IsDebit__c == true){
                            banktrans[i].DebitAmount = banktrans[i].Amount__c;
                            banktrans[i].CreditAmount  ='';
                            banktrans[i].showClass = 'redcolor';
                            banktrans[i].displayIconNameDebit = 'utility:dash';
                        }else {
                            banktrans[i].CreditAmount = banktrans[i].Amount__c;
                            banktrans[i].showClassRed = 'greencolor';
                            banktrans[i].DebitAmount = '';
                            banktrans[i].displayIconNameCredit = 'utility:add';
                        }
                }
                component.set("v.data", banktrans);
                component.set("v.Filterdata", banktrans);
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("Action End");
    },   
    fetchJointAccounts:function(component, helper,isJointChecked,bankAccId){
        var action = component.get("c.fetchJointAccount");
        action.setParams({
            'RecordID' : bankAccId,
            'JointAccount':isJointChecked
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){
                var apexReponse = response.getReturnValue();
                if(apexReponse.JointAccount){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success!', //add this for SF 178
                        message: 'You have confirmed this is a joint account!',
                        duration:' 1000',
                        key: 'info_alt',
                        type: 'success',
                       // mode: 'sticky' commented this for SF 178
                    });
                    toastEvent.fire(); 
                }
                else if(isJointChecked == false){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Warning!', //add this for SF 178
                        message: 'This is no longer a joint account!',
                        duration:' 1000',
                        key: 'info_alt',
                        type: 'warning',
                       // mode: 'sticky' commented this for SF 178
                    });
                    toastEvent.fire();
                }
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("Action End");
    },
    getData : function(component,helper){
        var bankAccountID = component.find("Accountselected").get("v.value");
        component.set("v.BankAccountID",bankAccountID);
        component.set('v.columns', [
            { label: '', fieldName: 'Flags',"cellAttributes" : {"class": {"fieldName": "redFlag"},"iconName": {"fieldName": "redFlagIcon"}},initialWidth: 5},
            { label: 'DATE', fieldName: 'TransactionDate__c', type: 'date-local', sortable: true},
            { label: 'TRANSACTION', fieldName: 'Description__c', type: 'text' , sortable: true,wrapText: true},
            { label: 'CATEGORY', fieldName: 'ParentCategory', type: 'text' , sortable: true,initialWidth: 150 },
            { label: 'SUB CATEGORY', fieldName: 'SubCategory', type: 'text' , sortable: true},
            { label: 'RECURRING', fieldName: 'IsReccuring', type: 'text', sortable: true},
            { label: 'CREDIT', fieldName: 'CreditAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClassRed"},"iconName": {"fieldName": "displayIconNameCredit","iconPosition":"right"},alignment: 'left'}},
            { label: 'DEBIT', fieldName: 'DebitAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClass"},"iconName": {"fieldName": "displayIconNameDebit","iconPosition":"right"},alignment: 'left'}},
            { label: 'BALANCE', fieldName: 'ResultingBalance__c', type: 'currency', sortable: true}
        ]);
        
        // call apex class method
        var action = component.get("c.fetchReccuringTransaction");
        action.setParams({
            "RecordID":component.get("v.BankAccountID"),
            "initialRows" : component.get("v.initialRows"), //how many rows to load during initialization
            "appId" : component.get('v.recordId'),
            "applicantType" :component.get('v.appType')
        });
        action.setCallback(this,function(response){
            var state = response.getState();
            //var toastReference = $A.get("e.force:showToast");
            if(state == "SUCCESS"){
                var accountWrapper = response.getReturnValue();
                console.log(JSON.stringify(accountWrapper.bankAccountDetails));
                if(accountWrapper.success){
                    // set total rows count from response wrapper
                    component.set("v.totalRows",accountWrapper.totalRecords);
                    component.set('v.allVal', accountWrapper.sumval);
                    if(accountWrapper.bankAccountDetails != undefined){
                        component.set("v.bankStatementDetails", accountWrapper.bankAccountDetails);
                         var bankAcocunt = accountWrapper.bankAccountDetails;
                        component.find('JointAccount1').set('v.checked',bankAcocunt.IsJoinAccount__c);
                    }else{
                        component.set('v.bankStatementDetails',null);
                        component.find('JointAccount1').set('v.checked',false);
                    }
                    
                    var banktrans  =  accountWrapper.bankTransactionDetails;
                    
                    if(banktrans != null)
                        component.set('v.showSum',true);
                    else
                         component.set('v.showSum',false);
                    
                    for(var i=0;i<accountWrapper.bankTransactionDetails.length;i++){
                        
                        if(banktrans[i].Flags__c != null && banktrans[i].Flags__c != undefined){
                        var flags = banktrans[i].Flags__c;
                            var res = flags.split(";");
                            if(res.length > 0){
                                banktrans[i].redFlag = 'redcolor1';
                                banktrans[i].redFlagIcon ='utility:bookmark';
                                
                            }
                        }
                        
                        if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.SubCategory__c != undefined){
                             banktrans[i].SubCategory = banktrans[i].BudgetCategory__r.SubCategory__c;
                        }
                        
                        if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.ParentCategory__c != undefined){
                             banktrans[i].ParentCategory = banktrans[i].BudgetCategory__r.ParentCategory__c;
                        }
                        
                   if(banktrans[i].IsReccuring__c == false){
                            banktrans[i].IsReccuring = 'N';
                            //  console.log("Value in 3 "+banktrans[i].IsReccuring__c);
                        }
                        else{
                            banktrans[i].IsReccuring = 'Y';
                            //  console.log("Value in 2 "+banktrans[i].IsReccuring__c);
                        }
                        
                        if(banktrans[i].IsDebit__c == true){
                            banktrans[i].DebitAmount = banktrans[i].Amount__c;
                            banktrans[i].CreditAmount  ='';
                            banktrans[i].showClass = 'redcolor';
                            banktrans[i].displayIconNameDebit = 'utility:dash';
                        }else {
                            banktrans[i].CreditAmount = banktrans[i].Amount__c;
                            banktrans[i].showClassRed = 'greencolor';
                            banktrans[i].DebitAmount = '';
                            banktrans[i].displayIconNameCredit = 'utility:add';
                        }
                    }
                    
                    component.set("v.data", banktrans);
                    this.sorttData(component,'TransactionDate__c','desc');
                   
                    
                    component.set("v.Filterdata",banktrans);
                    console.log("currentCount : "+component.get("v.currentCount"));
                    console.log("totalRows : "+component.get("v.totalRows"));
                    var accountList = accountWrapper.bankTransactionDetails;
                    // play a for each loop on list of account and set Account URL in custom 'accountName' field
                    /*   accountList.forEach(function(account){
                        account.accountName = '/'+account.Id;
                    });*/
                    // set the updated response on accountData aura attribute  
                    //component.set("v.data",accountList);
                    // display a success message  
                    toastReference.setParams({
                        "type" : "Success",
                        "title" : "Success",
                        "message" : accountWrapper.message,
                        "mode" : "dismissible"
                    });
                    toastReference.fire();
                }
                else{ // if any server side error, display error msg from response
                    toastReference.setParams({
                        "type" : "Error",
                        "title" : "Error",
                        "message" : accountWrapper.message,
                        "mode" : "sticky"
                    }); 
                    toastReference.fire();
                }
            }
            else{ // if any callback error, display error msg
                toastReference.setParams({
                    "type" : "Error",
                    "title" : "Error",
                    "message" : 'An error occurred during Initialization '+state,
                    "mode" : "sticky"
                });
                toastReference.fire();
            }
        });
        $A.enqueueAction(action);
    },
    loadData : function(component,helper){
        return new Promise($A.getCallback(function(resolve){
            var limit = component.get("v.initialRows");
            console.log("limit : "+limit);
            var offset = component.get("v.currentCount");
            console.log("offset : "+offset);
            var totalRows = component.get("v.totalRows");
            console.log("totalRows : "+totalRows);
            if(limit + offset > totalRows){
                limit = totalRows - offset;
            }
            var filterdate = component.get("v.filterDate");
            console.log("filterdate : "+filterdate);
            console.log("filterCustomStartDate : "+component.get("v.filterCustomStartDate"));
            var flagslist = component.get("v.filterFlag");
            console.log("flagslist : "+flagslist);
            console.log("filterCustomEndDate : "+component.get("v.filterCustomEndDate"));
            //filterCustomStartDate,filterCustomEndDate
            var action = component.get("c.loadTransactionRecords");
            action.setParams({
                "rowLimit" :  limit,
                "rowOffset" : offset,
                "RecordID":component.get("v.BankAccountID"),
                "customStartDate" :component.get("v.filterCustomStartDate"),
                "customEndDate" :component.get("v.filterCustomEndDate"),
                "filterDate" :filterdate,
                "flagsList" :flagslist
            });
            action.setCallback(this,function(response){
                var state = response.getState();
                var newData = response.getReturnValue();
               
                var banktrans  =  newData.bankTransactionDetails;
                
                  if(banktrans != null)
                        component.set('v.showSum',true);
                    else
                         component.set('v.showSum',false);
				
                for(var i=0;i<banktrans.length;i++){
                    //  console.log("Loop "+banktrans[i].IsReccuring__c);
                    
                     if(banktrans[i].Flags__c != null && banktrans[i].Flags__c != undefined){
                        var flags = banktrans[i].Flags__c;
                            var res = flags.split(";");
                            if(res.length > 0){
                                banktrans[i].redFlag = 'redcolor1';
                                banktrans[i].redFlagIcon ='utility:bookmark';
                                
                            }
                        }
                    
                      if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.SubCategory__c != undefined){
                             banktrans[i].SubCategory = banktrans[i].BudgetCategory__r.SubCategory__c;
                        }
                        
                        if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.ParentCategory__c != undefined){
                             banktrans[i].ParentCategory = banktrans[i].BudgetCategory__r.ParentCategory__c;
                        }

                    if(banktrans[i].IsReccuring__c == false){
                        banktrans[i].IsReccuring = 'N';
                        //  console.log("Value in 3 "+banktrans[i].IsReccuring__c);
                    }
                    else{
                        banktrans[i].IsReccuring = 'Y';
                        //  console.log("Value in 2 "+banktrans[i].IsReccuring__c);
                    }
                    
                    if(banktrans[i].IsDebit__c == true){
                        banktrans[i].DebitAmount = banktrans[i].Amount__c;
                        banktrans[i].CreditAmount  ='';
                        banktrans[i].showClass = 'redcolor';
                        banktrans[i].displayIconNameDebit = 'utility:dash';
                    }else {
                        banktrans[i].CreditAmount = banktrans[i].Amount__c;
                        banktrans[i].DebitAmount = '';
                        banktrans[i].showClassRed = 'greencolor';
                        banktrans[i].displayIconNameCredit = 'utility:add';
                        
                    }
                }
                // component.set("v.data", banktrans);
                component.set("v.Filterdata",banktrans);
                resolve(banktrans);
                var currentCount = component.get("v.currentCount");
                currentCount += component.get("v.initialRows");
                // set the current count with number of records loaded 
                component.set("v.totalRows",newData.totalRecords); 
                console.log('CurrentCount in Loadmorehelper'+currentCount);
                component.set("v.currentCount",currentCount);
                console.log('totalRows'+newData.totalRecords);
            });
            $A.enqueueAction(action);
        }));
    },
    FilterTransactionsHelper : function(component, helper) {
        component.set('v.columns', [
            { label: '', fieldName: 'Flags',"cellAttributes" : {"class": {"fieldName": "redFlag"},"iconName": {"fieldName": "redFlagIcon"}}, initialWidth: 5},
            { label: 'DATE', fieldName: 'TransactionDate__c', type: 'date-local',sortable: true },
            { label: 'TRANSACTION', fieldName: 'Description__c', type: 'text',wrapText: true },
            { label: 'CATEGORY', fieldName: 'ParentCategory', type: 'text',initialWidth: 150 },
            { label: 'SUB CATEGORY', fieldName: 'SubCategory', type: 'text' },
            { label: 'RECURRING', fieldName: 'IsReccuring__c', type: 'text'},
			{ label: 'CREDIT', fieldName: 'CreditAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClassRed"},"iconName": {"fieldName": "displayIconNameCredit","iconPosition":"right"},alignment: 'left'}},
            { label: 'DEBIT', fieldName: 'DebitAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClass"},"iconName": {"fieldName": "displayIconNameDebit","iconPosition":"right"},alignment: 'left'}},
            { label: 'BALANCE', fieldName: 'ResultingBalance__c', type: 'currency'}
        ]);
       
        var action = component.get("c.FilterRecords");
        var bankAccountID = component.get("v.BankAccountID");
        var filterdate = component.get("v.filterDate");
        console.log("filterCustomStartDate : "+component.get("v.filterCustomStartDate"));
        var flagslist = component.get("v.filterFlag");
        console.log("filterCustomEndDate : "+component.get("v.filterCustomEndDate"));
        // set the parameters to method  
        action.setParams({
            'recordID' : bankAccountID,
            'customStartDate' : component.get("v.filterCustomStartDate"),
            'customEndDate' : component.get("v.filterCustomEndDate"),
            'filterDate': filterdate,
            'flagsList':flagslist,
            'appId': component.get('v.recordId'),
            'applicationType' : component.get('v.appType')
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){        
                var apexReponse = response.getReturnValue();
                
                
                var banktrans  =  apexReponse;
                
                  if(banktrans != null)
                        component.set('v.showSum',true);
                    else
                         component.set('v.showSum',false);
                
                if(banktrans != null){
                for(var i=0;i<apexReponse.length;i++){
                    //  console.log("Loop "+banktrans[i].IsReccuring__c);
                  
                            if(banktrans[i].Flags__c != null && banktrans[i].Flags__c != undefined){
                        var flags = banktrans[i].Flags__c;
                            var res = flags.split(";");
                            if(res.length > 0){
                                banktrans[i].redFlag = 'redcolor1';
                                banktrans[i].redFlagIcon ='utility:bookmark';
                                
                            }
                        }
                    
                    if(banktrans[i].IsReccuring__c == false){
                        banktrans[i].IsReccuring__c = 'N';
                        //  console.log("Value in 3 "+banktrans[i].IsReccuring__c);
                    }
                    else{
                        banktrans[i].IsReccuring__c = 'Y';
                        //  console.log("Value in 2 "+banktrans[i].IsReccuring__c);
                    }
                    
                     if(banktrans[i].IsDebit__c == true){
                            banktrans[i].DebitAmount = banktrans[i].Amount__c;
                            banktrans[i].CreditAmount  ='';
                            banktrans[i].showClass = 'redcolor';
                            banktrans[i].displayIconNameDebit = 'utility:dash';
                        }else {
                            banktrans[i].CreditAmount = banktrans[i].Amount__c;
                            banktrans[i].showClassRed = 'greencolor';
                            banktrans[i].DebitAmount = '';
                            banktrans[i].displayIconNameCredit = 'utility:add';
                        }
                }
                }else{
                    banktrans = null;
                      var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'No records found!',
                            "type": "error",
                        });
                        toastEvent.fire();
                    
                    
                    
                }
                component.set("v.data", banktrans);
              //  this.sorttData(component,'TransactionDate__c','desc');
                component.set("v.Filterdata",banktrans);
                this.sorttData(component,'TransactionDate__c','desc');
                var empty = [];
             //   component.set("v.filterFlag", empty);
              //  console.log("Flag is clear ");
                component.set("v.enableInfiniteLoading",false);
                event.getSource().set("v.isLoading", false);
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("Action End");
    },
    SearchHelper : function(component, helper) {
        component.set('v.columns', [
            { label: '', fieldName: 'Flags',"cellAttributes" : {"class": {"fieldName": "redFlag"},"iconName": {"fieldName": "redFlagIcon"}},initialWidth: 5},
            { label: 'DATE', fieldName: 'TransactionDate__c', type: 'date',sortable: true },
            { label: 'TRANSACTION', fieldName: 'Description__c', type: 'text',wrapText: true },
            { label: 'CATEGORY', fieldName: 'ParentCategory', type: 'text' ,initialWidth: 150},
            { label: 'SUB CATEGORY', fieldName: 'SubCategory', type: 'text' },
            { label: 'RECURRING', fieldName: 'IsReccuring__c', type: 'text'},
            { label: 'CREDIT', fieldName: 'CreditAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClassRed"},"iconName": {"fieldName": "displayIconNameCredit","iconPosition":"right"},alignment: 'left'}},
            { label: 'DEBIT', fieldName: 'DebitAmount', type: 'currency' , sortable: true,"cellAttributes" : {"class": {"fieldName": "showClass"},"iconName": {"fieldName": "displayIconNameDebit","iconPosition":"right"},alignment: 'left'}},
            { label: 'BALANCE', fieldName: 'ResultingBalance__c', type: 'currency'}
        ]);
        var action = component.get("c.SearchRecords");
        var bankAccountID = component.get("v.BankAccountID");
        action.setParams({
            "recordID" : bankAccountID,
            "initialRows" : component.get("v.initialRows"),
            "searchKeyWord":component.get("v.searchKeyWord")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){        
                var apexReponse = response.getReturnValue();
                console.log("Value : "+apexReponse.bankTransactionDetails.length);
                component.set("v.data", apexReponse.bankTransactionDetails);
                var  banktrans =  apexReponse.bankTransactionDetails;
                  if(banktrans != null)
                        component.set('v.showSum',true);
                    else
                         component.set('v.showSum',false);
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("Action End");
    },
    searchloadData : function(component,helper){
        return new Promise($A.getCallback(function(resolve){
            var limit = component.get("v.initialRows");
            var offset = component.get("v.currentCount");
            var totalRows = component.get("v.totalRows");
            if(limit + offset > totalRows){
                limit = totalRows - offset;
            }
            var action = component.get("c.loadSearchTransactionRecords");
            action.setParams({
                "rowLimit" :  limit,
                "rowOffset" : offset,
                "RecordID":component.get("v.BankAccountID"),
                "searchKeyWord": component.get("v.searchKeyWord")
            });
            action.setCallback(this,function(response){
                var state = response.getState();
                var newData = response.getReturnValue();
                var banktrans  =  newData.bankTransactionDetails;
                 if(banktrans != null)
                        component.set('v.showSum',true);
                    else
                         component.set('v.showSum',false);
                 
                for(var i=0;i<banktrans.length;i++){
                    if(banktrans[i].IsReccuring__c == false){
                        banktrans[i].IsReccuring__c = 'N';
                    }
                    else{
                        banktrans[i].IsReccuring__c = 'Y';
                    }
                    
                     if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.SubCategory__c != undefined){
                             banktrans[i].SubCategory = banktrans[i].BudgetCategory__r.SubCategory__c;
                        }
                        
                        if(banktrans[i].BudgetCategory__c != null && banktrans[i].BudgetCategory__r.ParentCategory__c != undefined){
                             banktrans[i].ParentCategory = banktrans[i].BudgetCategory__r.ParentCategory__c;
                        }


                   
                       if(banktrans[i].IsDebit__c == true){
                            banktrans[i].DebitAmount = banktrans[i].Amount__c;
                            banktrans[i].CreditAmount  ='';
                            banktrans[i].showClass = 'redcolor';
                            banktrans[i].displayIconNameDebit = 'utility:dash';
                        }else {
                            banktrans[i].CreditAmount = banktrans[i].Amount__c;
                            banktrans[i].showClassRed = 'greencolor';
                            banktrans[i].DebitAmount = '';
                            banktrans[i].displayIconNameCredit = 'utility:add';
                        }
                    
                }
                resolve(banktrans);
                var currentCount = component.get("v.currentCount");
                currentCount += component.get("v.initialRows");
                component.set("v.totalRows",newData.totalRecords); 
                console.log('CurrentCount in Loadmorehelper'+currentCount);
                component.set("v.currentCount",currentCount);
                console.log('totalRows'+newData.totalRecords);
            });
            $A.enqueueAction(action);
        }));
    },
    handleSort: function(cmp, event) {
        var sortedBy = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');

        var cloneData = this.DATA.slice(0);
        cloneData.sort((this.sortBy(sortedBy, sortDirection === 'asc' ? 1 : -1)));
        
        cmp.set('v.data', cloneData);
        cmp.set('v.sortDirection', sortDirection);
        cmp.set('v.sortedBy', sortedBy);
    },
    sorttData: function (component, fieldName, sortDirection) {
        var data = component.get("v.data");
        var reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse));
        component.set("v.data", data);
    },
    sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    }
    })
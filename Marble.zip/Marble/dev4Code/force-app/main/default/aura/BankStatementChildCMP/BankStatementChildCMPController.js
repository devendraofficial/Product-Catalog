({
    doInit: function(component, event, helper) {
        
        
        var action = component.get("c.getBankAccounts");
        var recordId;
        if(component.get("v.pageReference") != null){
            component.set('v.recordId', component.get("v.pageReference").state.c__id);
            recordId = component.get("v.pageReference").state.c__id;
            component.set('v.isVisible',true);
        }else{
            recordId = component.get('v.recordId');
        }   
        
        
        action.setParams({
            "recId": recordId,
            "applicantType" : component.get('v.appType')
            
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS"){        
                var apexReponse = response.getReturnValue();
                if(component.get('v.appType') =='BORROWER') {
                    var bankArray = apexReponse.borrowerBankDetails;
                    if(apexReponse.borrowerBankDetails != null && apexReponse.borrowerBankDetails.length > 0){
                        console.log(JSON.stringify(apexReponse.borrowerBankDetails));
                        
                        var All ={};
                        All.Id = 'All';
                        All.Name ='Accounts';
                        All.AccountType__c = 'All';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray);
                    }else{
                        var All ={};
                        All.Id = '';
                        All.Name ='';
                        All.AccountType__c = '';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray);
                        //  component.set("v.BankAccount", apexReponse.borrowerBankDetails);
                    }
                    console.log('apexReponse.borrowerHasBankSessionCompleted');
                    console.log(apexReponse.borrowerHasBankSessionCompleted);
                    
                    
                    component.set("v.isBankAccountNull", apexReponse.borrowerHasBankSessionCompleted);
                    
                    component.set("v.IsDocumentTypeReceived", apexReponse.borrowerIsDocumentTypeReceived);
                    
                    if(apexReponse.borrowerBankDetails != null && apexReponse.borrowerBankDetails.length > 0){
                        component.find("Accountselected").set("v.value", 'All');
                        $A.enqueueAction(component.get('c.fetchBankAccounts'));
                    } 
                    
                }
                
                else if(component.get('v.appType') =='COBORROWER'){                   
                    var bankArray = apexReponse.coborrowerBankDetails;
                    if(apexReponse.coborrowerBankDetails != null && apexReponse.coborrowerBankDetails.length > 0){
                        var All ={};
                        All.Id = 'All';
                        All.Name ='Accounts';
                        All.AccountType__c = 'All';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray);
                    }
                    else{
                        var All ={};
                        All.Id = '';
                        All.Name ='';
                        All.AccountType__c = '';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray);
                    }
                    
                    component.set("v.isBankAccountNull", apexReponse.coborrowerHasBankSessionCompleted);
                    component.set("v.IsDocumentTypeReceived", apexReponse.coborrowerIsDocumentTypeReceived);
                    
                    if(apexReponse.coborrowerBankDetails != null && apexReponse.coborrowerBankDetails.length > 0){
                        component.find("Accountselected").set("v.value", 'All');
                        $A.enqueueAction(component.get('c.fetchBankAccounts'));
                    } 
                    
                }else if(component.get('v.appType') =='COSIGNER'){
                    var bankArray = apexReponse.cosignerBankDetails;
                    if(apexReponse.cosignerBankDetails != null && apexReponse.cosignerBankDetails.length > 0){
                        var All ={};
                        All.Id = 'All';
                        All.Name ='Accounts';
                        All.AccountType__c = 'All';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray);
                    }else{
                        var All ={};
                        All.Id = '';
                        All.Name ='';
                        All.AccountType__c = '';
                        bankArray.push(All);
                        bankArray.reverse();
                        component.set('v.BankAccount', bankArray)
                    }
                    component.set("v.isBankAccountNull", apexReponse.cosignerHasBankSessionCompleted);
                    console.log('isBankAccountNull :'+component.get("v.isBankAccountNull"));
                    
                    component.set("v.IsDocumentTypeReceived", apexReponse.cosignerIsDocumentTypeReceived);
                    console.log('IsDocumentTypeReceived :'+component.get("v.IsDocumentTypeReceived"));
                    
                    
                    if(apexReponse.cosignerBankDetails != null && apexReponse.cosignerBankDetails.length > 0){
                        component.find("Accountselected").set("v.value", 'All');
                        $A.enqueueAction(component.get('c.fetchBankAccounts'));
                    } 
                    
                }  
            }
        }
                          );
        $A.enqueueAction(action);    
        console.log("BankAccount Controller Start End");
    },
    handleDocuments:function(component,event,helper){
        event.preventDefault();
       console.log('function called');
        var tab = 'documents';
        var appEvent = $A.get("e.c:VerticalMenuEvent");
        appEvent.setParams({
            "tab" : tab });
        appEvent.fire();
    },
   
    fetchBankAccounts:function(component,event,helper){
        
 
        
        var customstartdate = '1970-01-01';
        console.log("customstartdate : "+customstartdate);
        var customenddate = '2020-05-01';
        console.log("customenddate : "+customenddate);
        component.set("v.filterCustomStartDate",customstartdate);
        component.set("v.filterCustomEndDate",customenddate);
        component.set("v.enableInfiniteLoading",true);
        component.set("v.currentCount",0);
        if(component.find("Accountselected").get("v.value") ==''){
            component.set("v.data",null);
            component.set("v.bankStatementDetails",null);
        }
        else{
            helper.getData(component, helper);
        }
         var checkJointAccount = component.find('Accountselected').get('v.value');
        console.log('Selected :'+checkJointAccount);
        if(checkJointAccount == 'All'){
            component.set("v.disableJointAccount",true);
        }
        else{
            component.set("v.disableJointAccount",false);
        }
        
    },
    
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isOpen", false);
    },
    
    Emails : function(component, event, helper) { 
        
    },
    
    JointAccount : function(component, event, helper) {        
        var isJointChecked = component.find('JointAccount1').get('v.checked');
        var bankAccId = component.get("v.BankAccountID");
        helper.fetchJointAccounts(component, helper,isJointChecked,bankAccId);
    },
    
    handleLoadMore :function(component, event, helper){
        console.log("handleLoadMore Action");
        console.log("currentCount : "+component.get("v.currentCount"));
        console.log("totalRows : "+component.get("v.totalRows"));
        if(!(component.get("v.currentCount") >= component.get("v.totalRows"))){
            //To display the spinner
            event.getSource().set("v.isLoading", true); 
            //To handle data returned from Promise function
            helper.loadData(component).then(function(data){ 
                var currentData = component.get("v.data");
                var newData = currentData.concat(data);
                
                
                
                component.set("v.data", newData);
                //To hide the spinner
                event.getSource().set("v.isLoading", false); 
            });
        }
        else{
            //To stop loading more rows
            component.set("v.enableInfiniteLoading",false);
            console.log("enableInfiniteLoading : "+component.get("v.enableInfiniteLoading"));
            event.getSource().set("v.isLoading", false);
            
        }
        
    },
    
    handleRowAction  : function(component, event, helper) {        
        alert('Row is selected');
    }, 
    updateSelectedText : function(component, event, helper) {
        var  sum = 0;      
        var selectedRows = event.getParam('selectedRows');
        console.log(selectedRows);
        component.set("v.selectedRowsCount" ,selectedRows.length );
        let obj =[] ; 
        for (var i = 0; i < selectedRows.length; i++){
            sum = sum  + Math.round(selectedRows[i].CreditAmount) - Math.round(selectedRows[i].DebitAmount)
            console.log(sum);
        }
        console.log(Object.values(selectedRows));
        if(selectedRows.length <= 0){
            component.set("v.Sum" ,0);
        }
        else{
            component.set("v.Sum" ,sum);
        }
    }, 
    
    filterThisMonth  : function(component, event, helper) {
        
        var cmpTarget = component.find('thisMonthStyle');	
        component.set("v.filterDate",'THIS_MONTH');
    }, 
    filterLatest3Months  : function(component, event, helper) {        
        component.set("v.filterDate",'Last_N_Months:3');
    },
    filterThisYear  : function(component, event, helper) {        
        component.set("v.filterDate",'THIS_YEAR');
    },
    filterLastYear  : function(component, event, helper) {        
        component.set("v.filterDate",'LAST_YEAR');
    },
    filterAllDates  : function(component, event, helper) {        
        component.set("v.filterDate",'All');
    },
    Update: function(component, event, helper) {
        component.set("v.isOpen", false);
        // component.set("v.filterCustomStartDate");
        var customstartdate = component.find("customStartDate").get("v.value");
        
        if(customstartdate != ''){
            console.log("In if");
            component.set("v.filterCustomStartDate",customstartdate);
        }
        else{
            
            component.set("v.filterCustomStartDate",null);
        }
        //filterCustomStartDate,filterCustomEndDate
        console.log('customstartdate : '+customstartdate);
        
        var customenddate = component.find("customEndDate").get("v.value");
        if(customenddate != ''){
            
            console.log("In if2");
            component.set("v.filterCustomEndDate",customenddate);
        }
        else{
            component.set("v.filterCustomEndDate",null);
        }
        console.log('customenddate : '+customenddate);
        
        var filterdate = component.get("v.filterDate");
        var flaglist = component.get("v.filterFlag");
        
        if((component.get("v.filterCustomStartDate") == null && component.get("v.filterCustomEndDate") != null) ||
           (component.get("v.filterCustomStartDate") != null && component.get("v.filterCustomEndDate") == null)){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": "From Date & To Date both needed togeather",
                "type" :"error"
            });
            toastEvent.fire();
            component.set("v.isOpen", true);
        }else{
            helper.FilterTransactionsHelper(component, helper);
        }
        
    },
    AutoLoan  : function(component, event, helper) {   
        var filterautoLoan = component.find("autoLoan").get("v.checked");
        console.log('AutoLoan : '+filterautoLoan);
        var flaglist = component.get("v.filterFlag");
        if(!flaglist.includes("AUTO_LOAN")){
            flaglist.push("AUTO_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'AUTO_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist); 
    },
    
    Collection  : function(component, event, helper) {        
        var filtercollection = component.find("collection").get("v.checked");  
        console.log('Collection : '+filtercollection);
        var flaglist = component.get("v.filterFlag");
        if(filtercollection){
            flaglist.push("COLLECTION");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'COLLECTION') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },    
    
    CreditRebuilding  : function(component, event, helper) {        
        var filtercreditRebuilding =component.find("creditRebuilding").get("v.checked");  
        console.log('CreditRebuilding : '+filtercreditRebuilding);
        var flaglist = component.get("v.filterFlag");
        if(filtercreditRebuilding){
            flaglist.push("CREDIT_REBUILDING_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'CREDIT_REBUILDING_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    DebtManagement  : function(component, event, helper) {        
        var filterdebtManagement = component.find("debtManagement").get("v.checked");  
        console.log('DebtManagement : '+filterdebtManagement);
        var flaglist = component.get("v.filterFlag");
        if(filterdebtManagement){
            flaglist.push("DEBT_MANAGEMENT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'DEBT_MANAGEMENT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    HighCostLoan  : function(component, event, helper) {        
        var filterhighCostLoan = component.find("highCostLoan").get("v.checked");
        console.log('HighCostLoan : '+filterhighCostLoan);
        var flaglist = component.get("v.filterFlag");
        if(filterhighCostLoan){
            flaglist.push("HIGH_COST_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'HIGH_COST_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    NSF  : function(component, event, helper) {        
        var filterNSF = component.find("NSF").get("v.checked");
        console.log('NSF : '+filterNSF);
        var flaglist = component.get("v.filterFlag");
        if(filterNSF){
            flaglist.push("NSF");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'NSF') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    Overdraft  : function(component, event, helper) {        
        var filteroverdraft = component.find("overdraft").get("v.checked");  
        console.log('Overdraft : '+filteroverdraft);
        var flaglist = component.get("v.filterFlag");
        if(filteroverdraft){
            flaglist.push("OVERDRAFT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'OVERDRAFT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    PaydayLoan  : function(component, event, helper) {        
        var filterpaydayLoan = component.find("paydayLoan").get("v.checked");
        console.log('PaydayLoan : '+filterpaydayLoan);
        var flaglist = component.get("v.filterFlag");
        if(filterpaydayLoan){
            flaglist.push("PAYDAY_LOAN");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'PAYDAY_LOAN') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    TrusteePayment  : function(component, event, helper) {        
        var filtertrusteePayment = component.find("trusteePayment").get("v.checked");
        console.log('TrusteePayment : '+filtertrusteePayment);
        var flaglist = component.get("v.filterFlag");
        if(filtertrusteePayment){
            flaglist.push("TRUSTEE_PAYMENT");
        }else{
            for(var i = flaglist.length - 1; i >= 0; i--) {
                if(flaglist[i] === 'TRUSTEE_PAYMENT') {
                    flaglist.splice(i, 1);
                }
            }
        }
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist);
    },
    
    handleSort: function(component, event, helper) {
        helper.handleSort(component, event);
    },
    
    searchBankTransaction: function (component, event, helper) {
       
        var isEnterKey = event.keyCode === 13;
        if (isEnterKey) {
            
        var data = component.get("v.Filterdata"),
            term = component.get("{!v.searchKeyWord}"),
            results = data, regex;
        
        if(term !=''){
            regex = new RegExp(term, "i");
            // filter checks each row, constructs new array where function returns true
            results = data.filter(row => regex.test(row.Description__c)  || 
                                  regex.test(row.CreditAmount) || 
                                  regex.test(row.Amount__c)|| 
                                  regex.test(row.IsReccuring)||
                                  regex.test(row.ResultingBalance__c) ||
                                     regex.test(row.ParentCategory)||
                                  regex.test(row.SubCategory) ||
                                  regex.test(row.DebitAmount) ||
                                 regex.test(row.TransactionDate__c)) 
            ;
            component.set("v.data",results);
            component.set("v.enableInfiniteLoading",false);
            console.log('length :'+results.length);
            //Ticket SF-177 changes (till line number 483)
            if(results.length <=0){
                // component.set("v.data",'No results found');
                 component.set("v.isNoResultFound",true);
                component.set('v.showSum',false);
            }
            else{
                component.set("v.isNoResultFound",false);
                component.set('v.showSum',true);
            }
        }else{
            component.set("v.data",component.get("v.Filterdata") );
            component.set("v.enableInfiniteLoading",true);
             component.set("v.isNoResultFound",false);
             component.set('v.showSum',true);
        }
        }
       
        
    },
    
    searchBankTransaction1 : function (component, event, helper) {
     var   term = component.get("v.searchKeyWord");
       if(term=='')
       {
            component.set("v.data",component.get("v.Filterdata") );
           component.set("v.enableInfiniteLoading",true);
             component.set("v.isNoResultFound",false);
             component.set('v.showSum',true);
       }
    },
    
    updateColumnSorting: function (component, event, helper) {
        var fieldName = event.getParam('fieldName');
        var sortDirection = event.getParam('sortDirection');
        component.set("v.sortedBy", fieldName);
        component.set("v.sortedDirection", sortDirection);
       
        helper.sorttData(component, fieldName, sortDirection);
    },
    
    clearAll : function (component, event, helper) {
        $A.enqueueAction(component.get('c.fetchBankAccounts'));
        // component.set('v.isOpen',false);
        component.set("v.filterDate",'');
        component.set("v.filterCustomStartDate1",null);
        component.set("v.filterCustomEndDate1",null);
        component.set('v.autoloanflag',false);
        component.set('v.collectionFlag',false);
        component.set('v.creditFlag',false);
        component.set('v.debtFlag',false);
        component.set('v.highcostFlag',false);
        component.set('v.nsfFlag',false);
        component.set('v.overFlag',false);
        component.set('v.allFlagsv1',false);
        component.set('v.payDayFlag',false);
        component.set('v.trusteeFlag',false);
        var empty = [];
        component.set("v.filterFlag", empty);
        
        
    },
    
    AllFlags : function (component, event, helper) {
        var allvals = component.find("allflagsv1").get("v.checked");  
        console.log(allvals);
        if(allvals){
        var flaglist = component.get("v.filterFlag");
            flaglist.push("AUTO_LOAN");
        	flaglist.push("COLLECTION");
        	flaglist.push("CREDIT_REBUILDING_LOAN");
        	flaglist.push("DEBT_MANAGEMENT");
       		flaglist.push("HIGH_COST_LOAN");
        	flaglist.push("NSF");
        	flaglist.push("OVERDRAFT");
        	flaglist.push("PAYDAY_LOAN");
        	flaglist.push("TRUSTEE_PAYMENT");
        console.log('flaglist : '+flaglist);
        component.set("v.filterFlag",flaglist); 
        }else{
            var flaglist = component.get("v.filterFlag");
            flaglist.length = 0;
        }
    }
    
})
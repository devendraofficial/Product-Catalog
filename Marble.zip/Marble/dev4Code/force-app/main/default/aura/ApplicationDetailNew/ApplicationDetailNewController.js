({
    doInit : function(component, event, helper) {
        
        var id = component.get('v.recordId');
        var today = new Date();
        var monthDigit = today.getMonth() + 1;
        if (monthDigit <= 9) {
            monthDigit = '0' + monthDigit;
        }
        component.set('v.today', today.getFullYear() + "-" + monthDigit + "-" + today.getDate()); 
        helper.fetchWrapperData(component, event);
        var action = component.get("c.getCosigners");
        action.setParams({
            "applicationId": component.get('v.recordId')
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var cosMap = [];
                for(var key in result){
                    cosMap.push({label: result[key], value: key});
                }
                component.set("v.cosignerMap", cosMap);
            }
        });
        $A.enqueueAction(action);
    },
    
    editbq : function(component, event, helper) {
        
        if( component.get('v.bqappLabel') =='Save'){
            // helper.updateRecs(component, event);
        }else{
            component.set('v.bqviewmode',false);
            component.set('v.bqappLabel','Save');
        }
    },
    
    ftasaedit : function(component, event, helper) {
        if( component.get('v.ftasaLabel') =='Confirm'){
            if(component.get('v.ftasa.InConsumerProposal__c') =='YES' && component.get('v.ftasa.ConsumerProposalDate__c') == undefined)
            {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Cannot Be Blank When In Consumer Proposal Is Yes.',
                    "type": "error",
                });
                toastEvent.fire();   
            }else if((component.get('v.ftasa.InConsumerProposal__c') =='NO' || component.get('v.ftasa.InConsumerProposal__c') =='') && component.get('v.ftasa.ConsumerProposalDate__c') != undefined){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": 'Consumer Proposal Date Should be Blank When In Consumer Proposal Is None/No.',
                    "type": "error",
                });
                toastEvent.fire();
            }
            else{
                helper.updateRecs(component, event,'appSpecfic');    
            }
        }else{
            component.set('v.ftasaviewmode',false);
            component.set('v.ftasaLabel','Confirm');
        }
    },
    
    ftasacancel : function(component, event, helper) {
        component.set('v.ftasaviewmode',true);
        component.set('v.ftasaLabel','Edit');
    },
    
    editbpa : function(component, event, helper) {
        
        if(component.get('v.bpaappLabel') =='Confirm'){
            helper.updateBorrowerPreApproval(component, event);            
        }else{
            component.set('v.bpaviewmode',false);
            component.set('v.bpaappLabel','Confirm');
        }
    },
    
    editcob :  function(component, event, helper) {
        
        if( component.get('v.cobappLabel') =='Save'){
            helper.updateRecsBor(component, event,'coborrower');    
        }else{
            component.set('v.cobviewmode',false);
            component.set('v.cobappLabel','Save');
        }
    },
    
    editbor:  function(component, event, helper) {
        if( component.get('v.borappLabel') =='Save'){
            helper.updateRecsBor(component, event,'borrower');     
        }else{
            component.set('v.borviewmode',false);
            component.set('v.borappLabel','Save');
        }
        
    },
    
    editcos : function(component, event, helper) {
        
        if( component.get('v.cosappLabel') =='Save'){
            helper.updateRecsBor(component, event,'cosigner');    
        }else{
            component.set('v.cosviewmode',false);
            component.set('v.cosappLabel','Save');
        }        
    },
    
    cancelcos: function(component, event, helper) {
        component.set('v.cosviewmode',true);
        component.set('v.cosappLabel','Edit');
        
    },
    
    cancelbor : function(component, event, helper) {
        component.set('v.borviewmode',true);
        component.set('v.borappLabel','Edit');
    },
    
    cancelcob : function(component, event, helper) {
        component.set('v.cobviewmode',true);
        component.set('v.cobappLabel','Edit');
    },
    
    cancelbpa : function(component, event, helper) {
        component.set('v.bpaviewmode',true);
        component.set('v.bpaappLabel','Edit');
    },
    
    cancelbq : function(component, event, helper) {
        component.set('v.bqviewmode',true);
        component.set('v.bqappLabel','Edit');
    },
    
    handleOnSubmit : function(component, event, helper) {},
    
    handleOnSuccess : function(component, event, helper) {},
    
    handleOnError : function(component, event, helper) {},
    
    addcoborrower : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Borrower');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','coborrower');
    },
    
    addcosigner : function(component, event, helper) {
        component.set('v.modalLabel','Add Co-Signer');
        component.set('v.isModalOpen',true);
        component.set('v.apptype','cosigner');
    },
    
    openModel: function(component, event, helper) {
        // Set isModalOpen attribute to true
        component.set("v.isModalOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    
    submitDetails: function(component, event, helper) {
        
        var callApex=true;
        var lookup = (component.get('v.selectedLookUpRecord'));
        if(component.get('v.selectedradio') == 'search' && (component.get('v.selectedLookUpRecord').Id == undefined))
        {
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Email Cannot be left Blank!',
                "type": "error"
            });
            toastEvent.fire();
        }else if (component.get('v.selectedradio') == 'add' && (component.get('v.accountRec.FirstName') =='' || component.get('v.accountRec.LastName') =='' ||  component.get('v.accountRec.PersonEmail') =='')) {
            
            callApex =false;
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Fill All Required Fields!',
                "type": "error"
            });
            toastEvent.fire();
        }
        
        
        if(callApex){ 
            if(component.get('v.apptype') =='cosigner'){
                var accrecord = component.get('v.accountRec');
                accrecord.IsActive__pc =true;
                component.set('v.accountRec',accrecord);
            }
            console.log(component.get('v.accountRec'));
            var action = component.get("c.createUpdateAccount");
            action.setParams({
                "existingAccount": component.get('v.selectedLookUpRecord'),
                "newRec": component.get('v.accountRec'),
                "applicantType" : component.get('v.apptype'),
                "applicationId" : component.get('v.recordId')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var recId = response.getReturnValue();
                    if(recId == 'fail'){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": 'Add Failed: User Already Present as Borrower/Co-Borrower/Co-Signer!',
                            "type": "error",
                        });
                        toastEvent.fire();
                    }else{
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "message": 'Added Successfully!',
                            "type": "success",
                        });
                        toastEvent.fire();
                        var navLink = component.find("navLink");
                        var pageRef = {
                            type: 'standard__recordPage',
                            attributes: {
                                actionName: 'view',
                                objectApiName: 'Application__c',
                                recordId : component.get('v.recordId')
                            },
                        };
                        navLink.navigate(pageRef, true);
                        //  $A.get('e.force:refreshView').fire();
                        component.set("v.isModalOpen", false);
                    }
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    var finalErrorMessage;
                    if (errors) {
                        var databaseError = errors[0].message;
                        if(databaseError.includes("A9A"))
                            finalErrorMessage = 'Postal Code Must Be In "A9A9A9" Format';
                        else
                            finalErrorMessage =  databaseError;
                        
                        
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": finalErrorMessage,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
        }
    },
    
    onGroup: function(component, event) {
        
        if(component.get('v.selectedradio') =='search'){
            var acc = component.get('v.accountRec');
            acc.FirstName='';
            acc.LastName='';
            acc.PersonEmail='';
            component.set('v.accountRec',acc);
            
        }else if(component.get('v.selectedradio') =='add'){
            component.set('v.selectedLookUpRecord',null);
        }
        
    },
    
    handleSaveEdition: function(component, event, helper) {
        var draftValues = event.getParam('draftValues');
        console.log(draftValues);
        var callApex=true;
        var action = component.get("c.updateRecords");
        action.setParams({"sobjList" : draftValues, "toUpateApplication" : false, "appRecord" :undefined});
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            if (component.isValid() && state === "SUCCESS") {
                helper.fetchWrapperData(component, event);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Updated Successfully!',
                    "type": "success",
                });
                toastEvent.fire();    
            } else if (state === "ERROR") {
                var errors = action.getError();
                var finalmessage='';
                if (errors) {
                    if( errors[0].message.includes('Province: bad value for restricted picklist field' ) )
                        finalmessage= 'Invalid Province. Only AB, BC, MB, NB, NL, NS, NT, NU, ON, PE, QC, SK, YT Allowed';
                    else if(errors[0].message.includes('A person should have only one primary address'))
                        finalmessage = 'A person should have only one primary address';
                    //  else if(errors[0].message.includes('duplicate value found: EmailAddress__c')){
                    //    finalmessage = 'Duplicate Email Entered For User';
                    //  }
                        else if(errors[0].message.includes('Employment Start Month: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Month can only Be January,February,March,April,May,June,July,August,Septemeber,October,November,December';
                        }else if(errors[0].message.includes('Employment Start Year: bad value for restricted picklist field')){
                            finalmessage = 'Employment Start Year Can only be of format 2000, 2001, 2002...';
                        }
                            else
                                finalmessage = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalmessage,
                        "type": "error",
                    });
                    toastEvent.fire();          
                }
            }            
        });
        $A.enqueueAction(action);
    },
    
    viewInactivecos :  function(component, event, helper) {
        component.set('v.isModalOpenCos',true);
    },
    
    closecosModel :  function(component, event, helper) {
        component.set('v.isModalOpenCos',false);
    },
    
    addAddress : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        /*   var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();            	
        }else if(addAdress =='coborroweraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
        }else if(addAdress =='cosigneraddress'){
            var createAddress = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createAddress.setParams({
                "entityApiName": "Address__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createAddress.fire();
            
            
        }*/
        var addAdress = event.getSource().getLocalId();
        if(addAdress =='borroweraddress'){
            let borrower = component.get('v.borrower');
            component.set('v.reqAccId',borrower.Id);
        }else if(addAdress =='coborroweraddress'){
            let coborrower = component.get('v.coborrower');
            component.set('v.reqAccId',coborrower.Id);
        }else if(addAdress =='cosigneraddress'){
            let cosigner = component.get('v.activecosigner');
            component.set('v.reqAccId',cosigner.Id);
        }
        
        component.set('v.showAddAddressCMP',true);
        
    },
    
    addEmail : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var email = event.getSource().getLocalId();
        if(email =='borroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();            	
        }else if(email =='coborroweremail'){
            var createEmail = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();
            
        }else if(email =='cosigneremail'){
            var createEmail = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmail.setParams({
                "entityApiName": "Email__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmail.fire();  
        }
    },
    
    addPhone : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var phone = event.getSource().getLocalId();
        if(phone =='borrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();            	
        }else if(phone =='coborrowerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();
            
        }else if(phone =='cosignerphone'){
            var createPhone = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createPhone.setParams({
                "entityApiName": "Phone__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createPhone.fire();  
        }
    },
    
    addEmployment : function(component, event, helper) {
        // this fetches the existing data as rendered in datatable
        var emp = event.getSource().getLocalId();
        if(emp =='borroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let borrower = component.get('v.borrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : borrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();            	
        }else if(emp =='coborroweremp'){
            var createEmp = $A.get("e.force:createRecord");
            let coborrower = component.get('v.coborrower');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : coborrower.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();
            
        }else if(emp =='cosigneremp'){
            var createEmp = $A.get("e.force:createRecord");
            let cosigner = component.get('v.activecosigner');
            var LOOKUP = 'LOOKUP'; 
            createEmp.setParams({
                "entityApiName": "Employment__c",
                "navigationLocation":LOOKUP,
                "defaultFieldValues": {
                    'Account__c' : cosigner.Id
                },
                "panelOnDestroyCallback": function() {
                    helper.fetchWrapperData(component, event);
                }
            });
            createEmp.fire();  
        }
    },
    
    
    sendconnecturl : function(component, event, helper) {
        
            var action = component.get("c.getBankUrl");
            action.setParams({
                "applicationId": component.get('v.recordId'),                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                     var toastEvent = $A.get("e.force:showToast");
                      toastEvent.setParams({
                            "title": "Success!",
                            "message": "Bank Connection URL Sent Successfully!",
                            "type": "success"
                        });
                        toastEvent.fire();
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    if (errors) {
                        var databaseError = errors[0].message;
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": databaseError,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
            
        },
    
    checkValidity : function(component, event, helper) {
        var validity = event.getSource().get("v.validity");
        console.log(validity)
    },
    
    checkReason :  function(component, event, helper) {
        if(component.get('v.applicationRec.ApplicationStatus__c') =='Rejected')
            component.set('v.showReason',true);
        else
            component.set('v.showReason',false);
    },
    
    activatecos : function(component, event, helper) {
        component.set('v.showActivateCosScreen',true);
         component.set('v.isModalOpenCos',false);
    },
    
    closecosaModel :function(component, event, helper) {
        component.set('v.showActivateCosScreen',false);
        component.set('v.cos','');
    },
    
    activateCosigner : function(component, event, helper) {
        var callApex =true;
        if(component.get('v.cos') == undefined || component.get('v.cos') =='' ){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Error!",
                "message": 'Please Select Atleast One Co-Signer',
                "type": "error",
            });
            toastEvent.fire();
        }else{
            
            var action = component.get("c.updateActiveCosigner");
            action.setParams({
                "idToActivate": component.get('v.cos'),
                "activecos": component.get('v.activecosigner')
                
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    component.set('v.loading',true);
                    
                    
                     window.setTimeout(
  					$A.getCallback(function() {
                    var toastEvent = $A.get("e.force:showToast");
                	toastEvent.setParams({
                    "title": "Success!",
                    "message": 'Co-Signer Activated!',
                    "type": "success",
                });
                toastEvent.fire();
    				component.set("v.loading",false);
                  location.reload(true);
  					}), 3000
					);
                    component.set('v.showActivateCosScreen',false);
                    
                    
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    if (errors) {
                        var databaseError = errors[0].message;
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": databaseError,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action);   
            
        }
    }
})
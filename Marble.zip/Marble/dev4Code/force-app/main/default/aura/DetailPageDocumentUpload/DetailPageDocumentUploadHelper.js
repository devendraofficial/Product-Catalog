({
    fetchData:function(component,event,helper)
    {
        var action = component.get("c.getDocuments");
        action.setParams({ LoanApplicationId : component.get("v.applicationId"),accountType : component.get("v.accountType") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               
               var appEvent = $A.get("e.c:RefreshMissingDcouments"); 
        	   appEvent.fire(); 
               var x = response.getReturnValue().RecDocList;
                var y =response.getReturnValue().pdList;
                
                x.forEach(function(record1){ 
                    record1.bool = true;
                     
                    y.forEach(function(record2){
                        if(record1.DocumentType__c==record2.Name)
                        {
                            record1.bool = false;
                        }
                       
                    })
                    
                });
                
             
              
                  
                  
                  
                
                component.set('v.documentTypes',x);
                component.set('v.productDocumentTypes',y);
				
            }
        });
        $A.enqueueAction(action);
        
    },
})
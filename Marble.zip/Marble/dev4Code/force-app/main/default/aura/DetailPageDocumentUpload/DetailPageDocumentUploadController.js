({
    doInit : function(component, event, helper) {
        
        helper.fetchData(component,event,helper);
        
    },
    buttonClick:function(component,event,helper){
        var val=event.getSource().get('v.value');
        component.set('v.documentHeaderId',val);
        component.set("v.viewModal",'true');
        component.set('v.fileUploadStatus','No file Uploaded!!!')
    },
    handleUploadFinished:function(component,event,helper){
        
        var val=event.getSource().get('v.name');
        var val1 = component.get('v.accountType');
        var uploadedFiles = event.getParam("files");
        for(var i=0;i<uploadedFiles.length;i++)
        {
            
            var action = component.get("c.fileInsert");
            action.setParams({ fileId:uploadedFiles[i].documentId , RecoveredDocumentId: event.getSource().get('v.name') });
            
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    helper.fetchData(component,event,helper);
               	 	}
            });
            $A.enqueueAction(action);
        }
    },
    insertFile:function(component,event,helper)
    {
        
        var action = component.get("c.uploadedFileId");
        action.setParams({ fileId : component.get("v.uploadedFileId"),docName:component.find("DocumentId").get("v.value"),docHeadId:component.get("v.documentHeaderId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                component.set('v.viewModal','false');
                helper.fetchData(component,event,helper);
            }
        });
        $A.enqueueAction(action);
        
    },
    cancelModal :function(component,event,helper)
    {
        
        
        component.set('v.viewModal','false');
        
    },
    viewClick :function(component,event,helper)
    {
        var val=event.getSource().get('v.value');
        component.set('v.imgModal','true');
        component.set('v.fileCardId',val);
    },
    deleteClick :function(component,event,helper)
    {
        
        var action = component.get("c.deleteFile");
        action.setParams({ fileId : event.getSource().get('v.value') });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                helper.fetchData(component,event,helper);
            }
        });
        $A.enqueueAction(action);
        
    },
    closeModal :function(component,event,helper)
    {
        component.set('v.imgModal','false');
        
        
    },
    createDoc:function(component,event,helper)
    {
        component.set('v.docModal','true');
        
    },
    canceldocHeader:function(component,event,handler)
    {
        component.set('v.docModal','false');
        
    },
    insertDocHeader:function(component,event,helper)
    {
        var isExisting = false;
        var val=component.find("DocumentHeadId").get("v.value");
        var existingDocumentType = component.get('v.documentTypes');
        existingDocumentType.forEach(function(record){
            if((record.Name).toLowerCase()==val.toLowerCase().replace(/\s*$/,''))
                isExisting = true;    
        })
        
        if(isExisting)
        {
            alert('Document Type already Existing');
        }
        else
        {
            var action = component.get("c.insertDoc");
            action.setParams({ applicationId : component.get('v.applicationId'),documentHeader:component.find("DocumentHeadId").get("v.value"),accountType:component.get('v.accountType')});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    
                    helper.fetchData(component,event,helper);
                    component.set('v.docModal','false');
                }
            });
            $A.enqueueAction(action);
            
        }
    },
    
    handleComponentEvent:function(component,event,helper)
    {
        
        helper.fetchData(component,event,helper);
    },
    handleNewButton:function(component,event,helper)
    {
        component.set('v.docModal','true');
    },
    deleteRecovery:function(component,event,helper)
    {
     
         var action = component.get("c.DeleteRecoveredDocument");
        action.setParams({ recoveredDocumentId :event.getSource().get('v.value')});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    
                    helper.fetchData(component,event,helper);
                    component.set('v.docModal','false');
                }
            });
            $A.enqueueAction(action);

    },
    
    inlineEditName : function(component,event,helper){   
        
      debugger
		 var id =event.getSource().get('v.value');
         var comment = component.find(id);
        $A.util.addClass(comment, "slds-hide");
 

      
    },
    handleSelectStatus :function(component,event,helper){

        
        debugger
        	 var selectedRecDocId =event.getSource().get('v.name');
            var selectedMenuItemValue = event.getParam("value");
        
        
        
        
        
         var action = component.get("c.changeStatus");
        action.setParams({ updatedStatus :selectedMenuItemValue,recoveredDocumentId : selectedRecDocId});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                   
                    helper.fetchData(component,event,helper);
                   
                }
            });
            $A.enqueueAction(action);
  
        
        
    },

    
})
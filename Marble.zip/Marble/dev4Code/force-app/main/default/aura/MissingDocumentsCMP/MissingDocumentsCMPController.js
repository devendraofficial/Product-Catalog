({
	sendEmail : function(component, event, helper) {
		
	}
})
({
    fetchData:function(component,event,helper)
    {
        var action = component.get("c.getDocuments");
        
        action.setParams({ LoanApplicationId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                debugger
                component.set('v.documentTypes',response.getReturnValue().ldhList);
                component.set('v.productDocumentTypes',response.getReturnValue().pdList);
               
            }
        });
        $A.enqueueAction(action);
        
    },
})
({
    closeModal : function(component, event, helper) {
        
        var vx = component.get("v.method");
        $A.enqueueAction(vx);
    },
    doInit:function (component, event,helper) {
      
        helper.fetchData(component,event,helper);
    },
    handleUploadFinished:function(component, event,helper) {
    },
    
    
    
    handleFilesChange: function(component, event, helper) {
        
         if (component.find("fuploader").get("v.files").length > 0) {
        component.set('v.isFileSelected',false);
         }
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            
            fileName = event.getSource().get("v.files")[0]['name'];
            component.set('v.fileDetails',fileName);
            component.set('v.isFileSelected',true);
        }
        component.set("v.fileName", fileName);
    },
    
     handleSave: function(component, event, helper) {
		 debugger
         var val1=component.get('v.documentType');
        var fileName = component.get('v.fileName');
         var files = component.find("fuploader").get("v.files");
		         
        if (files !=null && fileName!=null && val1 !=null) {

            component.set('v.loaded',true);
            helper.uploadHelper(component, event);
        } 
         else {

            if(fileName==null)
            {

                var inputCmp = component.find("fileName");
                inputCmp.showHelpMessageIfInvalid();
                
            }
             
              if(val1==null)
            {

                var inputType = component.find("fileType");
                inputType.showHelpMessageIfInvalid();
                
            }
             
             if(files == null)
             {
                 var inputFile = component.find("fuploader");
                inputFile.showHelpMessageIfInvalid();  
                 
             }
             
            
            
            
        }
         
       
    },
    changeVal:function(component,event,helper)
    {
        var selectedOptionValue = event.getParam("value");
        component.set('v.documentType',selectedOptionValue);
        
    }
   
    
    
})
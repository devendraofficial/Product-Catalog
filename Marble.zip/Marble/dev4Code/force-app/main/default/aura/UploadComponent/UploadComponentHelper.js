({
    
    MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 4500000,
    
    
	fetchData : function(component,event,helper) {
		
        var action = component.get("c.getProDocuments");
        var val = component.get("v.currentUserType");
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.recoveredDocuments',response.getReturnValue().recDocList);
                var recordData = component.get('v.recoveredDocuments');
                recordData.forEach(function(Rec){
                    Rec.label = Rec.DocumentType__c;
                    Rec.value = Rec.DocumentType__c;
                });      
                component.set('v.recoveredDocuments',recordData);				
            }
        });
        $A.enqueueAction(action);
        
	},
    uploadHelper: function(component, event) {

        var fileInput = component.find("fuploader").get("v.files");
        var file = fileInput[0];
        var self = this;


        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
         

        var objFileReader = new FileReader();

        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
             
            fileContents = fileContents.substring(dataStart);

            self.uploadProcess(component, file, fileContents);
        });
         
        objFileReader.readAsDataURL(file);
    },
     
    uploadProcess: function(component, file, fileContents) {

        var startPosition = 0;

        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
         

        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
     
     
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {

        var getchunk = fileContents.substring(startPosition, endPosition);

        var action = component.get("c.SaveFile");
        action.setParams({
            parentId: component.get("v.recordId"),
            fileName: component.get("v.fileName"),
            fileType: component.get("v.documentType"),
            userType: component.get("v.currentUserType"),
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
         

        action.setCallback(this, function(response) {

            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {

                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);



                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    
        
            
              component.set('v.handleUploadFinished',false);
                    var appEvent = $A.get("e.c:RefreshDocument");
                    appEvent.setParams({
                        
            "message" :  component.get('v.documentType') });
                appEvent.fire();
                                   
                    
                }

            } else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
                component.set('v.handleUploadFinished',false);
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        component.set('v.handleUploadFinished',false);
                    }
                } else {
                    console.log("Unknown error");
                    component.set('v.handleUploadFinished',false);
                }
            }
        });

        $A.enqueueAction(action);
    }
})
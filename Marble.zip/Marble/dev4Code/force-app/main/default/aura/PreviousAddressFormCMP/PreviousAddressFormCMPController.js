({
	closeModel: function(component, event, helper) {
        component.set("v.isModalOpen", false);
        //console.log(JSON.stringify(component.get('v.previousAddress')));
    },
})
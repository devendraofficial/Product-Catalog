({
	preview : function(component, event, helper) {
		
        
        component.set('v.imgModal','true');

	},
    closePreview :function(component)
    {
       component.set('v.imgModal','false'); 

    },
     closeModalWithoutSave : function(component, event, helper) {
         var cmpEvent = component.getEvent("CloseRequestEvent");
        
         cmpEvent.fire();
         
	},
    closeModal : function(component, event, helper) {

        var vx = component.get("v.method");
        $A.enqueueAction(vx);
	},
    
     doInit:function (component, event,helper) {
         var recId = component.get('v.row');

         component.set('v.fileName',recId.Title);
         component.set('v.type',recId.DocumentType);
         component.set('v.status',recId.DocumentStatus__c);
         component.set('v.fileCardId',recId.FileId__c);
      helper.fetchData(component,event,helper);
    },
    
    update:function(component, event, helper) {        
        var action = component.get("c.editDocument");
        var val = component.get("v.row"); 
        var val2 = component.get('v.fileName');
        var val3 = component.get('v.type');
        var val4 = component.get('v.status');
        var val5 = component.get('v.recordId');
        var val6 = component.get('v.currentUserType');
       
		if(val2!=null && val3!=null &&val4!=null)
        {
        if(val3==null)
        {
            var rec = component.get('v.row');
            val3 = rec.DocumentType;
        }
        if(val4==null)
        {
            var rec = component.get('v.row');
            val4 = rec.DocumentStatus__c;
        }        
        action.setParams({ row : component.get("v.row"),newName: component.get('v.fileName'),newType:val3,newStatus:val4,recordId:component.get('v.recordId'),type:component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
               
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                     "title": "Success!",
                    "message":"Record Updated!",
                    "type": 'success',
                });
                toastEvent.fire();
                
                
                var appEvent = $A.get("e.c:RefreshDocument");
                appEvent.fire();
            }
        });
        $A.enqueueAction(action);   
    }
        else
        {
            var name = component.find("FileName");
            var namevalue = inputCmp.get("v.value");
            if(namevalue==null)
            {
                 name.showHelpMessageIfInvalid();
            }
        }
    },
    
    
})
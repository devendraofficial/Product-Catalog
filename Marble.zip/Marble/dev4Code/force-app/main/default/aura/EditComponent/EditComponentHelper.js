({
    fetchData : function(component,event,helper) {
        
        var action = component.get("c.getProDocuments");
        var val = component.get("v.recordId");
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                debugger
                
                component.set('v.recoveredDocuments',response.getReturnValue().recDocList);
                component.set('v.statusList',response.getReturnValue().valueList);
               
                 var recDocList = component.get('v.recoveredDocuments');
                recDocList.forEach(function(rec){
                    rec.label = rec.DocumentType__c;
                    rec.value = rec.DocumentType__c;
                });
                component.set('v.recoveredDocuments',recDocList);
            
           
                
                

            }
        });
        $A.enqueueAction(action);
        
    }
})
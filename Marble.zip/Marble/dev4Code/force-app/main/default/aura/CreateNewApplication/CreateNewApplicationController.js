({
	doInit : function(component, event, helper) {
        
        var applicantId = component.get('v.recordId');
        var action = component.get("c.createApplication");
               action.setParams({
                "applicantId": applicantId,
                   "applicationRecord" : null,
                   "appType":'borrower',
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();
                if (component.isValid() && state === "SUCCESS") {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Success!",
                        "message": 'Appplication Created Successfully!',
                        "type": "success",
                    });
                    toastEvent.fire();
                    
                    var recId = response.getReturnValue();
                    var navLink = component.find("navLink");
                    var pageRef = {
                        type: 'standard__recordPage',
                        attributes: {
                            actionName: 'view',
                            objectApiName: 'Application__c',
                            recordId : recId //
                        },
                    };
                    navLink.navigate(pageRef, true);
                    $A.get("e.force:closeQuickAction").fire();
                }
                else if (state === "ERROR") {
                    var errors = action.getError();
                    if (errors) {
                        
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "message": errors[0].message,
                            "type": "error",
                        });
                        toastEvent.fire();
                        
                    }
                }
            });
            $A.enqueueAction(action); 
		
	}
})
({
    
    doInit: function(component, event, helper) {
        var recordId;
        if(component.get("v.pageReference") != null){
            component.set('v.recordId', component.get("v.pageReference").state.c__id);
            recordId = component.get("v.pageReference").state.c__id;
            component.set('v.isVisible',true);
        }else{
            recordId = component.get('v.recordId');
            
        }
        component.set('v.recordId',recordId);
        component.set('v.showBorrower',true);
        
        
        var action = component.get("c.checkApplicants");
         action.setParams({
            "recId": recordId
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
               var reps = response.getReturnValue();
               
                
                for(var key in reps){
                    if(key == 'BORROWER')
                    component.set('v.borrowerPresent',reps[key]);
                    else if(key == 'COBORROWER')
                    component.set('v.coborrowerPresent',reps[key]); 
                    else if(key == 'COSIGNER')
                    component.set('v.cosignerPresent',reps[key]);     
                } 
                
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": databaseError,
                        "type": "error",
                    });
                    toastEvent.fire();
                    
                }
            }
        });
        $A.enqueueAction(action); 
    },
    
    tabSelected : function(component, event, helper) {
        
         if(component.get('v.selTabId') =='borrowertab'){
             component.set('v.showBorrower',true);
             component.set('v.currentUserType','BORROWER');
         }else if(component.get('v.selTabId') =='coborrowertab'){
             component.set('v.showcoBorrower',true);
             component.set('v.currentUserType','COBORROWER');
         }else if(component.get('v.selTabId') =='cosignertab'){
             component.set('v.showcoSigner',true);
             component.set('v.currentUserType','COSIGNER');
         }
    },
    //Vertical Navigation CMP
    handleVerticalMenu:function(component,event,helper){
        var tab = event.getParam("tab");
        if(tab=="BankStatement"){
            component.set('v.isVisible','true');
        }
        else
            component.set('v.isVisible','false');
        
    },
    
    
    openEmailModel: function(component, event, helper) {
        component.set('v.loading',true);
        helper.fetchData(component, event, helper);
        helper.fetchEmailTemplatesList(component, event, helper);
        component.set("v.isEmailOpen", true);
        //component.set('v.templatePreviewBody','');
    },
    
    closeEmailModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
        component.set("v.isEmailOpen", false);
    },
    showTemplateBody:function(component,event,helper){
        component.set('v.loading','true');
        helper.fetchTemplateBody(component,event,helper);
    } ,
    openNewWindow: function(component, event, helper){
        window.open('/lightning/cmp/c__BankStatementCMP?c__id='+component.get('v.recordId'),'_new');
    },
    sendEmailTo: function(component, event, helper){
        component.set('v.loading',true);
        helper.sendEmailTo(component, event, helper);
    },
})
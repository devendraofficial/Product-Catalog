({
	helperMethod : function() {
		
	},
    
    fetchEmailTemplatesList : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : ''
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                console.log('Fetch success Box');
                var res = response.getReturnValue();    
                var templateListVal = [];
                if(res != null && res.data != null && res.data.result != null){
                    for(var i=0;i<res.data.result.length;i++){
                        if(res.data.result[i].Name == "Connect Inverite"){
                            templateListVal.push(res.data.result[i]);
                            break;
                        }
                    }
                    if(templateListVal.length == 1){
                    	component.set('v.emailTemplateList',templateListVal);  
                        component.set('v.emailTemplateSelectedVal',templateListVal[0].Id);
                        helper.fetchTemplateBody(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                    }
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
            }
        });
        $A.enqueueAction(action); 
    },
    fetchTemplateBody : function(component, event, helper){
        var action = component.get("c.fetchEmailTemplates");
        action.setParams({
            "templateId" : component.get("v.emailTemplateSelectedVal")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                var res = response.getReturnValue();    
                if(res != null && res.data != null && res.data.result != null){
                    var filertedtext = res.data.result[0].HtmlValue.split('</head>');
                    component.set('v.templatePreviewBody',filertedtext[1]);
                }
                component.set("v.loading",false);
            }
            else if (state === "ERROR") {
                var errors = action.getError();
                var finalErrorMessage;
                if (errors) {
                    var databaseError = errors[0].message;
                    finalErrorMessage =  databaseError;
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error!",
                        "message": finalErrorMessage,
                        "type": "error",
                    });
                    toastEvent.fire(); 
                }
                component.set("v.loading",false);
            }
        });
        $A.enqueueAction(action); 
    },
    fetchData : function(component,event,helper) {
        var action = component.get("c.getMailDetails");
        action.setParams({ LoanApplicationId : component.get("v.recordId"), accountType :component.get('v.currentUserType')});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('-----'+JSON.stringify(response.getReturnValue()));
                if(response.getReturnValue().PersonEmail != undefined)
                component.set('v.PersonEmail',response.getReturnValue().PersonEmail);
                if(response.getReturnValue().Name != undefined)
                component.set('v.Name',response.getReturnValue().Name);
            }
        });
        $A.enqueueAction(action);
        
    },
    sendEmailTo : function(component,event,helper) {
        console.log(component.get('v.PersonEmail'));
        var action = component.get("c.sendConnectionEmail");
        action.setParams({ applicationId : component.get("v.recordId"),
                          emailAddress :component.get('v.PersonEmail'),
                          htmlString :component.get('v.templatePreviewBody'),
                          accountType :component.get('v.currentUserType')
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var returnValue = response.getReturnValue();
                var message = '';
                var title = '';
                if(returnValue.calloutError){
                    var msg = JSON.parse(returnValue.calloutError);
                    message = msg.errors[0].stacktrace;
                    title="error";
                }else if(returnValue.error != null){
                    message = returnValue.error;
                    title="error";
                } else if(returnValue.success != null){
                    message = returnValue.success;
                    title="success";
                }
                console.log('-----'+response.getReturnValue());
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": title[0].toUpperCase()+title.substring(1,title.length),
                    "message": message,
                    "type": title,
                });
                toastEvent.fire(); 
                component.set('v.loading',false);
                component.set('v.isEmailOpen',false);
            }else{
                component.set('v.loading',false);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Error occured, Pleae try again later.",
                    "type": "error",
                });
                toastEvent.fire(); 
            }
        });
        $A.enqueueAction(action);
        
    },
})
({
	myAction : function(component, event, helper) {
		var recorId = component.get("v.recordId");
        var action = component.get("c.main");
		action.setParams({  contactId : recorId  });
        action.setCallback(this, function(response){
        var state = response.getState();
        if(state === 'SUCCESS'){
            alert('Softpull Success');
        }
    });
    $A.enqueueAction(action);
	}
})
({
    
    isTableResetRequired : false ,
    CoBorrowerTabShowHide : function(component, event, helper) {
        console.log('CoBorrowerTabShowHide function called');
        var action = component.get("c.checkForCoborrower");
        action.setParams({
            applicationID: component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var coborrower = response.getReturnValue();
                console.log('coborrower value:',coborrower);
                if(coborrower != null){
                    component.set("v.CoborrowerDiv",true);
                }
            }
        });
        $A.enqueueAction(action);
    },
    CoSignerTabShowHide : function(component, event, helper) {
        console.log('CoBorrowerTabShowHide function called');
        var action = component.get("c.checkForCoSigner");
        action.setParams({
            applicationID: component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var cosigner = response.getReturnValue();
                console.log('cosigner value:',cosigner);
                if(cosigner != null){
                    component.set("v.CoSignerDiv",true);
                }
            }
        });
        $A.enqueueAction(action);
    },
    fetchApplicantDetail : function(component, event, helper) {
        var action = component.get("c.getApplicantName");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set('v.accDetails',response.getReturnValue().acc);
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchCreditDetails : function(component, event, helper, reportId) {
        if(reportId != ''){
            component.set('v.HitErrorMessage','slds-hide');
            component.set('v.insightSection','slds-hide');
            component.set('v.insightSectionFull','slds-hide');
            component.set('v.postCP',false);
            component.set('v.filterReport',false);
            component.set("v.isPostCpFilterActivate",false);
            component.set("v.isFilterActivate",false);
            component.set("v.isAllFilterActivate",false);
            component.set("v.loading",true);
            component.set("v.searchValue",'');
            helper.showAllAccordions(component, event, helper, true);
        }
        var action = component.get("c.getCreditDetails");
        var recId = component.get("v.recordId");
        var applicantType = component.get("v.applicantType");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType1: component.get("v.applicantType"),
            selectedReportId : reportId
        });
        action.setCallback(this, function(response) {
            if(response){
                console.log(response.getReturnValue());
                var state = response.getState();
                var returnResponse = response.getReturnValue();
                if(state === 'SUCCESS') {
                    if(returnResponse != null && returnResponse.HardPullWrapper){
                        var creditData = returnResponse.HardPullWrapper;
                        component.set("v.CreditData",creditData);
                        if(creditData != null){
                            var hit = creditData.creditHistory.hit;
                            if (hit == false) {
                                component.set("v.insightSection",'slds-hide');
                                component.set("v.isDisabled",true);
                                component.set("v.isDisabledPostCP",true);
                                component.set("v.HitErrorMessageEnable", true);
                                component.set("v.HitErrorMessage",'slds-show');
                                console.log('JSON structure is incorrect');
                                component.set("v.IDMismatchAcordian",'slds-hide');
                                component.set("v.TradeAcordian",'slds-hide');
                                component.set("v.residenceAcordian",'slds-hide');
                                component.set("v.EmploymentAcordian",'slds-hide');
                                component.set("v.BankingClosedAcordian",'slds-hide');
                                component.set("v.RegisteredItemsAcordian",'slds-hide');
                                component.set("v.BankruptcyAcordian",'slds-hide');
                                component.set("v.InquiriesAcordian",'slds-hide');
                                component.set("v.OverviewAcordian",'slds-hide');
                                component.set("v.LegalItemsAcordian",'slds-hide');
                                component.set("v.CollectionsAcordian",'slds-hide');
                                component.set("v.RemarksAcordian",'slds-hide');
                            }else if(hit == true){
                                component.set("v.HitErrorMessageEnable", false);
                                component.set("v.HitErrorMessage",'slds-hide');
                                component.set("v.errorMessage",'');
                                helper.convertToDatatableData(component, event, helper);
                                //component.set("v.loading",true);
                            }
                            if(returnResponse.isHardPull != undefined && returnResponse.isHardPull == true){
                                component.set("v.currentActiveReportname","full");
                                component.set("v.isDisabled",false);
                                component.set("v.isDisabledPostCP",false);
                                helper.setinsightFieldsValue(component, event, helper);
                            }else{
                                component.set("v.currentActiveReportname","summary");
                                component.set("v.isDisabled",true);
                                if(hit){
                                	component.set("v.insightSection",'slds-show');    
                                }
                                component.set("v.isDisabledPostCP",true);
                                helper.setRedFlagsVisibility(component, event, helper,false);
                            }
                            helper.setAdditionalFields(component, event, helper);
                            component.set("v.loading",false);
                        }else{
                            component.set("v.loading",false);
                            helper.showToast(component, event, helper,returnResponse.error,"error");
                            helper.handleErrorblock(component, event, helper);
                        }
                    }else if(returnResponse.error){
                        component.set("v.loading",false);
                        helper.showToast(component, event, helper,returnResponse.error,"error");
                        helper.handleErrorblock(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                        helper.showToast(component, event, helper,"Something went wrong, Please try again later.","error");
                        helper.handleErrorblock(component, event, helper);
                    }
                }else if (status === "INCOMPLETE") {
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,"No response from server or client is offline.","error");
                    helper.handleErrorblock(component, event, helper);
                }else if (status == "ERROR") {
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,"Error occured.","error");
                    helper.handleErrorblock(component, event, helper);
                }else{
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,"Unable to read JSON data","error");
                    helper.handleErrorblock(component, event, helper);
                }
            }else{
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"Unable to read JSON","error");
                helper.handleErrorblock(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    handleErrorblock : function(component, event, helper) {
        //helper.setRedFlagsVisibility(component, event, helper,false);
        //helper.hideAllAccordianTabs(component, event, helper,false);
        //component.set("v.CreditData.creditHistory",null);
        //helper.convertToDatatableData(component, event, helper);
    },
    setRedFlagsVisibility : function(component, event, helper,isShow) {
        if(isShow){
            // not useful, just for future reference
            component.set("v.MoreThan3InquiriesInThePast6Months", "slds-show");
            component.set("v.JobTenureUnderOneYear", "slds-show");
            component.set("v.IncomeUnder2000PerMonth", "slds-show");
            component.set("v.NotInConsumerProposal", "slds-show");
            component.set("v.ConsumerProposalAgeUnderOneYear", "slds-show");
            component.set("v.ConsumerProposalBalanceOver15000", "slds-show");
            component.set("v.CreditSoughtDuringConsumerProposal", "slds-show");
            component.set("v.ResidenceTenureUnderOneYear", "slds-show");
            component.set("v.IDMismatchWarnings", "slds-show");
            component.set("v.HighRiskFraudAlerts", "slds-show");
            component.set("v.NoCreditScore", "slds-show"); 
            component.set("v.CreditScoreUnder500", "slds-show");
            component.set("v.DebtInCollections", "slds-show");
            component.set("v.DebtServiceRatioOver50Percent", "slds-show");
            component.set("v.PaydayLoans", "slds-show");
            component.set("v.CreditObtainedDuringConsumerProposal", "slds-show");
            component.set("v.BankingClosed", "slds-show");
        }else{
            component.set("v.MoreThan3InquiriesInThePast6Months", "slds-hide");
            component.set("v.JobTenureUnderOneYear", "slds-hide");
            component.set("v.IncomeUnder2000PerMonth", "slds-hide");
            component.set("v.NotInConsumerProposal", "slds-hide");
            component.set("v.ConsumerProposalAgeUnderOneYear", "slds-hide");
            component.set("v.ConsumerProposalBalanceOver15000", "slds-hide");
            component.set("v.CreditSoughtDuringConsumerProposal", "slds-hide");
            component.set("v.ResidenceTenureUnderOneYear", "slds-hide");
            component.set("v.IDMismatchWarnings", "slds-hide");
            component.set("v.HighRiskFraudAlerts", "slds-hide");
            component.set("v.NoCreditScore", "slds-hide"); 
            component.set("v.CreditScoreUnder500", "slds-hide");
            component.set("v.DebtInCollections", "slds-hide");
            component.set("v.DebtServiceRatioOver50Percent", "slds-hide");
            component.set("v.PaydayLoans", "slds-hide");
            component.set("v.CreditObtainedDuringConsumerProposal", "slds-hide");
            component.set("v.BankingClosed", "slds-hide");
        }
    },
    setinsightFieldsValue : function(component, event, helper) {
        var creditData = component.get("v.CreditData");
        var MoreThan3InquiriesInThePast6Months = false;
        var CreditSoughtDuringConsumerProposal  = false;
        var JobTenureUnderOneYear = false;
        var IncomeUnder2000PerMonth = false;
        var NotInConsumerProposal = false;
        var ConsumerProposalAgeUnderOneYear = false;
        var ConsumerProposalBalanceOver15000  = false;
        var CreditObtainedDuringConsumerProposal = false;
        var PaydayLoans  = false;
        var DebtServiceRatioOver50Percent = false;
        var ResidenceTenureUnderOneYear  = false;
        var IDMismatchWarnings = false;
        var HighRiskFraudAlerts = false;
        var NoCreditScore  = false;
        var CreditScoreUnder500 = false;
        var DebtInCollections = false;
        var BankingClosed = 0;
        var isNoHitFound = component.get("v.HitErrorMessageEnable");
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined){
            MoreThan3InquiriesInThePast6Months = creditData.insights.warnings.inquiriesSixMonthsOverMax;
            if(!isNoHitFound && MoreThan3InquiriesInThePast6Months == true){
                component.set("v.MoreThan3InquiriesInThePast6Months", "slds-show");
                component.set("v.inquiry_redflag", "slds-show");
            }else{
                component.set("v.MoreThan3InquiriesInThePast6Months", "slds-hide");
                component.set("v.inquiry_redflag", "slds-hide");
            }
        }else{
            component.set("v.MoreThan3InquiriesInThePast6Months", "slds-hide");
            component.set("v.inquiry_redflag", "slds-hide");
        }
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.employment != undefined){
            JobTenureUnderOneYear = creditData.insights.employment.tenureUnderMin;
            if(!isNoHitFound && JobTenureUnderOneYear == true){
                component.set("v.JobTenureUnderOneYear", "slds-show");
                component.set("v.employment_redflag", "slds-show");
            }else{
                component.set("v.JobTenureUnderOneYear", "slds-hide");
                component.set("v.employment_redflag", "slds-hide");
            }
        }else{
            component.set("v.JobTenureUnderOneYear", "slds-hide");
            component.set("v.employment_redflag", "slds-hide");
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.employment != undefined ){
            IncomeUnder2000PerMonth = creditData.insights.employment.payUnderMin;
            if(!isNoHitFound && IncomeUnder2000PerMonth == true){
                component.set("v.IncomeUnder2000PerMonth", "slds-show");
                component.set("v.employment_redflag", "slds-show");
            }else{
                component.set("v.IncomeUnder2000PerMonth", "slds-hide");
                component.set("v.employment_redflag", "slds-hide");
            }
        }else{
            component.set("v.IncomeUnder2000PerMonth", "slds-hide");
            component.set("v.employment_redflag", "slds-hide");
        }
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.cp != undefined ){
            //NotInConsumerProposal = creditData.insights.cp.since;
            if(!isNoHitFound && creditData.insights.cp.since == null){
                NotInConsumerProposal = true;
                component.set("v.NotInConsumerProposal", "slds-show");
                component.set("v.bankruptcyinsolvency_redflag", "slds-show");
            }else{
                NotInConsumerProposal = false;
                component.set("v.NotInConsumerProposal", "slds-hide");
                component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
            }
        }else{
            component.set("v.NotInConsumerProposal", "slds-hide");
            component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
        }
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.cp != undefined ){
            ConsumerProposalAgeUnderOneYear = creditData.insights.cp.durationUnderMin;
            if(!isNoHitFound && ConsumerProposalAgeUnderOneYear == true){
                component.set("v.ConsumerProposalAgeUnderOneYear", "slds-show");
                component.set("v.bankruptcyinsolvency_redflag", "slds-show");
            }else{
                component.set("v.ConsumerProposalAgeUnderOneYear", "slds-hide");
                component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
            }
        }else{
            component.set("v.ConsumerProposalAgeUnderOneYear", "slds-hide");
            component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
        }
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.cp != undefined ){
            ConsumerProposalBalanceOver15000 = creditData.insights.cp.estimatedAmountOverLimit ;
            if(!isNoHitFound && ConsumerProposalBalanceOver15000 == true){
                component.set("v.ConsumerProposalBalanceOver15000", "slds-show");
                component.set("v.bankruptcyinsolvency_redflag", "slds-show");
            }else{
                component.set("v.ConsumerProposalBalanceOver15000", "slds-hide");
                component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
            }
        }else{
            component.set("v.ConsumerProposalBalanceOver15000", "slds-hide");
            component.set("v.bankruptcyinsolvency_redflag", "slds-hide");
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.cp != undefined ){
            CreditSoughtDuringConsumerProposal = creditData.insights.cp.inquiriesDuring;
            if(!isNoHitFound && CreditSoughtDuringConsumerProposal == true){
                component.set("v.CreditSoughtDuringConsumerProposal", "slds-show");
                component.set("v.inquiry_redflag", "slds-show");
            }else{
                component.set("v.CreditSoughtDuringConsumerProposal", "slds-hide");
                component.set("v.inquiry_redflag", "slds-hide");
            }
        }else{
            component.set("v.CreditSoughtDuringConsumerProposal", "slds-hide");
            component.set("v.inquiry_redflag", "slds-hide");
        }
        
        
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.residence != undefined ){
            ResidenceTenureUnderOneYear = creditData.insights.residence.durationUnderMin;
            if(!isNoHitFound && ResidenceTenureUnderOneYear == true){
                component.set("v.ResidenceTenureUnderOneYear", "slds-show");
                component.set("v.residence_redflag", "slds-show");
            }else{
                component.set("v.ResidenceTenureUnderOneYear", "slds-hide");
                component.set("v.residence_redflag", "slds-hide");
            }
        }else{
            component.set("v.ResidenceTenureUnderOneYear", "slds-hide");
            component.set("v.residence_redflag", "slds-hide");
        }
        /*var PoorMortgagePaymentHistory = creditData.residence.mortgage.latePayments;
                if(PoorMortgagePaymentHistory == true){
                    component.set("v.PoorMortgagePaymentHistory", "slds-show");
                }*/
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined ){
            IDMismatchWarnings = creditData.insights.warnings.idMismatch;
            if(!isNoHitFound && IDMismatchWarnings == true){
                component.set("v.IDMismatchWarnings", "slds-show");
                component.set("v.filesummary_redflag", "slds-show");
            }else{
                component.set("v.IDMismatchWarnings", "slds-hide");
                component.set("v.filesummary_redflag", "slds-hide");
            }
        }else{
            component.set("v.IDMismatchWarnings", "slds-hide");
            component.set("v.filesummary_redflag", "slds-hide");
        }
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined ){
            HighRiskFraudAlerts = creditData.insights.warnings.fraud;
            if(!isNoHitFound && HighRiskFraudAlerts == true){
                component.set("v.HighRiskFraudAlerts", "slds-show");
                component.set("v.filesummary_redflag", "slds-show");
            }else{
                component.set("v.HighRiskFraudAlerts", "slds-hide");
                component.set("v.filesummary_redflag", "slds-hide");
            }
        }else{
            component.set("v.HighRiskFraudAlerts", "slds-hide");
            component.set("v.filesummary_redflag", "slds-hide");
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined ){
            NoCreditScore = creditData.insights.warnings.noCreditScore;
            if(!isNoHitFound && NoCreditScore == true){
                component.set("v.NoCreditScore", "slds-show");
                component.set("v.filesummary_redflag", "slds-show");
            }else{
                component.set("v.NoCreditScore", "slds-hide");
                component.set("v.filesummary_redflag", "slds-hide");     
            }
        }else{
            component.set("v.NoCreditScore", "slds-hide");
            component.set("v.filesummary_redflag", "slds-hide");     
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined ){        
            CreditScoreUnder500 = creditData.insights.warnings.creditScoreUnderMin; 
            if(!isNoHitFound && CreditScoreUnder500 == true){
                component.set("v.CreditScoreUnder500", "slds-show");
                component.set("v.filesummary_redflag", "slds-show");
            }else{
                component.set("v.CreditScoreUnder500", "slds-hide");
                component.set("v.filesummary_redflag", "slds-hide");
            }
        }else{
            component.set("v.CreditScoreUnder500", "slds-hide");
            component.set("v.filesummary_redflag", "slds-hide");
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.warnings != undefined ){    
            DebtInCollections = creditData.insights.warnings.unpaidCollections;
            if(!isNoHitFound && DebtInCollections == true){
                component.set("v.DebtInCollections", "slds-show");
                component.set("v.collections_redflag", "slds-show");
            }else{
                component.set("v.DebtInCollections", "slds-hide");
                component.set("v.collections_redflag", "slds-hide");
            }
        }else{
            component.set("v.DebtInCollections", "slds-hide");
            component.set("v.collections_redflag", "slds-hide");
        }
        
        //New flag added here,,,
        if(!isNoHitFound && creditData.creditHistory != null && creditData.creditHistory.bankClosures){    
            BankingClosed = creditData.creditHistory.bankClosures.length;
            if(!isNoHitFound && BankingClosed > 0){
                component.set("v.BankingClosed", "slds-show");
                component.set("v.bankingclosedforcause_redflag", "slds-show");
            }else{
                component.set("v.BankingClosed", "slds-hide");
                component.set("v.bankingclosedforcause_redflag", "slds-hide");
            }
        }else{
                component.set("v.BankingClosed", "slds-hide");
                component.set("v.bankingclosedforcause_redflag", "slds-hide");
        }
        
        if(!isNoHitFound && creditData.insights != undefined && creditData.insights.dsr != undefined 
           && creditData.insights.warnings != undefined && creditData.insights.cp != undefined){    
            DebtServiceRatioOver50Percent = creditData.insights.dsr.overMax;
            PaydayLoans = creditData.insights.warnings.paydayLoans;
            CreditObtainedDuringConsumerProposal = creditData.insights.cp.creditDuring;
            if(!isNoHitFound && DebtServiceRatioOver50Percent){
                component.set("v.DebtServiceRatioOver50Percent", "slds-show");
                component.set("v.trade_redflag", "slds-show");
            }else if(!isNoHitFound && PaydayLoans){
                component.set("v.PaydayLoans", "slds-show");
                component.set("v.trade_redflag", "slds-show");
            }else if(!isNoHitFound && CreditObtainedDuringConsumerProposal){
                component.set("v.trade_redflag", "slds-show");
                component.set("v.CreditObtainedDuringConsumerProposal", "slds-show");
            }else{
                component.set("v.DebtServiceRatioOver50Percent", "slds-hide");
                component.set("v.PaydayLoans", "slds-hide");
                component.set("v.CreditObtainedDuringConsumerProposal", "slds-hide");
                component.set("v.trade_redflag", "slds-hide");
            }
        }else{
            component.set("v.DebtServiceRatioOver50Percent", "slds-hide");
            component.set("v.PaydayLoans", "slds-hide");
            component.set("v.CreditObtainedDuringConsumerProposal", "slds-hide");
            component.set("v.trade_redflag", "slds-hide");
        }
        if(isNoHitFound){
            component.set("v.insightSection",'slds-hide');
            component.set("v.insightSectionFull",'slds-hide');
        }else{
            if((MoreThan3InquiriesInThePast6Months || CreditSoughtDuringConsumerProposal 
                || JobTenureUnderOneYear || IncomeUnder2000PerMonth || NotInConsumerProposal 
                || ConsumerProposalAgeUnderOneYear || ConsumerProposalBalanceOver15000 
                || CreditObtainedDuringConsumerProposal || PaydayLoans 
                || DebtServiceRatioOver50Percent || ResidenceTenureUnderOneYear 
                || IDMismatchWarnings || HighRiskFraudAlerts || NoCreditScore 
                || CreditScoreUnder500 || DebtInCollections || BankingClosed)){
                component.set("v.insightSectionFull",'slds-hide');
                component.set("v.insightSection",'slds-hide');  
            } else {
                if(component.get("v.currentActiveReportname") == 'full'){
                    component.set("v.insightSectionFull",'slds-show');
                    component.set("v.isDisabled",true);
                    component.set("v.insightSection",'slds-hide');
                }else{
                    component.set("v.insightSection",'slds-show');
                    component.set("v.insightSectionFull",'slds-hide');
                }
            }
        }
    },    
    initiateNewSummary : function(component, event, helper) {
        component.set('v.postCP',false);
        component.set('v.filterReport',false);
        component.set("v.isPostCpFilterActivate",false);
        component.set("v.isFilterActivate",false);
        component.set("v.isAllFilterActivate",false);
        component.set("v.insightSection","slds-hide");
        var action = component.get("c.initiateSoftSummaryPull");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                var returnResponse = response.getReturnValue();
                if(returnResponse != null && returnResponse.HardPullWrapper){
                    var creditData = returnResponse.HardPullWrapper;
                    component.set("v.currentActiveReportname","summary");
                    if(creditData != null && creditData.creditHistory != undefined){
                        helper.showAllAccordions(component, event, helper, true);
                        component.set("v.CreditData",creditData);
                        var hit = creditData.creditHistory.hit;
                        //console.log('hit value: ',hit);
                        component.set("v.isHitEnable",hit);
                        component.set("v.isDisabled",true);
                        component.set("v.isDisabledPostCP",true);
                        if (hit == false) {
                            component.set("v.isDisabled",true);
                            component.set("v.isDisabledPostCP",true);
                            component.set("v.HitErrorMessageEnable", true);
                            component.set("v.HitErrorMessage",'slds-show');
                            //console.log('JSON structure is incorrect');
                            component.set("v.IDMismatchAcordian",'slds-hide');
                            component.set("v.TradeAcordian",'slds-hide');
                            component.set("v.residenceAcordian",'slds-hide');
                            component.set("v.EmploymentAcordian",'slds-hide');
                            component.set("v.BankingClosedAcordian",'slds-hide');
                            component.set("v.RegisteredItemsAcordian",'slds-hide');
                            component.set("v.BankruptcyAcordian",'slds-hide');
                            component.set("v.InquiriesAcordian",'slds-hide');
                            component.set("v.OverviewAcordian",'slds-hide');
                            component.set("v.LegalItemsAcordian",'slds-hide');
                            component.set("v.CollectionsAcordian",'slds-hide');
                            component.set("v.RemarksAcordian",'slds-hide');
                            //component.set("v.loading",false);
                        }else if(hit == true){
                            component.set("v.HitErrorMessageEnable", false);
                            component.set("v.HitErrorMessage",'slds-hide');
                            component.set("v.errorMessage",'');
                            helper.convertToDatatableData(component, event, helper);
                            helper.showToast(component, event, helper, "New Summary pulled","success");
                            //component.set("v.loading",false);
                        }
                        component.set("v.loading",false);
                        if(returnResponse.isHardPull != undefined && returnResponse.isHardPull == true){
                            helper.setinsightFieldsValue(component, event, helper);
                        }else{
                            helper.setRedFlagsVisibility(component, event, helper,false);
                        }
                        helper.getCreditRecordDates(component, event, helper);
                    }else{
                        component.set("v.loading",false);
                        helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                        helper.handleErrorblock(component, event, helper);
                    }
                }else if(returnResponse.error){
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,returnResponse.error,"error");
                    helper.handleErrorblock(component, event, helper);
                }else{
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                    helper.handleErrorblock(component, event, helper);
                }
            }else if (status == "INCOMPLETE") {
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"No response from server or client is offline.","error");
                helper.handleErrorblock(component, event, helper);
            }else if (status == "ERROR") {
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                helper.handleErrorblock(component, event, helper);
            }else{
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                helper.handleErrorblock(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    getCreditRecordDates : function(component, event, helper) {
        component.set("v.loading",true);
        var action = component.get("c.getCreditReportDate");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
                                    "July", "Aug", "Sep", "Oct", "Nov", "Dec"
                                   ];
                var creditData = response.getReturnValue();
                var mydates = [];
                if(creditData != null){
                    for (var i=0;i<creditData.length;i++){
                        var obj = {};
                        var typeReport = '';
                        if(creditData[i].IsHardPull__c){
                            typeReport = 'Full';
                        }else{
                            typeReport = 'Summary';
                        }
                        var d = new Date(creditData[i].CreatedDate);
                        var str = monthNames[d.getMonth()]+' '+d.getDate() +','+d.getFullYear()+' - '+typeReport;
                        obj.CreatedDate = str;
                        obj.Id = creditData[i].Id;
                        obj.IsHardPull__c = creditData[i].IsHardPull__c;
                        mydates.push(obj);
                        
                    }
                    component.set("v.datevalue",mydates);
                    if(mydates.length > 0){
                        if(component.get("v.applicantType") == 'BORROWER'){
                            component.find("mySelect").set("v.value",mydates[0].Id);
                        }else if(component.get("v.applicantType") == 'COBORROWER'){
                            component.find("mySelectCo").set("v.value",mydates[0].Id);
                        }else if(component.get("v.applicantType") == 'COSIGNER'){
                            component.find("mySelectSigner").set("v.value",mydates[0].Id);
                        }
                        if(mydates[0].IsHardPull__c){
                            component.set("v.currentActiveReportname","full");
                            component.set("v.isDisabled",false);
                            component.set("v.isDisabledPostCP",false);
                        }else{
                            component.set("v.currentActiveReportname","summary");
                            component.set("v.isDisabled",true);
                            component.set("v.isDisabledPostCP",true);
                            if(!component.get("v.HitErrorMessageEnable")){
                                component.set("v.insightSection",'slds-show');
                            }
                        }
                    }
                }else{
                    component.set("v.datevalue",[]);
                }
                component.set("v.loading",false);
            }else if (status === "INCOMPLETE") {
                component.set("v.loading",false);
                console.log("No response from server or client is offline.")
            }else if (status === "ERROR") {
                component.set("v.loading",false);
                console.log("Error: " + errorMessage);
            }
        });
        $A.enqueueAction(action);
    },
    
    setAdditionalFields : function(component, event, helper) {
        var creditData = component.get("v.CreditData");
        var jsonDate = creditData.creditHistory.pulledAt;
        var overViewDate = ($A.localizationService.formatDate(jsonDate,"yyyy-MM-dd"));
        component.set("v.OverviewDate",overViewDate);
        if(creditData.creditHistory != undefined && creditData.creditHistory.phoneNumbers != undefined  && creditData.creditHistory.phoneNumbers.length > 0){
            var phoneNumber1 = creditData.creditHistory.phoneNumbers[0].areaCode + creditData.creditHistory.phoneNumbers[0].applicantphoneNumber;
            if(phoneNumber1 != undefined){
                var cleaned = ('' + phoneNumber1).replace(/\D/g, '');
                var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
                if (match) {
                    component.set("v.PhoneNumber1",'(' + match[1] + ') ' + match[2] + '-' + match[3]); 
                }else {
                    component.set("v.PhoneNumber1",'--');
                }
            }
            //below condition is added outside if condition, now we can fetch prev telephone field value
            var phoneNumber2 = creditData.creditHistory.phoneNumbers[1].areaCode + creditData.creditHistory.phoneNumbers[1].applicantphoneNumber;
            if(phoneNumber2 != undefined){
                var cleaned = ('' + phoneNumber2).replace(/\D/g, '');
                var match2 = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
                if (match2) {
                    component.set("v.PhoneNumber2",'(' + match2[1] + ') ' + match2[2] + '-' + match2[3]); 
                }else {
                    component.set("v.PhoneNumber2",'--');
                }
            }
        }
    },
    filterDataTablesByInput : function(component, event, helper,searchInput) {
        var creditData = component.get("v.CreditData");
        var arrayToSearch = [];
        var objHistory = creditData.creditHistory; 
        if(component.get("v.isFilterActivate")){
            arrayToSearch = component.get("v.FilteredObjects");
        }else if(component.get("v.isPostCpFilterActivate")){
            arrayToSearch = component.get("v.postCPSearchObject");
        }else if(component.get("v.isAllFilterActivate")){
            arrayToSearch = component.get("v.allFilterSearchObjects");
        }else{
            arrayToSearch = component.get("v.searchableArrays");
        }
        var finalSearchDataObj = {};
        for(var i = 0;i<arrayToSearch.length;i++){
            var filteredResult = [];
            var elementsToSearch = [];
            if(arrayToSearch[i] == 'addresses'){
                elementsToSearch = component.get("v.ResidenceSearch");
            }else if(arrayToSearch[i] == 'employments'){
                elementsToSearch = component.get("v.EmploymentSearch");
            }else if(arrayToSearch[i] == 'summaryReport'){
                //var elementsToSearch = component.get("v.ResidenceSearch");
            }else if(arrayToSearch[i] == 'registeredItems'){
                elementsToSearch = component.get("v.RegisteredItemSearch");
            }else if(arrayToSearch[i] == 'inquiries'){
                elementsToSearch = component.get("v.InquirySearch");
            }else if(arrayToSearch[i] == 'bankClosures'){
                elementsToSearch = component.get("v.BankingClosedForCauseSearch");
            }else if(arrayToSearch[i] == 'bankruptcies' || arrayToSearch[i] == 'consumerProposals'){
                elementsToSearch = component.get("v.BankruptcyAndInsolvencySearch");
            }else if(arrayToSearch[i] == 'loans' || arrayToSearch[i] == 'revolvingCreditAccounts' || arrayToSearch[i] == 'openCreditAccounts'){
                elementsToSearch = component.get("v.TradeSearch");
            }else if(arrayToSearch[i] == 'CreditHistoryOverview'){
                elementsToSearch = component.get("v.OverviewSearch");
            }else if(arrayToSearch[i] == 'remarks'){
                elementsToSearch = component.get("v.RemarksSearch");
            }else if(arrayToSearch[i] == 'legalItems'){
                elementsToSearch = component.get("v.LegalItemsSearch");
            }else if(arrayToSearch[i] == 'collections'){
                elementsToSearch = component.get("v.CollectionsSearch");
            }
            if (objHistory.hasOwnProperty(arrayToSearch[i])){
                var currentArray = objHistory[arrayToSearch[i]];
                for(var ind = 0; ind<currentArray.length; ind++){
                    var currentObj = currentArray[ind];
                    if(currentObj.hasOwnProperty('item')){
                        var isFoundInOtherObj = false;
                        if(currentObj.fromDate){
                            if(((currentObj.fromDate).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                searchedFieldsCount.push(searchInput.toUpperCase());
                                isFoundInOtherObj = true;
                                filteredResult.push(currentArray[ind]);
                                continue;
                            }
                        }
                        if(!isFoundInOtherObj){
                            var searchedFieldsCount = [];
                            for (var key in currentObj.item) {
                                var isNeedToSearch = false;
                                for(var elmInd = 0;elmInd < elementsToSearch.length; elmInd++){
                                    if(elementsToSearch[elmInd] == key){
                                        isNeedToSearch = true;
                                    }
                                }
                                if(isNeedToSearch && currentObj.item[key] && !searchedFieldsCount.includes(searchInput.toUpperCase())){
                                    if(((currentObj.item[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                        searchedFieldsCount.push(searchInput.toUpperCase());
                                        filteredResult.push(currentArray[ind]);
                                    } 
                                }  
                            }
                        }
                    }else{
                        var searchedFieldsCount = [];
                        for (var key in currentObj) {
                            var isNeedToSearch = false;
                            for(var elmInd = 0; elmInd<elementsToSearch.length; elmInd++){
                                if(elementsToSearch[elmInd] == key){
                                    isNeedToSearch = true;
                                }
                            }
                            if(isNeedToSearch && currentObj[key] && !searchedFieldsCount.includes(searchInput.toUpperCase())){
                                if(((currentObj[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                    searchedFieldsCount.push(searchInput.toUpperCase());
                                    filteredResult.push(currentArray[ind]);
                                } 
                            }  
                        }
                    }
                }
            }else if(arrayToSearch[i] == 'CreditHistoryOverview'){
                filteredResult = [];
                var objToSearch = component.get("v.OverviewSearch");
                for (var key in objHistory) {
                    var isNeedToSearch = false;
                    for(var elmInd = 0; elmInd< elementsToSearch.length; elmInd++){
                        if(elementsToSearch[elmInd] == key){
                            isNeedToSearch = true;
                        }
                    }
                    var isSearchedInChildObj = false;
                    if(objHistory.hasOwnProperty('name')){
                        if(objHistory.name.first != undefined || objHistory.name.last){
                            if(((objHistory.name.first).toString()).includes(searchInput.toUpperCase())){
                                isSearchedInChildObj = true;
                                filteredResult.push(objHistory);
                            }else if(((objHistory.name.last).toUpperCase()).includes(searchInput.toUpperCase())){
                                isSearchedInChildObj = true;
                                filteredResult.push(objHistory);
                            } 
                        }     
                    }
                    if(objHistory.phoneNumbers[0] != undefined && objHistory.phoneNumbers[0] != null && objHistory.phoneNumbers[0].applicantphoneNumber != undefined){
                        if(((objHistory.phoneNumbers[0].applicantphoneNumber).toUpperCase()).includes(searchInput.toUpperCase())){
                            isSearchedInChildObj = true;
                            filteredResult.push(objHistory);
                        }
                    }
                    if(objHistory.aliases[0] != undefined && objHistory.aliases[0] != null){
                        var innerArr = ['title','first','middle','last','suffix'];
                        for(var elmInd = 0; elmInd<innerArr.length; elmInd++){
                            if(objHistory.aliases[0][innerArr[elmInd]] != undefined && (objHistory.aliases[0][innerArr[elmInd]]).toUpperCase().includes(searchInput.toUpperCase())){
                                isSearchedInChildObj = true;
                                filteredResult.push(objHistory);
                            }
                        }
                        if(objHistory.aliases[0].title && ((objHistory.aliases[0].title).toUpperCase()).includes(searchInput.toUpperCase())){
                            isSearchedInChildObj = true;
                            filteredResult.push(objHistory);
                        }
                    }
                    if(objHistory.inquiries[0] != undefined && objHistory.inquiries[0] != null && objHistory.inquiries[0].eqDate != undefined){
                        if(((objHistory.inquiries[0].eqDate).toUpperCase()).includes(searchInput.toUpperCase())){
                            isSearchedInChildObj = true;
                            filteredResult.push(objHistory);
                        }
                    }
                    if(objToSearch.includes(key) && objHistory[key]){
                        if(isNeedToSearch){
                            if(((objHistory[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                filteredResult.push(objHistory);
                            } 
                        }
                    }  
                }
            }else if(arrayToSearch[i] == 'FileSummaryToSearch'){
                var summaryObj = objHistory.summaryReport;
                var isResultSearched = false;
                for (var key in summaryObj) {
                    if(key == 'bankruptcies' || key == 'legalItems' || key == 'collections' || key == 'bankClosures' || key == 'registeredItems' || key == 'inquiries'){
                        if(summaryObj[key]['eqDate']){
                            if(((summaryObj[key]['eqDate']).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                isResultSearched = true;
                                //break;
                            }
                        }else if(summaryObj[key]['count']){
                            if(((summaryObj[key]['count']).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                isResultSearched = true;
                                //break;
                            }
                        }
                    }else if(key == 'tradeSummaries'){
                        var searchedTradeSummary = [];
                        var tradeSummaryArray = summaryObj[key];
                        for(var tradeInd = 0; tradeInd<tradeSummaryArray.length;tradeInd++){
                            var isSearchedInRow = false;
                            for(var tardeKey in tradeSummaryArray[tradeInd]){
                                if(tradeSummaryArray[tradeInd][tardeKey]){
                                    if(!isSearchedInRow && ((tradeSummaryArray[tradeInd][tardeKey]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                        var objectToIterate = tradeSummaryArray[tradeInd];
                                        var objData = {};
                                        objData.balance = (objectToIterate.balance).toString();
                                        if(objectToIterate.highCredit != undefined){
                                            objData.highCredit = (objectToIterate.highCredit).toString();
                                        }else{
                                            objData.highCredit = '-';
                                        }
                                        
                                        if(objectToIterate.fileSummarytype != undefined){
                                            objData.fileSummarytype = objectToIterate.fileSummarytype;
                                        }else{
                                            objData.highCredit = '-';
                                        }
                                        if(objectToIterate.creditLimit != undefined){
                                            objData.creditLimit = (objectToIterate.creditLimit).toString();
                                        }else{
                                            objData.creditLimit = '-';
                                        }
                                        //Changed available into percentage
                                        if(objectToIterate.available != undefined){
                                            objData.available = (Math.round(objectToIterate.available* 100)).toString() + '%';
                                        }else{
                                            objData.available = '-';
                                        }
                                        objData.count = (objectToIterate.count).toString();
                                        objData.pastDue = (objectToIterate.pastDue).toString();
                                        objData.payment = (objectToIterate.payment).toString();
                                        
                                        searchedTradeSummary.push(objData);
                                        isSearchedInRow = true;
                                        isResultSearched = true;
                                        continue;
                                    }
                                }
                            }    
                        }
                        component.set("v.FileSummaryData",searchedTradeSummary);
                    }else{
                        if(summaryObj[key] && ((summaryObj[key]).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                            isResultSearched = true;
                            //break;
                        }
                    }
                }
                if(!isResultSearched && objHistory && objHistory.creditScores && objHistory.creditScores.TU_RISK){
                    if(objHistory.creditScores.TU_RISK.score && ((objHistory.creditScores.TU_RISK.score).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                        isResultSearched = true;
                    }
                    if(!isResultSearched && objHistory.creditScores.TU_RISK.factors.length > 0){
                        for(var ex=0;ex<objHistory.creditScores.TU_RISK.factors.length; ex++){
                            if(((objHistory.creditScores.TU_RISK.factors[ex].code).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                isResultSearched = true;
                            }
                            if(((objHistory.creditScores.TU_RISK.factors[ex].description).toString().toUpperCase()).includes(searchInput.toUpperCase())){
                                isResultSearched = true;
                            }
                        }
                    }
                }
                if(isResultSearched){
                    filteredResult.push(summaryObj);
                }
            }
            finalSearchDataObj[arrayToSearch[i]] = filteredResult;
        }
        helper.setFilteredData(component, event, helper,finalSearchDataObj);
    },
    setFilteredData : function(component, event, helper,filteredData) {
        component.set("v.isNoResultFound",false);
        var activeSectionsToShow = [];
        var isResultFound = false;
        Object.keys(filteredData).forEach(function(key) {
            if(filteredData[key]){
                if(key == 'addresses'){
                    var objectToIterate = filteredData[key];
                    dataTableArray = [];
                    for(var i=0; i <objectToIterate.length;i++){
                        var objData = {};
                        if(objectToIterate[i].item.civic || objectToIterate[i].item.streetType || objectToIterate[i].item.streetName){
                            objData.streetName = objectToIterate[i].item.civic+' '+objectToIterate[i].item.streetType+' '+objectToIterate[i].item.streetName;
                        }else{
                            objData.streetName = '-';
                        }
                        if(objectToIterate[i].item.city){
                            objData.city = objectToIterate[i].item.city;
                        }else{
                            objData.city = '-';
                        }
                        if(objectToIterate[i].item.province){
                            objData.province = objectToIterate[i].item.province;
                        }else{
                            objData.province = '-';
                        }
                        if(objectToIterate[i].item.postalCode){
                            objData.postalCode = objectToIterate[i].item.postalCode;
                        }else{
                            objData.postalCode = '-';
                        }
                        if(objectToIterate[i].fromDate){
                            objData.fromDate = objectToIterate[i].fromDate;
                        }else{
                            objData.fromDate = '-';
                        }
                        dataTableArray.push(objData);
                    }
                    component.set("v.ResidenceData",dataTableArray);
                    if(filteredData[key].length < 1){
                        component.set("v.residenceAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("B");
                        isResultFound = true;
                        component.set("v.residenceAcordian",'slds-show');                        
                    }
                }else if(key == 'tradeSummaries'){
                    //component.set("v.FileSummaryData",filteredData[key]);
                    if(filteredData[key].length < 1){
                        //component.set("v.IDMismatchAcordian",'slds-hide');
                    }
                }else if(key == 'registeredItems'){
                    component.set("v.registeredItems",filteredData[key]);
                    if(filteredData[key].length < 1){
                        component.set("v.RegisteredItemsAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("G");
                        isResultFound = true;
                        component.set("v.RegisteredItemsAcordian",'slds-show');
                    }
                }else if(key == 'bankruptcies' || key == 'consumerProposals'){
                    dataTableArray = [];
                    var tradeUnionArray = ['consumerProposals', 'bankruptcies'];
                    for(var ind=0; ind <tradeUnionArray.length;ind++){
                        if(filteredData[tradeUnionArray[ind]].length > 0){
                            dataTableArray.push(filteredData[tradeUnionArray[ind]]);    
                        }
                    }
                    component.set("v.bankruptcies",dataTableArray);
                    if(dataTableArray.length < 1){
                        component.set("v.BankruptcyAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("H");
                        isResultFound = true;
                        component.set("v.BankruptcyAcordian",'slds-show');
                    }
                }else if(key == 'inquiries'){
                    component.set("v.Inquirydata",filteredData[key]);
                    if(filteredData[key].length < 1){
                        component.set("v.InquiriesAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("K");
                        isResultFound = true;
                        component.set("v.InquiriesAcordian",'slds-show');
                    }
                }else if(key == 'creditHistory'){
                    /*component.set("v.CreditData",filteredData[key]);
                    if(filteredData[key].length < 1){
                        component.set("v.residenceAcordian",'slds-hide');
                    }else{
                        isResultFound = true;
                        component.set("v.residenceAcordian",'slds-show');
                    }*/
                }else if(key == 'employments'){
                    var dataTableArray = [];
                    var objectToIterate = filteredData[key];
                    for(var i=0; i <objectToIterate.length;i++){
                        var objData = {};
                        if(objectToIterate[i].fromDate){
                            objData.fromDate = objectToIterate[i].fromDate;
                        }else{
                            objData.fromDate = '-';
                        }
                        if(objectToIterate[i].to){
                            objData.to = objectToIterate[i].to;
                        }else{
                            objData.to = '-';
                        }
                        if(objectToIterate[i].item.companyName){
                            objData.companyName = objectToIterate[i].item.companyName;
                        }else{
                            objData.companyName = '-';
                        }
                        if(objectToIterate[i].item.position){
                            objData.position = objectToIterate[i].item.position;
                        }else{
                            objData.position = '-';
                        }
                        if(objectToIterate[i].item.paySchedule){
                            objData.paySchedule = objectToIterate[i].item.paySchedule;
                        }else{
                            objData.paySchedule = '-';
                        }
                        //Change in payperiod, included .toFixed in place of .toString..
                        if(objectToIterate[i].item.payPerPeriod){
                            //uncommented below so that Wage column field can be fetched after search
                            objData.payPerPeriod = ((objectToIterate[i].item.payPerPeriod).toFixed(2)).toString();
                        }else{
                            objData.payPerPeriod = '-';
                        }
                        dataTableArray.push(objData);
                    }
                    component.set("v.EmploymentData",dataTableArray);
                    if(filteredData[key].length < 1){
                        component.set("v.EmploymentAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("C");
                        isResultFound = true;
                        component.set("v.EmploymentAcordian",'slds-show');
                    }
                }else if(key == 'summaryReport'){
                    /*component.set("v.FileSummaryData",filteredData[key]);
                    if(filteredData[key].length < 1){
                        component.set("v.IDMismatchAcordian",'slds-hide');
                    }*/
                }else if(key == 'CreditHistoryOverview'){
                    if(filteredData[key].length > 0){
                        component.set("v.CreditHistoryOverview",filteredData[key][0]);
                        component.set("v.OverviewAcordian",'slds-show');
                        isResultFound = true;
                        activeSectionsToShow.push("A");
                    }else{
                        component.set("v.CreditHistoryOverview",[]);
                        component.set("v.OverviewAcordian",'slds-hide');
                    }
                }else if(key == 'FileSummaryToSearch'){
                    if(filteredData[key].length > 0){
                        component.set("v.FileSummaryReport",filteredData[key][0]);
                        component.set("v.IDMismatchAcordian",'slds-show');
                        isResultFound = true;
                        activeSectionsToShow.push("D");
                    }else{
                        if(component.get("v.FileSummaryReport").length > 0){
                            component.set("v.FileSummaryReport",filteredData[key][0]);
                            component.set("v.IDMismatchAcordian",'slds-show');
                            isResultFound = true;
                            activeSectionsToShow.push("D");
                        }else{
                            component.set("v.FileSummaryReport",[]);
                            component.set("v.IDMismatchAcordian",'slds-hide');
                        }
                    }
                }else if(key == 'bankClosures'){
                    objectToIterate = filteredData[key];
                    dataTableArray = [];
                    for(var i=0; i <objectToIterate.length;i++){
                        var objData = {};
                        if(objectToIterate[i].dateVerified){
                            objData.dateVerified = objectToIterate[i].dateVerified;
                        }else{
                            objData.dateVerified = '-';
                        }
                        if(objectToIterate[i].subscriberName){
                            objData.subscriberName = objectToIterate[i].subscriberName;
                        }else{
                            objData.subscriberName = '-';
                        }
                        if(objectToIterate[i].dateOpened){
                            objData.dateOpened = objectToIterate[i].dateOpened;
                        }else{
                            objData.dateOpened = '-';
                        }
                        if(objectToIterate[i].dateClosed){
                            objData.dateClosed = objectToIterate[i].dateClosed;
                        }else{
                            objData.dateClosed = '-';
                        }
                        if(objectToIterate[i].reason){
                            objData.reason = objectToIterate[i].reason;
                        }else{
                            objData.reason = '-';
                        }
                        if(objectToIterate[i].industryCode){
                            objData.industryCode = objectToIterate[i].industryCode;
                        }else{
                            objData.industryCode = '-';
                        }
                        if(objectToIterate[i].balance){
                            objData.balance = (objectToIterate[i].balance).toString();
                            console.log('-----Balance ---',objData.balance);
                        }else{
                            objData.balance = '-';
                            console.log('-----Balance ---else',objData.balance);
                        }
                        dataTableArray.push(objData);
                    }
                    
                    component.set("v.BankingClosedForCauseData",dataTableArray);
                    if(filteredData[key].length < 1){
                        component.set("v.BankingClosedAcordian",'slds-hide');
                    }else{
                        isResultFound = true;
                        activeSectionsToShow.push("E");
                        component.set("v.BankingClosedAcordian",'slds-show');
                    }
                }else if(key == 'loans' || key == 'revolvingCreditAccounts' ||key == 'openCreditAccounts'){
                    var tradeUnionArray = ['loans', 'openCreditAccounts','revolvingCreditAccounts'];
                    dataTableArray = [];
                    for(var ind=0; ind <tradeUnionArray.length;ind++){
                        var objectToIterate = filteredData[tradeUnionArray[ind]];
                        //(objectToIterate);
                        for(var i=0; i <objectToIterate.length;i++){
                            var objData = {};
                            if(objectToIterate[i].openedOn){
                                objData.openedOn = objectToIterate[i].openedOn;
                            }else{
                                objData.openedOn = '-';
                            }
                            if(objectToIterate[i].description){
                                objData.description = objectToIterate[i].description;
                            }else{
                                objData.description = '-';
                            }
                            if(objectToIterate[i].creditor){
                                objData.creditor = objectToIterate[i].creditor;
                            }else{
                                objData.creditor = '-';
                            }
                            if(objectToIterate[i].paymentPattern){
                                objData.paymentPattern = objectToIterate[i].paymentPattern;
                            }else{
                                objData.paymentPattern = '-';
                            }
                            if(objectToIterate[i].industryCode){
                                objData.industryCode = objectToIterate[i].industryCode;
                            }else{
                                objData.industryCode = '-';
                            }
                            if(objectToIterate[i].accountNumber){
                                objData.accountNumber = objectToIterate[i].accountNumber;
                            }else{
                                objData.accountNumber = '-';
                            }
                            if(objectToIterate[i].mop || objectToIterate[i].status){
                                objData.mop = objectToIterate[i].mop+' '+objectToIterate[i].status;
                            }else{
                                objData.mop = '-';
                            }
                            if(objectToIterate[i].lastActivity){
                                objData.lastActivity = objectToIterate[i].lastActivity;
                            }else{
                                objData.lastActivity = '-';
                            }
                            if(objectToIterate[i].openingBalance != undefined){
                                objData.openingBalance = (objectToIterate[i].openingBalance).toString();
                            }else if(objectToIterate[i].historicalMaxBalance != undefined){
                                objData.openingBalance = (objectToIterate[i].historicalMaxBalance).toString();
                            }else if(objectToIterate[i].creditLimit != undefined){
                                objData.openingBalance = (objectToIterate[i].creditLimit).toString();
                            }else{
                                objData.openingBalance = '-';
                            }
                            if(objectToIterate[i].paymentAmount.toString()){
                                objData.paymentAmount = (objectToIterate[i].paymentAmount).toString();
                            }else{
                                objData.paymentAmount = '-';
                            }
                            if(objectToIterate[i].paymentPatternStart){
                                objData.paymentPatternStart = objectToIterate[i].paymentPatternStart;
                            }else{
                                objData.paymentPatternStart = '-';
                            }
                            if(objectToIterate[i].amountPastDue.toString()){
                                objData.amountPastDue = (objectToIterate[i].amountPastDue).toString();
                            }else{
                                objData.amountPastDue = '-';
                            }
                            if(objectToIterate[i].payments30DaysLate || objectToIterate[i].payments60DaysLate ||
                               objectToIterate[i].payments90DaysLate || objectToIterate[i].monthsReviewed){
                                var a= objectToIterate[i].payments30DaysLate;
                                var b= objectToIterate[i].payments60DaysLate;
                                var c= objectToIterate[i].payments90DaysLate;
                                var d= objectToIterate[i].monthsReviewed;
                                objData.monthsReviewed = a+'/'+''+b+'/'+''+c+'/'+''+d;
                            }else{
                                objData.monthsReviewed = '-';
                            }
                            if(objectToIterate[i].paymentAmount || objectToIterate[i].paymentSchedule){
                                var a1= objectToIterate[i].paymentAmount;
                                var b1= objectToIterate[i].paymentSchedule;
                                objData.paymentSchedule = a1+'/'+''+b1;
                            }else{
                                objData.paymentSchedule = '-';
                            }
                            dataTableArray.push(objData);
                        }
                    }
                    component.set("v.TradeData",dataTableArray);
                    if(dataTableArray.length < 1){
                        component.set("v.TradeAcordian",'slds-hide');
                    }else{
                        isResultFound = true;
                        activeSectionsToShow.push("F");
                        component.set("v.TradeAcordian",'slds-show');
                    }
                }else if(key == 'collections'){
                    var dataTableArray = [];
                    for(var i=0; i <filteredData[key].length;i++){
                        var objData = filteredData[key][i];
                        if((filteredData[key][i]).payOutDate != null && (filteredData[key][i]).payOutDate.toString() != ''){
                            objData.payOutDate = (filteredData[key][i]).payOutDate.toString();
                        }else{
                            objData.payOutDate = '-';
                        }
                        if((filteredData[key][i]).originalAmount != null && (filteredData[key][i]).originalAmount.toString() != ''){
                            objData.originalAmount = (filteredData[key][i]).originalAmount.toString();
                        }else{
                            objData.originalAmount = '-';
                        }
                        if((filteredData[key][i]).currentBalance != null && (filteredData[key][i]).currentBalance.toString() != ''){
                            objData.currentBalance = (filteredData[key][i]).currentBalance.toString();
                        }else{
                            objData.currentBalance = '-';
                        }
                        if((filteredData[key][i]).revisedDate){
                            objData.revisedDate = (filteredData[key][i]).revisedDate;
                        }else{
                            objData.revisedDate = '-';
                        }
                        if((filteredData[key][i]).reportedDate){
                            objData.reportedDate = (filteredData[key][i]).reportedDate;
                        }else{
                            objData.reportedDate = '-';
                        }
                        if((filteredData[key][i]).creditorName){
                            objData.creditorName = (filteredData[key][i]).creditorName;
                        }else{
                            objData.creditorName = '-';
                        }
                        if((filteredData[key][i]).narrative){
                            objData.narrative = (filteredData[key][i]).narrative;
                        }else{
                            objData.narrative = '-';
                        }
                        dataTableArray.push(objData);
                    }
                    component.set("v.CollectionsData",dataTableArray);
                    if(filteredData[key].length < 1){
                        component.set("v.CollectionsAcordian",'slds-hide');
                    }else{
                        activeSectionsToShow.push("J");
                        isResultFound = true;
                        component.set("v.CollectionsAcordian",'slds-show');
                    }
                }else if(key == 'remarks'){
                    component.set("v.RemarksData",filteredData[key]);
                    if(filteredData[key].length < 1){
                        component.set("v.RemarksAcordian",'slds-hide');
                    }else{
                        isResultFound = true;
                        activeSectionsToShow.push("L");
                        component.set("v.RemarksAcordian",'slds-show');
                    }
                }else if(key == 'legalItems'){
                    var dataTableArray = [];
                    for(var i=0; i <filteredData[key].length;i++){
                        var objData = filteredData[key][i];//revisedDate
                        if(filteredData[key][i].revisedDate != undefined || filteredData[key][i].revisedDate != null){
                            objData.revisedDate = filteredData[key][i].revisedDate;
                        }else{
                            objData.revisedDate = '-';
                        }
                        if(filteredData[key][i].dateSettled != undefined || filteredData[key][i].dateSettled != null){
                            objData.dateSettled = filteredData[key][i].dateSettled;
                        }else{
                            objData.dateSettled = '-';
                        }
                        //added new field --> narrative
                        if(filteredData[key][i].narrative != undefined || filteredData[key][i].narrative != null){
                            objData.narrative = filteredData[key][i].narrative;
                        }else{
                            objData.narrative = '-';
                        }
                        if(filteredData[key][i].amount != undefined || filteredData[key][i].amount != null){
                            objData.amount = filteredData[key][i].amount.toString();
                        }else{
                            objData.amount = '-';
                        }
                        if(filteredData[key][i].balance != undefined || filteredData[key][i].balance != null){
                            objData.balance = filteredData[key][i].balance.toString();
                        }else{
                            objData.balance = '--';
                        }
                        dataTableArray.push(objData);
                    }
                    component.set("v.LegalItemsData",dataTableArray);
                    if(filteredData[key].length < 1){
                        component.set("v.LegalItemsAcordian",'slds-hide');
                    }else{
                        isResultFound = true;
                        activeSectionsToShow.push("I");
                        component.set("v.LegalItemsAcordian",'slds-show');
                    }
                }
            }
        });
        if(!isResultFound){
            component.set("v.isNoResultFound",true);
            helper.hideAllAccordianTabs(component, event, helper,false);
            //component.set("v.isDisabled",true);
            //component.set("v.isDisabledPostCP",true);
            //component.set("v.IDMismatchAcordian",'slds-hide');
        }else{
            //component.set("v.isDisabled",false);
            //component.set("v.isDisabledPostCP",false);
            
            // component.set("v.IDMismatchAcordian",'slds-show');
        }
        //console.log(component.find("accordion").get('v.activeSectionName'));
        setTimeout(function(){ 
            if(component.get("v.applicantType") == 'BORROWER'){
                component.find("accordion").set('v.activeSectionName', activeSectionsToShow);
            }else if(component.get("v.applicantType") == 'COBORROWER'){
                component.find("accordionCo").set('v.activeSectionName', activeSectionsToShow);
            }else if(component.get("v.applicantType") == 'COSIGNER'){
                component.find("accordionSig").set('v.activeSectionName', activeSectionsToShow);
            }
            //
        }, 100);
        console.log("----finel result----");
    },
    hideAllAccordianTabs : function (component, event, helper,isShow){
        if(isShow){
            component.set("v.IDMismatchAcordian",'slds-show');
            component.set("v.TradeAcordian",'slds-show');
            component.set("v.residenceAcordian",'slds-show');
            component.set("v.EmploymentAcordian",'slds-show');
            component.set("v.BankingClosedAcordian",'slds-show');
            component.set("v.RegisteredItemsAcordian",'slds-show');
            component.set("v.BankruptcyAcordian",'slds-show');
            component.set("v.InquiriesAcordian",'slds-show');
            component.set("v.OverviewAcordian",'slds-show');
            component.set("v.LegalItemsAcordian",'slds-show');
            component.set("v.CollectionsAcordian",'slds-show');
            component.set("v.RemarksAcordian",'slds-show');
        }else{
            component.set("v.IDMismatchAcordian",'slds-hide');
            component.set("v.TradeAcordian",'slds-hide');
            component.set("v.residenceAcordian",'slds-hide');
            component.set("v.EmploymentAcordian",'slds-hide');
            component.set("v.BankingClosedAcordian",'slds-hide');
            component.set("v.RegisteredItemsAcordian",'slds-hide');
            component.set("v.BankruptcyAcordian",'slds-hide');
            component.set("v.InquiriesAcordian",'slds-hide');
            component.set("v.OverviewAcordian",'slds-hide');
            component.set("v.LegalItemsAcordian",'slds-hide');
            component.set("v.CollectionsAcordian",'slds-hide');
            component.set("v.RemarksAcordian",'slds-hide');
        }
        
    },
    showCombineFilterResults : function (component, event, helper){
        var activeSeactionsName = [];
        var isResultFound = false;
        var creditData = component.get("v.CreditData");
        var allFilterSearchObjects = [];
        var MoreThan3InquiriesInThePast6Months = creditData.insights.warnings.inquiriesSixMonthsOverMax;
        var CreditSoughtDuringConsumerProposal = creditData.insights.cp.inquiriesDuring;
        var CreditObtainedDuringConsumerProposal = creditData.insights.cp.creditDuring;
        var PaydayLoans = creditData.insights.warnings.paydayLoans;
        var DebtServiceRatioOver50Percent = creditData.insights.dsr.overMax;
        /*component.set("v.OverviewAcordian",'slds-hide');
        component.set("v.LegalItemsAcordian",'slds-hide');
        component.set("v.RegisteredItemsAcordian",'slds-hide');
        component.set("v.RemarksAcordian",'slds-hide');
        component.set("v.BankingClosedAcordian",'slds-hide');*/
        var creditData = component.get("v.CreditData");
        var creditHistory = creditData.creditHistory;
        /*if(MoreThan3InquiriesInThePast6Months == true || CreditSoughtDuringConsumerProposal == true){
                component.set("v.InquiriesAcordian",'slds-show');
                objToFilter.push('inquiries');
                isResultFound = true;
            } else {
                component.set("v.InquiriesAcordian",'slds-hide');
            } */
        if(CreditObtainedDuringConsumerProposal == true || PaydayLoans == true || DebtServiceRatioOver50Percent == true){
            var tradeUnionArray = ['loans', 'openCreditAccounts','revolvingCreditAccounts'];
            dataTableArray = [];
            for(var ind=0; ind <tradeUnionArray.length;ind++){
                objectToIterate = [];
                if(creditHistory[tradeUnionArray[ind]] != undefined && creditHistory[tradeUnionArray[ind]] != null){
                    objectToIterate = creditHistory[tradeUnionArray[ind]];
                }
                for(var i=0; i <objectToIterate.length;i++){
                    if(objectToIterate[i].postCP != undefined && objectToIterate[i].postCP == true){
                        var objData = {};
                        objData.openedOn = objectToIterate[i].openedOn;
                        objData.description = objectToIterate[i].description;
                        objData.creditor = objectToIterate[i].creditor;
                        objData.paymentPattern = objectToIterate[i].paymentPattern;
                        objData.industryCode = objectToIterate[i].industryCode;
                        objData.accountNumber = objectToIterate[i].accountNumber;
                        objData.mop = objectToIterate[i].mop+' '+objectToIterate[i].status;
                        objData.lastActivity = objectToIterate[i].lastActivity;
                        if(objectToIterate[i].openingBalance != undefined){
                            objData.openingBalance = (objectToIterate[i].openingBalance).toString();
                        }else if(objectToIterate[i].historicalMaxBalance != undefined){
                            objData.openingBalance = (objectToIterate[i].historicalMaxBalance).toString();
                        }else if(objectToIterate[i].creditLimit != undefined){
                            objData.openingBalance = (objectToIterate[i].creditLimit).toString();
                        }
                        objData.paymentAmount = (objectToIterate[i].paymentAmount).toString();
                        objData.paymentPatternStart = objectToIterate[i].paymentPatternStart;
                        var a= objectToIterate[i].payments30DaysLate;
                        var b= objectToIterate[i].payments60DaysLate;
                        var c= objectToIterate[i].payments90DaysLate;
                        var d= objectToIterate[i].monthsReviewed;
                        objData.amountPastDue = (objectToIterate[i].amountPastDue).toString();
                        objData.monthsReviewed = a+'/'+''+b+'/'+''+c+'/'+''+d;
                        var a1= objectToIterate[i].paymentAmount;
                        var b1= objectToIterate[i].paymentSchedule;
                        objData.paymentSchedule = a1+'/'+''+b1;
                        dataTableArray.push(objData);
                    }
                }
            }
            component.set("v.TradeData",dataTableArray);
            if(dataTableArray.length > 0){
                component.set("v.TradeAcordian",'slds-show');
                isResultFound = true;
                allFilterSearchObjects.push('loans');
                allFilterSearchObjects.push('revolvingCreditAccounts');
                allFilterSearchObjects.push('openCreditAccounts');
                activeSeactionsName.push("F");
            }else{
                component.set("v.TradeAcordian",'slds-hide');
            }
        }else {
            component.set("v.TradeAcordian",'slds-hide');
        }
        var objectToIterate = creditHistory.inquiries;
        var dataTableArray = [];
        if(MoreThan3InquiriesInThePast6Months == true || CreditSoughtDuringConsumerProposal == true){
            for(var i=0; i <objectToIterate.length;i++){
                var objData = {};
                if(objectToIterate[i].postCP != undefined && objectToIterate[i].postCP == true){
                    
                    objData.eqDate = objectToIterate[i].eqDate;
                    objData.industryCode = objectToIterate[i].industryCode;
                    objData.inquirerName = objectToIterate[i].inquirerName;
                    objData.subscriberCode = objectToIterate[i].subscriberCode;
                    dataTableArray.push(objData);
                }
            }
            component.set("v.Inquirydata",dataTableArray);
            if(dataTableArray.length > 0){
                allFilterSearchObjects.push('inquiries');
                component.set("v.InquiriesAcordian",'slds-show');
                isResultFound = true;
                activeSeactionsName.push("K");
            }else{
                component.set("v.InquiriesAcordian",'slds-hide');
            }
        } else {
            component.set("v.InquiriesAcordian",'slds-hide');
        }        
        component.set("v.isAllFilterActivate",true);
        component.set("v.allFilterSearchObjects",allFilterSearchObjects);
        helper.showAllAccordions(component, event, helper, false);
        setTimeout(function(){
            component.set("v.activeSections",activeSeactionsName);
            component.find("accordion").set('v.activeSectionName', activeSeactionsName);
        }, 30);
    },
    renderTableVisibility : function(component, event, helper) {
        var activeSeactionsName = [];
        var value = component.get('v.filterReport');
        if (value == true) {
            var isResultFound = false;
            component.set("v.FilteredObjects",[]);
            var objToFilter = component.get("v.FilteredObjects");
            var creditData = component.get("v.CreditData");
            var MoreThan3InquiriesInThePast6Months = creditData.insights.warnings.inquiriesSixMonthsOverMax;
            var JobTenureUnderOneYear = creditData.insights.employment.tenureUnderMin;
            var IncomeUnder2000PerMonth = creditData.insights.employment.payUnderMin;
            var ConsumerProposalAgeUnderOneYear = creditData.insights.cp.durationUnderMin;
            var ConsumerProposalBalanceOver15000 = creditData.insights.cp.estimatedAmountOverLimit ;
            var NotInConsumerProposal = creditData.insights.cp.since;
            var CreditSoughtDuringConsumerProposal = creditData.insights.cp.inquiriesDuring;
            var CreditObtainedDuringConsumerProposal = creditData.insights.cp.creditDuring;
            var ResidenceTenureUnderOneYear = creditData.insights.residence.durationUnderMin;
            var PaydayLoans = creditData.insights.warnings.paydayLoans;
            var IDMismatchWarnings = creditData.insights.warnings.idMismatch;
            var HighRiskFraudAlerts = creditData.insights.warnings.fraud;
            var NoCreditScore = creditData.insights.warnings.noCreditScore;
            var CreditScoreUnder500 = creditData.insights.warnings.creditScoreUnderMin;
            var DebtInCollections = creditData.insights.warnings.unpaidCollections;
            var DebtServiceRatioOver50Percent = creditData.insights.dsr.overMax;
            var BankClosed = creditData.creditHistory.bankClosures;
            component.set("v.OverviewAcordian",'slds-hide');
            component.set("v.LegalItemsAcordian",'slds-hide');
            component.set("v.RegisteredItemsAcordian",'slds-hide');
            component.set("v.RemarksAcordian",'slds-hide');
            component.set("v.BankingClosedAcordian",'slds-hide');
            if(BankClosed != undefined && BankClosed.length > 0){
                component.set("v.BankingClosedAcordian",'slds-show');
                objToFilter.push('bankClosures');
                isResultFound = true;
                activeSeactionsName.push("E");
            }else{
                component.set("v.BankingClosedAcordian",'slds-hide');
            }
            if(MoreThan3InquiriesInThePast6Months == true || CreditSoughtDuringConsumerProposal == true){
                component.set("v.InquiriesAcordian",'slds-show');
                objToFilter.push('inquiries');
                isResultFound = true;
                activeSeactionsName.push("K");
            } else {
                component.set("v.InquiriesAcordian",'slds-hide');
            }
            if(JobTenureUnderOneYear == true || IncomeUnder2000PerMonth == true){
                component.set("v.EmploymentAcordian",'slds-show');
                objToFilter.push('employments');
                isResultFound = true;
                activeSeactionsName.push("C");
            } else {
                component.set("v.EmploymentAcordian",'slds-hide');
            }
            if(NotInConsumerProposal == null || ConsumerProposalAgeUnderOneYear == true || ConsumerProposalBalanceOver15000 == true){
                component.set("v.BankruptcyAcordian",'slds-show');
                objToFilter.push('bankruptcies');
                objToFilter.push('consumerProposals');
                isResultFound = true;
                activeSeactionsName.push("H");
            }else {
                component.set("v.BankruptcyAcordian",'slds-hide');
            }
            if(CreditObtainedDuringConsumerProposal == true || PaydayLoans == true || DebtServiceRatioOver50Percent == true){
                component.set("v.TradeAcordian",'slds-show');
                isResultFound = true;
                objToFilter.push('loans');
                objToFilter.push('revolvingCreditAccounts');
                objToFilter.push('openCreditAccounts');
                activeSeactionsName.push("F");
            }else {
                component.set("v.TradeAcordian",'slds-hide');
            }
            if(ResidenceTenureUnderOneYear == true){
                component.set("v.residenceAcordian",'slds-show');
                isResultFound = true;
                objToFilter.push('addresses');
                activeSeactionsName.push("B");
            } else{
                component.set("v.residenceAcordian",'slds-hide');
            }
            /*var PoorMortgagePaymentHistory = creditData.residence.mortgage.latePayments;
                if(PoorMortgagePaymentHistory == true){
                    component.set("v.PoorMortgagePaymentHistory", "slds-show");
                }*/
            if(IDMismatchWarnings == true || HighRiskFraudAlerts == true || NoCreditScore == true || CreditScoreUnder500 == true){
                component.set("v.IDMismatchAcordian",'slds-show');
                isResultFound = true;
                objToFilter.push('summaryReport');
                objToFilter.push('FileSummaryToSearch');
                activeSeactionsName.push("D");
            }else {
                component.set("v.IDMismatchAcordian",'slds-hide');
            }
            
            if(DebtInCollections == true){
                component.set("v.CollectionsAcordian",'slds-show');
                isResultFound = true;
                objToFilter.push('collections');
                activeSeactionsName.push("J");
            }else {
                component.set("v.CollectionsAcordian",'slds-hide');
            }
        }else if (value == false) {
            isResultFound = false;
            component.set("v.isFilterActivate",false);
        }
        if(isResultFound){
            component.set("v.isFilterActivate",true);
            component.set("v.FilteredObjects",objToFilter);
        }else{
            
        }
        helper.hideAllOtherTabs(component, event, helper, isResultFound);
        setTimeout(function(){
            component.set("v.activeSections",activeSeactionsName);
            component.find("accordion").set('v.activeSectionName', activeSeactionsName);
        }, 50);
    },
    hideAllOtherTabs : function(component, event, helper, isHide) {
        if(isHide){
            component.set("v.OverviewAcordian",'slds-hide');
            component.set("v.LegalItemsAcordian",'slds-hide');
            component.set("v.RegisteredItemsAcordian",'slds-hide');
            component.set("v.RemarksAcordian",'slds-hide');
            //component.set("v.BankingClosedAcordian",'slds-hide');
        }else{
            component.set("v.IDMismatchAcordian",'slds-show');
            component.set("v.TradeAcordian",'slds-show');
            component.set("v.residenceAcordian",'slds-show');
            component.set("v.EmploymentAcordian",'slds-show');
            component.set("v.BankingClosedAcordian",'slds-show');
            component.set("v.RegisteredItemsAcordian",'slds-show');
            component.set("v.BankruptcyAcordian",'slds-show');
            component.set("v.InquiriesAcordian",'slds-show');
            component.set("v.OverviewAcordian",'slds-show');
            component.set("v.LegalItemsAcordian",'slds-show');
            component.set("v.CollectionsAcordian",'slds-show');
            component.set("v.RemarksAcordian",'slds-show');
        }
    },
    
    getHardPullData : function(component, event, helper) {
        //('----getHardPullData start----');
        component.set('v.postCP',false);
        component.set("v.insightSection","slds-hide");
        component.set('v.filterReport',false);
        component.set("v.isPostCpFilterActivate",false);
        component.set("v.isFilterActivate",false);
        component.set("v.isAllFilterActivate",false);
        var action = component.get("c.initiateHardPull");
        var recId = component.get("v.recordId");
        var applicantType = component.get("v.applicantType");
        action.setParams({
            appId: component.get("v.recordId"),
            appType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            var returnResponse = response.getReturnValue();
            if(state === 'SUCCESS') {
                if(returnResponse != null && returnResponse.HardPullWrapper){
                    var creditData = returnResponse.HardPullWrapper;
                    component.set("v.currentActiveReportname","full");
                    if(creditData != null && creditData.creditHistory != undefined){
                        helper.showAllAccordions(component, event, helper, true);
                        component.set("v.CreditData",creditData);
                        var hit = creditData.creditHistory.hit;
                        component.set("v.isHitEnable",hit);
                        console.log('hit value: ',hit);
                        if (!hit) {
                            component.set("v.isDisabled",true);
                            component.set("v.isDisabledPostCP",true);
                            component.set("v.HitErrorMessageEnable", true);
                            component.set("v.HitErrorMessage",'slds-show');
                            console.log('JSON structure is incorrect');
                            component.set("v.IDMismatchAcordian",'slds-hide');
                            component.set("v.TradeAcordian",'slds-hide');
                            component.set("v.residenceAcordian",'slds-hide');
                            component.set("v.EmploymentAcordian",'slds-hide');
                            component.set("v.BankingClosedAcordian",'slds-hide');
                            component.set("v.RegisteredItemsAcordian",'slds-hide');
                            component.set("v.BankruptcyAcordian",'slds-hide');
                            component.set("v.InquiriesAcordian",'slds-hide');
                            component.set("v.OverviewAcordian",'slds-hide');
                            component.set("v.LegalItemsAcordian",'slds-hide');
                            component.set("v.CollectionsAcordian",'slds-hide');
                            component.set("v.RemarksAcordian",'slds-hide');
                            //component.set("v.loading",false);
                        }else if(hit){
                            component.set("v.HitErrorMessageEnable", false);
                            component.set("v.errorMessage",'');
                            component.set("v.HitErrorMessage",'slds-hide');
                            var jsonDate = creditData.creditHistory.pulledAt;
                            //var overViewDate = ($A.localizationService.formatDate(jsonDate,"yyyy-MM-dd"));
                            //component.set("v.OverviewDate",overViewDate);
                            helper.convertToDatatableData(component, event, helper);
                            helper.showToast(component, event, helper,"New Full report pulled","success");
                            //component.set("v.loading",false);
                            component.set("v.isDisabled",false);
                            component.set("v.isDisabledPostCP",false);
                        }
                        component.set("v.loading",false);
                        if(returnResponse.isHardPull != undefined && returnResponse.isHardPull == true){
                            helper.setinsightFieldsValue(component, event, helper);
                        }
                        helper.getCreditRecordDates(component, event, helper);
                        
                    }else{
                        helper.showToast(component, event, helper,"Unable to read JSON data","error");
                    }
                    component.set("v.loading",false);
                }else if(returnResponse.error){
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,returnResponse.error,"error");
                    helper.handleErrorblock(component, event, helper);
                }else{
                    component.set("v.loading",false);
                    helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                    helper.handleErrorblock(component, event, helper);
                }
            }else if (status == "INCOMPLETE") {
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"No response from server or client is offline.","error");
                helper.handleErrorblock(component, event, helper);
            }else if (status == "ERROR") {
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                helper.handleErrorblock(component, event, helper);
            }else{
                component.set("v.loading",false);
                helper.showToast(component, event, helper,"Something went wrong, Please try again later or try to refresh page.","error");
                helper.handleErrorblock(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    setDataTableHeaders :  function (component, event, helper){
        component.set('v.EmploymentColumns', [
            { label: 'EMPLOYER', fieldName: 'companyName' },
            { label: 'OCCUPATION', fieldName: 'position' },
            { label: 'WAGE', fieldName: 'payPerPeriod' },
            { label: 'FREQUENCY', fieldName: 'paySchedule' },
            { label: 'HIRED', fieldName: 'fromDate' },
            { label: 'SEPARATED', fieldName: 'to'}
        ]);
        component.set('v.ResidenceColumns', [
            { label: 'STREET', fieldName: 'streetName' },
            { label: 'CITY', fieldName: 'city'},
            { label: 'PROVINCE', fieldName: 'province' },
            { label: 'POSTALCODE', fieldName: 'postalCode' },
            { label: 'SINCE', fieldName: 'fromDate' }
        ]);
        
        component.set('v.Inquirycolumns', [
            { label: 'DATE', fieldName: 'eqDate' },
            { label: 'INDUSTRY', fieldName: 'industryCode' },
            { label: 'CREDIT GRANTOR', fieldName: 'inquirerName' },
            { label: 'ACCOUNT NUMBER', fieldName: 'subscriberCode' }
        ]);
        
        component.set('v.BankruptcyInsolvencyColumns', [
            { label: 'RVSD', fieldName: 'revisedDate' },
            { label: 'REPTD', fieldName: 'reportedDate' },
            { label: 'TRUSTEE', fieldName: 'trusteeName' },
            { label: 'ASSETS', fieldName: 'assets'},
            { label: 'LIAB', fieldName: 'liabilities'},
            { label: 'PROPOSAL', fieldName: 'referenceNumber'},
            { label: 'TRUSTEE', fieldName: 'trusteeCompany' },
            { label: 'THIRD PARTY/CONTACT', fieldName: 'thirdParty' },
        ]);
            
            component.set('v.RegisteredItemsColumns', [
            { label: 'SUBSCRIBER', fieldName: 'subscriberName' },
            { label: 'REPT', fieldName: 'dateRevised' },
            { label: 'OPEN', fieldName: 'dateFiled' },
            { label: 'MATUR', fieldName: 'dateMature' },
            { label: 'AMOUNT', fieldName: 'balance',  },
            { label: 'Description', fieldName: 'description'},
            { label: 'SECURITY', fieldName: 'security' }
        ]);
        
        component.set('v.TradeColumns', [
            { label: 'COMPANY', fieldName: 'creditor' },
            { label: 'ACCOUNT', fieldName: 'accountNumber' },
            { label: 'PAYMENT', fieldName: 'paymentPattern' },
            { label: 'REPT', fieldName: 'paymentPatternStart' },
            { label: 'OPEN', fieldName: 'openedOn' },
            { label: 'LAST', fieldName: 'lastActivity' },
            { label: 'H.CREDIT', fieldName: 'openingBalance' },
            { label: 'Balance', fieldName: 'paymentAmount' },
            { label: 'PAST DUE', fieldName: 'amountPastDue' },
            { label: 'TERMS', fieldName: 'paymentSchedule' },
            { label: '30/60/90/#M', fieldName: 'monthsReviewed' },
            { label: 'MOP', fieldName: 'mop' },
            { label: 'INDUSTRY', fieldName: 'industryCode' },
            { label: 'COMMENT', fieldName: 'description' }
        ]);
        
        component.set('v.BankingClosedForCauseColumns', [
            { label: 'REPORTED', fieldName: 'dateVerified' },
            { label: 'OPEN', fieldName: 'dateOpened' },
            { label: 'WRITE OFF', fieldName: 'dateClosed' },
            { label: 'AMOUNT', fieldName: 'balance' },
            { label: 'INDUSTRY', fieldName: 'industryCode' },
            { label: 'INSTITUTION', fieldName: 'subscriberName' },
            { label: 'REASON', fieldName: 'reason' }
        ]);
        
        component.set('v.FileSummaryColumns', [
            { label: 'TYPE', fieldName: 'fileSummarytype' },
            { label: 'COUNT', fieldName: 'count' },
            { label: 'HIGH CRED', fieldName: 'highCredit' },
            { label: 'CRED LIMIT', fieldName: 'creditLimit' },
            { label: 'BALANCE', fieldName: 'balance' },
            { label: 'PAST DUE', fieldName: 'pastDue' },
            { label: 'PAYMENT', fieldName: 'payment' },
            { label: 'AVAILABLE', fieldName: 'available' }
        ]);
        component.set('v.LegalItemsColumns', [
            { label: 'RVSD', fieldName: 'revisedDate' },
            { label: 'REPT', fieldName: 'dateReported' },
            { label: 'PLANTIFF NAME', fieldName: 'plaintiff' },
            { label: 'AMOUNT', fieldName: 'amount' },
            { label: 'BALANCE', fieldName: 'balance' },
            { label: 'SETTLED', fieldName: 'dateSettled' },
            { label: 'NOTE', fieldName: 'narrative' }
        ]);
        component.set('v.CollectionsColumns', [
            { label: 'RVSD', fieldName: 'revisedDate' },
            { label: 'REPT', fieldName: 'reportedDate' },
            { label: 'CREDITOR', fieldName: 'creditorName' },
            { label: 'AMOUNT', fieldName: 'originalAmount' },
            { label: 'BALANCE', fieldName: 'currentBalance' },
            { label: 'PAID', fieldName: 'payOutDate' },
            { label: 'NOTES', fieldName: 'narrative' }
        ]);
        component.set('v.RemarksColumns', [
            { label: 'DATE', fieldName: 'eqDate' },
            { label: 'CODE', fieldName: 'code' },
            { label: 'INFORMATION', fieldName: 'text' }
        ]);
    },
    convertToDatatableData : function (component, event, helper){
        
        var creditData = component.get("v.CreditData");
        var creditHistory = creditData.creditHistory;
        var objectToIterate = creditHistory.employments;
        var dataTableArray = [];
        component.set("v.CreditHistoryOverview",creditHistory);
        component.set("v.FileSummaryReport",creditHistory.summaryReport);
        component.set("v.FileTradeSummaries",creditHistory);
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].fromDate){
                objData.fromDate = objectToIterate[i].fromDate;
            }else{
                objData.fromDate = '-';
            }
            if(objectToIterate[i].to){
                objData.to = objectToIterate[i].to;
            }else{
                objData.to = '-';
            }
            if(objectToIterate[i].item.companyName){
                objData.companyName = objectToIterate[i].item.companyName;
            }else{
                objData.companyName = '-';
            }
            if(objectToIterate[i].item.position){
                objData.position = objectToIterate[i].item.position;
            }else{
                objData.position = '-';
            }
            if(objectToIterate[i].item.paySchedule){
                objData.paySchedule = objectToIterate[i].item.paySchedule;
            }else{
                objData.paySchedule = '-';
            }
            //Added .toFixed to convert 3000 into 3000.00
            if(objectToIterate[i].item.payPerPeriod){
                objData.payPerPeriod = ((objectToIterate[i].item.payPerPeriod).toFixed(2)).toString();                
            }else{
                objData.payPerPeriod = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.EmploymentData",dataTableArray);
        objectToIterate = creditHistory.addresses;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].item.civic || objectToIterate[i].item.streetType || objectToIterate[i].item.streetName){
                objData.streetName = objectToIterate[i].item.civic+' '+objectToIterate[i].item.streetType+' '+objectToIterate[i].item.streetName;
            }else{
                objData.streetName = '-';
            }
            if(objectToIterate[i].item.city){
                objData.city = objectToIterate[i].item.city;
            }else{
                objData.city = '-';
            }
            if(objectToIterate[i].item.province){
                objData.province = objectToIterate[i].item.province;
            }else{
                objData.province = '-';
            }
            if(objectToIterate[i].item.postalCode){
                objData.postalCode = objectToIterate[i].item.postalCode;
            }else{
                objData.postalCode = '-';
            }
            if(objectToIterate[i].fromDate){
                objData.fromDate = objectToIterate[i].fromDate;
            }else{
                objData.fromDate = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.ResidenceData",dataTableArray);
        
        objectToIterate = creditHistory.remarks;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].eqDate){
                objData.eqDate = objectToIterate[i].eqDate;
            }else{
                objData.eqDate = '-';
            }
            if(objectToIterate[i].code){
                objData.code = objectToIterate[i].code;
            }else{
                objData.code = '-';
            }
            if(objectToIterate[i].text){
                objData.text = objectToIterate[i].text;
            }else{
                objData.text = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.RemarksData",dataTableArray);
        
        objectToIterate = creditHistory.collections;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].revisedDate){
                objData.revisedDate = objectToIterate[i].revisedDate;
            }else{
                objData.revisedDate = '-';
            }
            if(objectToIterate[i].reportedDate){
                objData.reportedDate = objectToIterate[i].reportedDate;
            }else{
                objData.reportedDate = '-';
            }
            if(objectToIterate[i].creditorName){
                objData.creditorName = objectToIterate[i].creditorName;
            }else{
                objData.creditorName = '-';
            }
            if(objectToIterate[i].originalAmount){
                objData.originalAmount = (objectToIterate[i]).originalAmount.toString();
            }else{
                objData.originalAmount = '-';
            }
            if(objectToIterate[i].currentBalance.toString()){
                objData.currentBalance = (objectToIterate[i]).currentBalance.toString();
            }else{
                objData.currentBalance = '-';
            }
            if(objectToIterate[i].payOutDate){
                objData.payOutDate = objectToIterate[i].payOutDate;
            }else{
                objData.payOutDate = '-';
            }
            if(objectToIterate[i].narrative){
                objData.narrative = objectToIterate[i].narrative;
            }else{
                objData.narrative = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.CollectionsData",dataTableArray);
        
        objectToIterate = creditHistory.legalItems;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].revisedDate){
                objData.revisedDate = objectToIterate[i].dateRevised;
            }else{
                objData.revisedDate = '-';
            }
            if(objectToIterate[i].dateReported){
                objData.dateReported = objectToIterate[i].dateReported;
            }else{
                objData.dateReported = '-';
            }
            if(objectToIterate[i].dateSettled){
                objData.dateSettled = objectToIterate[i].dateSettled;
            }else{
                objData.dateSettled = '--';
            }
            if(objectToIterate[i].plaintiff){
                objData.plaintiff = objectToIterate[i].plaintiff;
            }else{
                objData.plaintiff = '-';
            }
            if(objectToIterate[i].amount){
                objData.amount = (objectToIterate[i]).amount.toString();
            }else{
                objData.amount = '-';
            }
            if(objectToIterate[i].balance.toString()){
                objData.balance = (objectToIterate[i]).balance.toString();
            }else{
                objData.balance = '-';
            }
            if(objectToIterate[i].narrative){
                objData.narrative = objectToIterate[i].narrative;
            }else{
                objData.narrative = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.LegalItemsData",dataTableArray);
        
        
        objectToIterate = creditHistory.inquiries;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].eqDate){
                objData.eqDate = objectToIterate[i].eqDate;
            }else{
                objData.eqDate = '-';
            }
            if(objectToIterate[i].industryCode){
                objData.industryCode = objectToIterate[i].industryCode;
            }else{
                objData.industryCode = '-';
            }
            if(objectToIterate[i].inquirerName){
                objData.inquirerName = objectToIterate[i].inquirerName;
            }else{
                objData.inquirerName = '-';
            }
            if(objectToIterate[i].subscriberCode){
                objData.subscriberCode = objectToIterate[i].subscriberCode;
            }else{
                objData.subscriberCode = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.Inquirydata",dataTableArray);
        dataTableArray = [];
        var tradeUnionArray = ['consumerProposals', 'bankruptcies'];
        for(var ind=0; ind <tradeUnionArray.length;ind++){
            objectToIterate = [];
            if(creditHistory[tradeUnionArray[ind]] != undefined && creditHistory[tradeUnionArray[ind]] != null){
                objectToIterate = creditHistory[tradeUnionArray[ind]];
            }
            for(var i=0; i <objectToIterate.length;i++){
                var objData = {};
                if(objectToIterate[i].trusteeCompany){
                    objData.trusteeCompany = objectToIterate[i].trusteeCompany;
                }else{
                    objData.trusteeCompany = '-';
                }
                if(objectToIterate[i].thirdParty){
                    objData.thirdParty = objectToIterate[i].thirdParty;
                }else{
                    objData.thirdParty = '-';
                }
                if(objectToIterate[i].referenceNumber){
                    objData.referenceNumber = objectToIterate[i].referenceNumber;
                }else{
                    objData.referenceNumber = '-';
                }
                if(objectToIterate[i].reportedDate){
                    objData.reportedDate = objectToIterate[i].reportedDate;
                }else{
                    objData.reportedDate = '-';
                }
                if(objectToIterate[i].trusteeName){
                    objData.trusteeName = objectToIterate[i].trusteeName;
                }else{
                    objData.trusteeName = '-';
                }
                if(objectToIterate[i].assets.toString()){
                    objData.assets = (objectToIterate[i].assets).toString();
                }else{
                    objData.assets = '-';
                }
                if(objectToIterate[i].liabilities){
                    objData.liabilities = (objectToIterate[i].liabilities).toString();
                }else{
                    objData.liabilities = '-';
                }
                if(objectToIterate[i].revisedDate){
                    objData.revisedDate = objectToIterate[i].revisedDate;
                }else{
                    objData.revisedDate = '-';
                }
                dataTableArray.push(objData);
            }
        }
        component.set("v.BankruptcyInsolvencyData",dataTableArray);
        objectToIterate = creditHistory.registeredItems;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].subscriberName){
                objData.subscriberName = objectToIterate[i].subscriberName;
            }else{
                objData.subscriberName = '-';
            }
            if(objectToIterate[i].dateMature){
                objData.dateMature = objectToIterate[i].dateMature;
            }else{
                objData.dateMature = '-';
            }
            if(objectToIterate[i].balance.toString()){
                objData.balance = (objectToIterate[i].balance).toString();
            }else{
                objData.balance = '-';
            }
            if(objectToIterate[i].security){
                objData.security = objectToIterate[i].security;
            }else{
                objData.security = '-';
            }
            if(objectToIterate[i].dateFiled){
                objData.dateFiled = objectToIterate[i].dateFiled;
            }else{
                objData.dateFiled = '-';
            }
            if(objectToIterate[i].dateRevised){
                objData.dateRevised = objectToIterate[i].dateRevised;
            }else{
                objData.dateRevised = '-';
            }
            if(objectToIterate[i].description){
                objData.description = objectToIterate[i].description;
            }else{
                objData.description = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.RegisteredItemsData",dataTableArray);
        var tradeUnionArray = ['loans', 'openCreditAccounts','revolvingCreditAccounts'];
        dataTableArray = [];
        for(var ind=0; ind <tradeUnionArray.length;ind++){
            objectToIterate = [];
            if(creditHistory[tradeUnionArray[ind]] != undefined && creditHistory[tradeUnionArray[ind]] != null){
                objectToIterate = creditHistory[tradeUnionArray[ind]];
            }
            for(var i=0; i <objectToIterate.length;i++){
                var objData = {};
                if(objectToIterate[i].openedOn){
                    objData.openedOn = objectToIterate[i].openedOn;
                }else{
                    objData.openedOn = '-';
                }
                if(objectToIterate[i].description){
                    objData.description = objectToIterate[i].description;
                }else{
                    objData.description = '-';
                }
                if(objectToIterate[i].creditor){
                    objData.creditor = objectToIterate[i].creditor;
                }else{
                    objData.creditor = '-';
                }
                if(objectToIterate[i].paymentPattern){
                    objData.paymentPattern = objectToIterate[i].paymentPattern;
                }else{
                    objData.paymentPattern = '-';
                }
                if(objectToIterate[i].industryCode){
                    objData.industryCode = objectToIterate[i].industryCode;
                }else{
                    objData.industryCode = '-';
                }
                if(objectToIterate[i].accountNumber){
                    objData.accountNumber = objectToIterate[i].accountNumber;
                }else{
                    objData.accountNumber = '-';
                }
                if(objectToIterate[i].mop || objectToIterate[i].status){
                    objData.mop = objectToIterate[i].mop+' '+objectToIterate[i].status;
                }else{
                    objData.mop = '-';
                }
                if(objectToIterate[i].lastActivity){
                    objData.lastActivity = objectToIterate[i].lastActivity;
                }else{
                    objData.lastActivity = '-';
                }
                if(objectToIterate[i].openingBalance != undefined){
                    objData.openingBalance = (objectToIterate[i].openingBalance).toString();
                }else if(objectToIterate[i].historicalMaxBalance != undefined){
                    objData.openingBalance = (objectToIterate[i].historicalMaxBalance).toString();
                }else if(objectToIterate[i].creditLimit != undefined){
                    objData.openingBalance = (objectToIterate[i].creditLimit).toString();
                }else{
                    objData.openingBalance = '-';
                }
                if(objectToIterate[i].paymentAmount.toString()){
                    objData.paymentAmount = (objectToIterate[i].paymentAmount).toString();
                }else{
                    objData.paymentAmount = '-';
                }
                if(objectToIterate[i].paymentPatternStart){
                    objData.paymentPatternStart = objectToIterate[i].paymentPatternStart;
                }else{
                    objData.paymentPatternStart = '-';
                }
                if(objectToIterate[i].amountPastDue.toString()){
                    objData.amountPastDue = (objectToIterate[i].amountPastDue).toString();
                }else{
                    objData.amountPastDue = '-';
                }
                if(objectToIterate[i].payments30DaysLate || objectToIterate[i].payments60DaysLate ||
                   objectToIterate[i].payments90DaysLate || objectToIterate[i].monthsReviewed){
                    var a= objectToIterate[i].payments30DaysLate;
                    var b= objectToIterate[i].payments60DaysLate;
                    var c= objectToIterate[i].payments90DaysLate;
                    var d= objectToIterate[i].monthsReviewed;
                    objData.monthsReviewed = a+'/'+''+b+'/'+''+c+'/'+''+d;
                }else{
                    objData.monthsReviewed = '-';
                }
                if(objectToIterate[i].paymentAmount || objectToIterate[i].paymentSchedule){
                    var a1= objectToIterate[i].paymentAmount;
                    var b1= objectToIterate[i].paymentSchedule;
                    objData.paymentSchedule = a1+'/'+''+b1;
                }else{
                    objData.paymentSchedule = '-';
                }
                dataTableArray.push(objData);
            }
        }
        //(dataTableArray);
        component.set("v.TradeData",dataTableArray);
        objectToIterate = creditHistory.bankClosures;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].dateVerified){
                objData.dateVerified = objectToIterate[i].dateVerified;
            }else{
                objData.dateVerified = '-';
            }
            if(objectToIterate[i].subscriberName){
                objData.subscriberName = objectToIterate[i].subscriberName;
            }else{
                objData.subscriberName = '-';
            }
            if(objectToIterate[i].dateOpened){
                objData.dateOpened = objectToIterate[i].dateOpened;
            }else{
                objData.dateOpened = '-';
            }
            if(objectToIterate[i].dateClosed){
                objData.dateClosed = objectToIterate[i].dateClosed;
            }else{
                objData.dateClosed = '-';
            }
            if(objectToIterate[i].reason){
                objData.reason = objectToIterate[i].reason;
            }else{
                objData.reason = '-';
            }
            if(objectToIterate[i].industryCode){
                objData.industryCode = objectToIterate[i].industryCode;
            }else{
                objData.industryCode = '-';
            }
            if(objectToIterate[i].balance.toString()){
                objData.balance = '$'+(objectToIterate[i].balance).toString();
            }else{
                objData.balance = '-';
            }
            dataTableArray.push(objData);
        }
        
        component.set("v.BankingClosedForCauseData",dataTableArray);
        objectToIterate = creditHistory.summaryReport.tradeSummaries;
        dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].balance != undefined){
                objData.balance = '$'+(objectToIterate[i].balance).toString();
            }else{
                objData.balance = '-';
            }
            if(objectToIterate[i].highCredit != undefined && objectToIterate[i].highCredit.toString()){
                objData.highCredit = '$'+(objectToIterate[i].highCredit).toString();
            }else{
                objData.highCredit = '-';
            }
            
            if(objectToIterate[i].fileSummarytype != undefined){
                objData.fileSummarytype = objectToIterate[i].fileSummarytype;
            }else{
                objData.highCredit = '-';
            }
            if(objectToIterate[i].creditLimit != undefined){
                objData.creditLimit = '$'+(objectToIterate[i].creditLimit).toString();
            }else{
                objData.creditLimit = '-';
            }
            if(objectToIterate[i].available != undefined && objectToIterate[i].available.toString()){
                objData.available = (Math.round(objectToIterate[i].available* 100)).toString() + '%';
            }else{
                objData.available = '-';
            }
            if(objectToIterate[i].count != null && objectToIterate[i].count != ''){
                objData.count = (objectToIterate[i].count).toString();
            }else{
                objData.count = '-';
            }
            if(objectToIterate[i].pastDue != null  && objectToIterate[i].pastDue.toString() != ''){
                objData.pastDue = '$'+(objectToIterate[i].pastDue).toString();
            }else{
                objData.pastDue = '-';
            }
            if(objectToIterate[i].payment != null && objectToIterate[i].payment.toString()){
                objData.payment = '$'+(objectToIterate[i].payment).toString();
            }else{
                objData.payment = '-';
            }
            dataTableArray.push(objData);
        }
        component.set("v.FileSummaryData",dataTableArray);
        helper.openAllAccordian(component, event, helper);
        //component.set("v.loading",false);
    },
    fetchErrorMessages: function(component, event, helper) {
        var action = component.get("c.getErrorMessages");
        action.setParams({
            applicationID: component.get("v.recordId"),
            applicantType: component.get("v.applicantType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                var errormessages = response.getReturnValue();
                console.log('errormessages',errormessages);
                if(errormessages != 'Success'){
                    component.set("v.errorMessage",errormessages);
                    component.set("v.loading",false);
                    helper.setRedFlagsVisibility(component, event, helper,false);
                    //component.set("v.isDisabledRawReportButton",true);
                    
                }else if(errormessages == 'Success'){
                    component.set("v.errorMessage",'');
                    //component.set("v.isDisabledRawReportButton",false);
                    helper.fetchCreditDetails(component, event, helper,'');
                }
            }
            else if (status === "INCOMPLETE") {
                component.set("v.loading",false);
                console.log("No response from server or client is offline.")
            }else if (status === "ERROR") {
                component.set("v.loading",false);
                console.log("Error: " + errorMessage);
            }
        });
        $A.enqueueAction(action);
    },
    showPostCPResults : function (component, event, helper){
        var activeSeactionsName = [];
        component.set("v.postCPSearchObject",[]);
        component.set("v.isPostCpFilterActivate",true);
        var postCPSearchObjects = component.get("v.postCPSearchObject");
        var creditData = component.get("v.CreditData");
        console.log('---isPostCpFilterActivate------');
        var creditHistory = creditData.creditHistory;
        var objectToIterate = creditHistory.inquiries;
        var dataTableArray = [];
        for(var i=0; i <objectToIterate.length;i++){
            var objData = {};
            if(objectToIterate[i].postCP != undefined && objectToIterate[i].postCP == true){
                
                objData.eqDate = objectToIterate[i].eqDate;
                objData.industryCode = objectToIterate[i].industryCode;
                objData.inquirerName = objectToIterate[i].inquirerName;
                objData.subscriberCode = objectToIterate[i].subscriberCode;
                dataTableArray.push(objData);
            }
        }
        component.set("v.Inquirydata",dataTableArray);
        if(dataTableArray.length > 0){
            postCPSearchObjects.push('inquiries');
            component.set("v.InquiriesAcordian",'slds-show');
            activeSeactionsName.push("K");
        }
        var tradeUnionArray = ['loans', 'openCreditAccounts','revolvingCreditAccounts'];
        dataTableArray = [];
        for(var ind=0; ind <tradeUnionArray.length;ind++){
            objectToIterate = [];
            if(creditHistory[tradeUnionArray[ind]] != undefined && creditHistory[tradeUnionArray[ind]] != null){
                objectToIterate = creditHistory[tradeUnionArray[ind]];
            }
            for(var i=0; i <objectToIterate.length;i++){
                if(objectToIterate[i].postCP != undefined && objectToIterate[i].postCP == true){
                    var objData = {};
                    objData.openedOn = objectToIterate[i].openedOn;
                    objData.description = objectToIterate[i].description;
                    objData.creditor = objectToIterate[i].creditor;
                    objData.paymentPattern = objectToIterate[i].paymentPattern;
                    objData.industryCode = objectToIterate[i].industryCode;
                    objData.accountNumber = objectToIterate[i].accountNumber;
                    objData.mop = objectToIterate[i].mop+' '+objectToIterate[i].status;
                    objData.lastActivity = objectToIterate[i].lastActivity;
                    if(objectToIterate[i].openingBalance != undefined){
                        objData.openingBalance = (objectToIterate[i].openingBalance).toString();
                    }else if(objectToIterate[i].historicalMaxBalance != undefined){
                        objData.openingBalance = (objectToIterate[i].historicalMaxBalance).toString();
                    }else if(objectToIterate[i].creditLimit != undefined){
                        objData.openingBalance = (objectToIterate[i].creditLimit).toString();
                    }
                    objData.paymentAmount = (objectToIterate[i].paymentAmount).toString();
                    objData.paymentPatternStart = objectToIterate[i].paymentPatternStart;
                    var a= objectToIterate[i].payments30DaysLate;
                    var b= objectToIterate[i].payments60DaysLate;
                    var c= objectToIterate[i].payments90DaysLate;
                    var d= objectToIterate[i].monthsReviewed;
                    objData.amountPastDue = (objectToIterate[i].amountPastDue).toString();
                    objData.monthsReviewed = a+'/'+''+b+'/'+''+c+'/'+''+d;
                    var a1= objectToIterate[i].paymentAmount;
                    var b1= objectToIterate[i].paymentSchedule;
                    objData.paymentSchedule = a1+'/'+''+b1;
                    dataTableArray.push(objData);
                }
            }
        }
        if(dataTableArray.length > 0){
            component.set("v.TradeAcordian",'slds-show');
            activeSeactionsName.push("F");
            postCPSearchObjects.push('loans');
            postCPSearchObjects.push('openCreditAccounts');
            postCPSearchObjects.push('revolvingCreditAccounts');
        }
        component.set("v.TradeData",dataTableArray);
        component.set("v.postCPSearchObject",postCPSearchObjects);
        helper.showAllAccordions(component, event, helper, false);
        setTimeout(function(){
            component.set("v.activeSections",activeSeactionsName);
            component.find("accordion").set('v.activeSectionName', activeSeactionsName);
        }, 50);
    },
    showAllAccordions : function (component, event, helper, isShow){
        console.log('----showAllAccordionsshowAllAccordions---'+isShow);
        if(isShow){
            component.set("v.IDMismatchAcordian",'slds-show');
            component.set("v.TradeAcordian",'slds-show');
            component.set("v.residenceAcordian",'slds-show');
            component.set("v.EmploymentAcordian",'slds-show');
            component.set("v.BankingClosedAcordian",'slds-show');
            component.set("v.RegisteredItemsAcordian",'slds-show');
            component.set("v.BankruptcyAcordian",'slds-show');
            component.set("v.InquiriesAcordian",'slds-show');
            component.set("v.OverviewAcordian",'slds-show');
            component.set("v.LegalItemsAcordian",'slds-show');
            component.set("v.CollectionsAcordian",'slds-show');
            component.set("v.RemarksAcordian",'slds-show');
            
        }else{
            component.set("v.IDMismatchAcordian",'slds-hide');
            component.set("v.residenceAcordian",'slds-hide');
            component.set("v.EmploymentAcordian",'slds-hide');
            component.set("v.BankingClosedAcordian",'slds-hide');
            component.set("v.RegisteredItemsAcordian",'slds-hide');
            component.set("v.BankruptcyAcordian",'slds-hide');
            component.set("v.OverviewAcordian",'slds-hide');
            component.set("v.LegalItemsAcordian",'slds-hide');
            component.set("v.CollectionsAcordian",'slds-hide');
            component.set("v.RemarksAcordian",'slds-hide');
            
        }
    },
    
    showToast : function(component, event, helper, message,toasttype) {
        var toastEvent = $A.get("e.force:showToast");
        var title = toasttype[0].toUpperCase();
        title += toasttype.substring(1,toasttype.length)+'!';
        toastEvent.setParams({
            "title": title, 
            "type" : toasttype,
            "message": message
        });
        toastEvent.fire();
    },
    openAllAccordian : function(component, event, helper) {
        setTimeout(function(){
            component.set("v.activeSections",component.get("v.AllActiveSectionsNames"));
            component.find("accordion").set('v.activeSectionName', component.get("v.AllActiveSectionsNames"));
        }, 100);
    }
})
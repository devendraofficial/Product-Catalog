({
    doInit : function(component, event, helper) {
        /*
        helper.CoBorrowerTabShowHide(component, event, helper);
        helper.CoSignerTabShowHide(component, event, helper);
        helper.fetchApplicantDetail(component, event, helper);
        helper.fetchErrorMessages(component, event, helper);
        helper.getCreditRecordDates(component, event, helper);
        helper.setDataTableHeaders(component, event, helper);
        component.set("v.loading",false);
        */
        //helper.fetchCreditDetails(component, event, helper);
        // window.onkeydown = function( event ) {
        
        //alert(event.keyCode+"-keyCode---"+component.get("v.isfocusSearchInput"));
        
        //helper.showInsightErrorMessage (component, event, helper);
        //helper.fetchCreditRecordsByDate(component, event, helper);
    },
    newSummaryPull: function(component, event, helper) {
        component.set('v.HitErrorMessage','slds-hide');
        component.set('v.insightSection','slds-hide');
        component.set('v.insightSectionFull','slds-hide');
        component.set('v.postCP',false);
        component.set('v.filterReport',false);
        component.set("v.isPostCpFilterActivate",false);
        component.set("v.isFilterActivate",false);
        component.set("v.isAllFilterActivate",false);
        component.set("v.loading",true);
        component.set("v.searchValue",'');
        component.set("v.isOpenSummary", false);
        helper.initiateNewSummary(component, event, helper);
    },
    GetNewFullReport: function(component, event, helper) {
        //component.set('v.HitErrorMessage','slds-hide');
        //component.set('v.insightSection','slds-hide');
        //component.set('v.insightSectionFull','slds-hide');
        component.set('v.postCP',false);
        component.set('v.filterReport',false);
        component.set("v.isPostCpFilterActivate",false);
        component.set("v.isFilterActivate",false);
        component.set("v.isAllFilterActivate",false);
        component.set("v.loading",true);
        component.set("v.searchValue",'');
        component.set("v.isOpen", false);
        helper.getHardPullData(component, event, helper);
    },
    
    fetchCreditRecords: function(component, event, helper) {
        component.set("v.loading",true);
        component.get("v.searchValue",'');
        var selectList;
        if(component.get("v.applicantType") == 'BORROWER'){
            selectList = component.find("mySelect");
        }else if(component.get("v.applicantType") == 'COBORROWER'){
            selectList = component.find("mySelectCo");
        }else if(component.get("v.applicantType") == 'COSIGNER'){
            selectList = component.find("mySelectSigner");
        }
        var selectedId = selectList.get("v.value");
        helper.fetchCreditDetails(component, event, helper,selectedId);
    },
    
    tabSelected: function(component,event,helper) {
        component.set("v.datevalue",[]);
        component.set('v.HitErrorMessage','slds-hide');
        component.set('v.insightSection','slds-hide');
        component.set('v.insightSectionFull','slds-hide');
        component.set('v.postCP',false);
        component.set('v.filterReport',false);
        component.set("v.isPostCpFilterActivate",false);
        component.set("v.isFilterActivate",false);
        component.set("v.isAllFilterActivate",false);
        if(component.get("v.applicantType") == 'BORROWER'){
            component.set("v.ShowBorrowerDiv",true);
            component.set("v.ShowCoborrowerDiv",false);
            component.set("v.ShowCoSignerDiv",false);
        }else if(component.get("v.applicantType") == 'COBORROWER'){
            component.set("v.ShowCoborrowerDiv",true);
            component.set("v.ShowBorrowerDiv",false);
            component.set("v.ShowCoSignerDiv",false);
        }else if(component.get("v.applicantType") == 'COSIGNER'){
            component.set("v.ShowCoSignerDiv",true);
            component.set("v.ShowCoborrowerDiv",false);
            component.set("v.ShowBorrowerDiv",false);
        }
        component.set("v.CreditData",null);
        component.set("v.loading",true);
        component.set("v.searchValue",'');
        helper.fetchApplicantDetail(component, event, helper);
        helper.fetchErrorMessages(component, event, helper);
        helper.setDataTableHeaders(component, event, helper);
        helper.getCreditRecordDates(component, event, helper);
        helper.hideAllOtherTabs(component, event, helper, false);   
        //helper.fetchCreditDetails(component, event, helper);
        //component.set("v.loading",false);
    },
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"
        component.set("v.isOpen", false);
    },
    
    openSummaryModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpenSummary", true);
    },
    closeSummaryModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"
        component.set("v.isOpenSummary", false);
    },
    callVFPage : function(component, event, helper) {
        //var action = component.get("c.getRawCreditReport");
        var selectList;
        if(component.get("v.applicantType") == 'BORROWER'){
            selectList = component.find("mySelect");
        }else if(component.get("v.applicantType") == 'COBORROWER'){
            selectList = component.find("mySelectCo");
        }else if(component.get("v.applicantType") == 'COSIGNER'){
            selectList = component.find("mySelectSigner");
        }
        var selectedId = selectList.get("v.value");
        window.open('/apex/creditReportRawData?id='+selectedId);
        
    },
    hideErrorMesssage: function(component, event, helper) {
        component.set("v.isfocusSearchInput",false);
        component.set("v.isNoResultFound",false);
    },
    focusSearchInput: function(component, event, helper) {
        if(event.which == 13){
            if(component.get("v.CreditData") != null && !component.get("v.HitErrorMessageEnable")){
                var searchInput = component.get("v.searchValue");
                if(false/*searchInput.length >= 0 && searchInput.length < 2 */){
                    component.set("v.isNoResultFound",false);
                    if(helper.isTableResetRequired){
                        helper.isTableResetRequired = false;
                        if(component.get("v.isAllFilterActivate")){
                            helper.showCombineFilterResults(component, event, helper);
                        }else if(component.get("v.isFilterActivate")){
                            helper.renderTableVisibility(component, event, helper);
                        }else if(component.get("v.isPostCpFilterActivate")){
                            helper.showPostCPResults(component, event, helper);
                        }else{
                            helper.hideAllOtherTabs(component, event, helper, false);    
                        }
                        helper.convertToDatatableData(component, event, helper);
                    }else{
                    }
                }else{
                    helper.isTableResetRequired = true;
                    helper.filterDataTablesByInput(component, event, helper,searchInput);
                }
            }
        }
    },
    filterDataTables: function(component, event, helper) {
        console.log(component.get("v.CreditData"));
        console.log(component.get("v.HitErrorMessageEnable"));
        //alert("-----"+event.keyCode);
        /*if(component.get("v.CreditData") != null && !component.get("v.HitErrorMessageEnable")){
            var searchInput = component.get("v.searchValue");
            if(searchInput.length >= 0 && searchInput.length < 2 ){
                component.set("v.isNoResultFound",false);
                if(helper.isTableResetRequired){
                    helper.isTableResetRequired = false;
                    if(component.get("v.isAllFilterActivate")){
                        helper.showCombineFilterResults(component, event, helper);
                    }else if(component.get("v.isFilterActivate")){
                        helper.renderTableVisibility(component, event, helper);
                    }else if(component.get("v.isPostCpFilterActivate")){
                        helper.showPostCPResults(component, event, helper);
                    }else{
                        helper.hideAllOtherTabs(component, event, helper, false);    
                    }
                    helper.convertToDatatableData(component, event, helper);
                }else{
                }
            }else{
                helper.isTableResetRequired = true;
                helper.filterDataTablesByInput(component, event, helper,searchInput);
            }
           
        } */
    }, 
    handleVerticalMenu:function(component,event,helper)
    {
        var tab = event.getParam("tab");
        if(tab=="CreditReport"){     
            component.set("v.loading",true);
            component.set('v.isVisible','true');
            helper.CoBorrowerTabShowHide(component, event, helper);
            helper.CoSignerTabShowHide(component, event, helper);
            helper.fetchApplicantDetail(component, event, helper);
            helper.fetchErrorMessages(component, event, helper);
            helper.getCreditRecordDates(component, event, helper);
            helper.setDataTableHeaders(component, event, helper);
            //component.set("v.loading",false);
        }
        else
            component.set('v.isVisible','false');
        
    },
    
    showRedFlagsSections:function(component,event,helper){
        component.set("v.searchValue",'');
        var isPostCpChecked = component.get('v.postCP');
        if(isPostCpChecked && component.get('v.filterReport')){
            component.set("v.isFilterActivate",false);
            component.set("v.isPostCpFilterActivate",false);
            helper.showCombineFilterResults(component, event, helper);
        }else{
            component.set("v.isAllFilterActivate",false);
            helper.renderTableVisibility(component, event, helper);
            if(!component.get('v.filterReport') && component.get('v.postCP')){
                component.set("v.isPostCpFilterActivate",true);
                helper.showPostCPResults(component, event, helper);
            }
            if(!(isPostCpChecked && component.get('v.filterReport'))){
                helper.openAllAccordian(component, event, helper);
            }
        } 
    },
    getPostCPData:function(component,event,helper){ 
        component.set("v.searchValue",'');
        var value = component.get('v.postCP');
        var isFilterReportChecked = component.get('v.filterReport');
        if(isFilterReportChecked && component.get('v.postCP')){
            component.set("v.isFilterActivate",false);
            component.set("v.isPostCpFilterActivate",false);
            helper.showCombineFilterResults(component, event, helper);
        }else{
            component.set("v.isAllFilterActivate",false);
            if (value == true) {
                component.set("v.isPostCpFilterActivate",true);
                helper.showPostCPResults(component, event, helper);
            } else{
                component.set('v.isPostCpFilterActivate',false);
                helper.convertToDatatableData(component, event, helper);
                helper.showAllAccordions(component, event, helper, true);
                if(component.get('v.filterReport')){
                    helper.renderTableVisibility(component, event, helper);
                }
                if(!(value && component.get('v.filterReport'))){
                    helper.openAllAccordian(component, event, helper);
                }
            }
        }
    },
})
({
    doInit: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
    removeDeletedRow: function(component, event, helper) {
        var index = event.getParam("indexVar");
        var AllRowsList = component.get("v.addressList");
        AllRowsList.splice(index, 1);
        component.set("v.addressList", AllRowsList);
    },
})
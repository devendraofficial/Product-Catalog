({
    createObjectData: function(component, event) {
        var RowItemList = component.get("v.addressList");
        RowItemList.push({
            'sobjectType': 'Address__c',
            'Unit__c': '',
            'Street_Address__c': '',
            'Province__c': '',
            'City__c' : ''
        });
        component.set("v.addressList", RowItemList);
    },
})
({
    doInit : function(component, event, helper) {   
        component.set('v.columns', [
            {label: 'Application ID',  fieldName: 'linkName', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: 'Application Stage', fieldName: 'ApplicationStage__c', type: 'picklist'},
            {label: 'Application Status', fieldName: 'ApplicationStatus__c',  type: 'picklist'},
            {label: 'Amount', fieldName: 'LoanAmount__c',  type: 'currency'},
            {label: 'Product Type', fieldName: 'Product_Type__c',  type: 'text'}
            
        ]);  
         var actionFilter = {"Stage":component.get("v.Stage"),"Status":component.get("v.Status")};
        helper.getApp(component, helper);
    },
    onSave : function (component, event, helper) {
        helper.saveDataTable(component, event, helper);
    },
    doSearch:function(component, event, helper){
         helper.getApp(component, helper);
    },   
    New : function (component, event, helper) {
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({
            "entityApiName": "Application__c"
        });
        createRecordEvent.fire();
    },
    ApplicationStage:function(component, event, helper){
        console.log('1');
        var stage = component.find("applicationstage").get("v.value");
        console.log('stage : '+stage);
        if(stage!= 'None'){
            console.log('3');
            component.set('v.Stage',stage);
         helper.ApplicationStage(component, helper);    
        }
        else{
            
            console.log('Select an Stage');
        }
        
    },
     ApplicationStatus:function(component, event, helper){
          var status = component.find("applicationstatus").get("v.value");
        if(status!= 'None'){
            component.set('v.Status',status);
            
         helper.ApplicationStatus(component, helper);
        }
        else{
            console.log('Select an Status');
        }
    }, 
    
})
({
    getApp : function(component, event, helper) {
        var action = component.get("c.getApplication");
        action.setParams({
            //'Stage': component.get("v.Stage"),
            //'Status': component.get("v.Status")
            'AppId': component.get("v.AppId"),
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if (row.Borrower__c) {
                        row.Borrower__c = row.Borrower__r.Name;
                        //row.Borrower__c = '/'+Borrower__r.name;
                    }
                    if(row.ProductType__c) {
                        row.ProductType__c = row.ProductType__r.Name;
                    } 
                }
                rows.forEach(function(record){
                    record.linkName = '/'+record.Id;
                });  
                
                component.set("v.data", rows);
            }
        });
        $A.enqueueAction(action);
    },
    
    saveDataTable : function(component, event, helper) {
        var editedRecords =  component.find("applicationDataTable").get("v.draftValues");
        var totalRecordEdited = editedRecords.length;
        var action = component.get("c.updateApplications");
        action.setParams({
            'editedApplicationList' : editedRecords
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                //if update is successful
                if(response.getReturnValue() === true){
                    helper.showToast({
                        "title": "Record Update",
                        "type": "success",
                        "message": totalRecordEdited+" Account Records Updated"
                    });
                    helper.reloadDataTable();
                } else{ //if update got failed
                    helper.showToast({
                        "title": "Error!!",
                        "type": "error",
                        "message": "Error in update"
                    });
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    showToast : function(params){
        var toastEvent = $A.get("e.force:showToast");
        if(toastEvent){
            toastEvent.setParams(params);
            toastEvent.fire();
        } else{
            alert(params.message);
        }
    },
    
    reloadDataTable : function(){
        var refreshEvent = $A.get("e.force:refreshView");
        if(refreshEvent){
            refreshEvent.fire();
        }
    },
    ApplicationStage : function(component, event, helper) {
        var action = component.get("c.getApplicationStage");
        action.setParams({
            'Stage': component.get("v.Stage"),
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if (row.Borrower__c) {
                        row.Borrower__c = row.Borrower__r.Name;
                        //row.Borrower__c = '/'+Borrower__r.name;
                    }
                    if(row.ProductType__c) {
                        row.ProductType__c = row.ProductType__r.Name;
                    } 
                }
                rows.forEach(function(record){
                    record.linkName = '/'+record.Id;
                });  
                component.find("applicationstatus").set('v.value','None');
                component.set("v.data", rows);
            }
        });
        $A.enqueueAction(action);
    },
    ApplicationStatus : function(component, event, helper) {
        var action = component.get("c.getApplicationStatus");
        action.setParams({
            'Status': component.get("v.Status"),
        });
        action.setCallback(this,function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var rows = response.getReturnValue();
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    if (row.Borrower__c) {
                        row.Borrower__c = row.Borrower__r.Name;
                        //row.Borrower__c = '/'+Borrower__r.name;
                    }
                    if(row.ProductType__c) {
                        row.ProductType__c = row.ProductType__r.Name;
                    } 
                }
                rows.forEach(function(record){
                    record.linkName = '/'+record.Id;
                });  
                console.log('1');
                component.find("applicationstage").set('v.value','None');
                console.log('2');
                component.set("v.data", rows);
            }
        });
        $A.enqueueAction(action);
    },
})